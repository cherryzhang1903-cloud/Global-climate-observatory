import assert from 'node:assert/strict';
import {aggregateUltraviolet,loadUltraviolet} from './src/utils/solar.mjs';
const make=(a,b)=>({header:{time_standard:'UTC',fill_value:-999},parameters:{ALLSKY_SFC_UVA:{units:'Wh/m^2'},ALLSKY_SFC_UVB:{units:'Wh/m^2'}},properties:{parameter:{ALLSKY_SFC_UVA:a,ALLSKY_SFC_UVB:b}}});
const a={},b={};for(let h=0;h<24;h++){let k='20250101'+String(h).padStart(2,'0');a[k]=10;b[k]=2;}
const x=aggregateUltraviolet(make(a,b),2025,'UTC');assert.ok(Math.abs(x.daily[0].energy-24*12*.0036)<1e-10);assert.equal(x.validHours,24);
b['2025010100']=-999;const y=aggregateUltraviolet(make(a,b),2025,'UTC');assert.equal(y.hourly[0].energy,null);assert.equal(y.validHours,23);assert.equal(y.daily[0].energy,null);
a['2025010101']=0;b['2025010101']=0;assert.equal(aggregateUltraviolet(make(a,b),2025,'UTC').hourly[1].energy,0);
let requested='';await loadUltraviolet(42,89,2025,'Asia/Shanghai',undefined,async url=>{requested=url;return {ok:true,json:async()=>make(a,b)}});
const params=new URL(requested).searchParams.get('parameters');assert.equal(params,'ALLSKY_SFC_UVA,ALLSKY_SFC_UVB');assert.ok(!params.includes('INDEX'));
assert.throws(()=>aggregateUltraviolet(make(a,undefined),2025,'UTC'),/UVB/);
const mixed=make({'2025010100':10},{'2025010100':.002});mixed.parameters.ALLSKY_SFC_UVB.units='kW-hr/m^2';assert.ok(Math.abs(aggregateUltraviolet(mixed,2025,'UTC').hourly[0].energy-.0432)<1e-12);
console.log('PASS UVA+UVB sum, matching-hour validity, valid zero, unit conversion and exact API parameters.');
