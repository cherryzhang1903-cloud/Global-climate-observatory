# V5 report source

Run npm ci, node test-ultraviolet.mjs, node test-solar.mjs, then node build.mjs. Build output: ../site/report. Viewing the built website does not require Node.js.
