import assert from 'node:assert/strict';
import {parseMeteostatCsv,boundaryYears,localizeAnnualData} from './src/utils/meteostat.mjs';
const dump=(year,line)=>parseMeteostatCsv('year,month,day,hour,temp,rhum,temp_source\n'+line,year);
assert.deepEqual(boundaryYears(2025,'Asia/Shanghai'),[2024]);assert.deepEqual(boundaryYears(2025,'America/New_York'),[2026]);assert.deepEqual(boundaryYears(2025,'UTC'),[]);
const prev=dump(2024,'2024,12,31,16,11,50,model\n');const main=dump(2025,'2025,1,1,0,22,50,obs\n');const cn=localizeAnnualData([prev,main],2025,'Asia/Shanghai');assert.equal(cn.rows.length,8760);assert.equal(cn.rows[0][0],'2025-01-01T00:00:00');assert.equal(cn.rows[0][1],11);assert.equal(cn.rows[8][1],22);assert.equal(cn.rows.at(-1)[0],'2025-12-31T23:00:00');assert.equal(cn.modelHours,1);
const next=dump(2026,'2026,1,1,4,33,50,obs\n');const ny=localizeAnnualData([main,next],2025,'America/New_York');assert.equal(ny.rows.at(-1)[1],33);assert.equal(ny.rows.filter(r=>r[0].startsWith('2025-03-09')).length,23);assert.equal(ny.rows.filter(r=>r[0].startsWith('2025-11-02')).length,25);const repeated=ny.rows.flatMap((r,i)=>r[0]==='2025-11-02T01:00:00'?[ny.utcTimes[i]]:[]);assert.equal(repeated.length,2);assert.notEqual(repeated[0],repeated[1]);
assert.throws(()=>boundaryYears(2025,''),/缺少/);assert.throws(()=>boundaryYears(2025,'Invalid/Zone'),/无效/);
console.log('PASS: local year boundaries, positive/negative offsets, previous/next year data, DST 23/25-hour days, repeated local hours retain unique UTC, invalid zones');
