const PARAM='ALLSKY_SFC_SW_DWN';
const stamp=(f,ms)=>{const p=Object.fromEntries(f.formatToParts(new Date(ms)).map(x=>[x.type,x.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;};
export function aggregateSolar(payload,year,timezone){
 if(payload.header?.time_standard!=='UTC')throw Error('NASA数据时间标准不是UTC');
 const unit=payload.parameters?.[PARAM]?.units;
 const factor=unit==='Wh/m^2'?0.0036:unit==='kW-hr/m^2'?3.6:null;
 if(factor===null)throw Error('NASA辐照数据单位无法识别：'+unit);
 const source=payload.properties?.parameter?.[PARAM];if(!source||typeof source!=='object')throw Error('NASA未提供辐照数据');
 const f=new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 const hourly=[],days=new Map();let sum=0,validHours=0,peak=null;
 for(let ms=Date.UTC(year,0,1)-86400000;ms<Date.UTC(year+1,0,1)+86400000;ms+=3600000){
  const local=stamp(f,ms);if(Number(local.slice(0,4))!==year)continue;
  const utc=new Date(ms).toISOString().slice(0,19)+'Z',key=utc.slice(0,13).replace(/[-T:]/g,''),raw=source[key];
  const energy=typeof raw==='number'&&Number.isFinite(raw)&&raw>=0&&raw!==payload.header?.fill_value?raw*factor:null;
  const irradiance=energy===null?null:energy/0.0036;
  hourly.push({utc,local,energy,irradiance});const date=local.slice(0,10);
  if(!days.has(date))days.set(date,{date,expected:0,valid:0,sum:0});const d=days.get(date);d.expected++;
  if(energy!==null){d.valid++;d.sum+=energy;sum+=energy;validHours++;if(peak===null||irradiance>peak.irradiance)peak={local,utc,irradiance};}
 }
 const daily=[...days.values()].map(d=>({...d,energy:d.valid===d.expected?d.sum:null}));
 const monthly=Array.from({length:12},(_,i)=>{const month=`${year}-${String(i+1).padStart(2,'0')}`,ds=daily.filter(d=>d.date.startsWith(month)),expected=ds.reduce((n,d)=>n+d.expected,0),valid=ds.reduce((n,d)=>n+d.valid,0);return {month,expected,valid,energy:valid===expected?ds.reduce((n,d)=>n+d.sum,0):null};});
 return {hourly,daily,monthly,validHours,expectedHours:hourly.length,completeDays:daily.filter(d=>d.energy!==null).length,total:validHours===hourly.length?sum:null,availableEnergy:sum,peak,timezone,year,unit};
}
export function aggregateUltraviolet(payload,year,timezone){
 const names=['ALLSKY_SFC_UVA','ALLSKY_SFC_UVB'];
 const factors=names.map(name=>{const u=payload.parameters?.[name]?.units;const factor=u==='Wh/m^2'?.0036:u==='kW-hr/m^2'?3.6:null;if(factor===null)throw Error('NASA紫外辐照数据单位无法识别：'+name+' '+u);return factor;});
 const [a,b]=names.map(name=>{const source=payload.properties?.parameter?.[name];if(!source||typeof source!=='object')throw Error('NASA未提供'+name+'数据');return source;});
 const combined={};const valid=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v!==payload.header?.fill_value;
 for(const key of new Set([...Object.keys(a),...Object.keys(b)]))combined[key]=valid(a[key])&&valid(b[key])?(a[key]*factors[0]+b[key]*factors[1])/.0036:null;
 return {...aggregateSolar({...payload,parameters:{[PARAM]:{units:'Wh/m^2'}},properties:{parameter:{[PARAM]:combined}}},year,timezone),kind:'ultraviolet'};
}
export const loadUltraviolet=(lat,lon,year,timezone,signal,fetcher=fetch)=>loadSolar(lat,lon,year,timezone,signal,fetcher,'ultraviolet');
export async function loadSolar(lat,lon,year,timezone,signal,fetcher=fetch,kind='solar'){
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw Error('站点经纬度无效');
 const q=new URLSearchParams({parameters:kind==='ultraviolet'?'ALLSKY_SFC_UVA,ALLSKY_SFC_UVB':PARAM,community:'RE',latitude:String(lat),longitude:String(lon),start:`${year-1}1231`,end:`${year+1}0101`,format:'JSON','time-standard':'UTC'});
 const url='https://power.larc.nasa.gov/api/temporal/hourly/point?'+q;
 const ctl=new AbortController(),abort=()=>ctl.abort();signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();const timer=setTimeout(abort,60000);
 try{const r=await fetcher(url,{signal:ctl.signal,credentials:'omit',cache:'default'});if(!r.ok)throw Error(`NASA POWER返回${r.status}，请稍后重试`);const payload=await r.json();return {...(kind==='ultraviolet'?aggregateUltraviolet:aggregateSolar)(payload,year,timezone),url,fetchedAt:new Date().toISOString(),sources:payload.header?.sources||[]};}
 catch(e){if(e.name==='AbortError')throw Error('NASA辐照请求已取消或超时，请重试');if(e instanceof TypeError)throw Error('无法连接NASA POWER，请检查网络或跨域限制后重试');throw e;}
 finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
