/**
 * 导出工具集合：将元素导出为长图片（PNG）
 * - 特性
 *   1) 导出前临时缩放页面（CSS zoom，默认 90%），导出后恢复
 *   2) 单张优先：如果整页超出浏览器单次位图上限，自动“分片渲染 + 拼接 + 等比缩小”为一张图
 *   3) 滚动截图式切片：在克隆文档内创建 wrapper，根元素 absolute 置顶并按切片位移，避免顶部/底部空白或缺失
 *   4) 支持排除导出元素（如悬浮导出按钮），默认识别 [data-export-exclude="true"]
 */

import type html2canvasType from 'html2canvas'

/** 导出基础选项 */
export interface BaseExportOptions {
  /** 文件名（不含扩展名） */
  fileName: string
  /** 画布缩放，决定清晰度（与页面 zoom 无关），建议 1~2 */
  scale?: 1 | 1.5 | 2
  /** 背景：匹配主题 或 透明（仅 PNG 有效） */
  background?: 'matchTheme' | 'transparent'
}

/** 长图导出选项 */
export interface ImageExportOptions extends BaseExportOptions {
  /** 单张输出最大高度（画布像素），超过则等比缩小到该高度，默认 16000 */
  maxSingleImageHeight?: number
  /** 分片导出时每片 CSS 高度，默认 2200（过小会增加次数，过大会增加内存峰值） */
  sliceHeight?: number
  /** 导出时临时网页缩放百分比（CSS zoom），默认 90；设置 100 则不缩放 */
  tempZoomPercent?: number
  /** 优先输出单张图：若超限则拼接后等比缩小为单图；false 则输出多张，默认 true */
  preferSingleImage?: boolean
  /** 需要在导出时隐藏的选择器（visibility: hidden，不影响布局） */
  excludeSelectors?: string[]
}

/** 延时 */
function sleep(ms: number) {
  return new Promise((res) => setTimeout(res, ms))
}

/** 下载 DataURL 为文件 */
function downloadDataURL(fileName: string, dataUrl: string) {
  const a = document.createElement('a')
  a.href = dataUrl
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  a.remove()
}

/** 等待元素内部图片加载完成（避免空白占位导致尺寸不稳） */
async function waitImagesLoaded(root: HTMLElement) {
  const imgs = Array.from(root.querySelectorAll('img'))
  if (!imgs.length) return
  await Promise.all(
    imgs.map((img) => {
      const el = img as HTMLImageElement
      if (el.complete) return Promise.resolve()
      return new Promise<void>((res) => {
        el.addEventListener('load', () => res(), { once: true })
        el.addEventListener('error', () => res(), { once: true })
      })
    })
  )
}

/** 触发稳定布局：一次 resize + 两帧 RAF */
async function stabilizeLayout() {
  window.dispatchEvent(new Event('resize'))
  await new Promise((r) => requestAnimationFrame(() => r(undefined)))
  await new Promise((r) => requestAnimationFrame(() => r(undefined)))
}

/**
 * 临时设置页面缩放（CSS zoom），返回用于恢复的清理函数
 * @param zoom 页面缩放比例，如 0.9
 */
function applyTempZoom(zoom: number): () => void {
  const html = document.documentElement as HTMLElement & { style: any }
  const prev = html.style.zoom as string | undefined
  html.style.zoom = String(zoom)
  return () => {
    if (prev === undefined) html.style.zoom = ''
    else html.style.zoom = prev
  }
}

/**
 * 计算导出根的完整尺寸
 * - 宽度取根元素 scrollWidth 与视口/文档宽度的最大值
 * - 高度以根元素 scrollHeight 为主，兜底比较文档高度
 */
function measureExportSize(root: HTMLElement) {
  const docEl = document.documentElement
  const rect = root.getBoundingClientRect()
  const width = Math.max(
    Math.ceil(rect.width),
    root.scrollWidth,
    docEl.scrollWidth,
    docEl.clientWidth
  )
  const height = Math.max(root.scrollHeight, docEl.scrollHeight, docEl.clientHeight)
  return { width, height }
}

/**
 * 在克隆文档中将 root 放入一个置顶 wrapper，便于“滚动截图式”切片。
 * 说明：
 * - wrapper 作为渲染视窗（宽 = 页面总宽， 高 = 当前切片高度）
 * - 克隆 root 改为 absolute，top 设为 -sliceTop 以对齐当前切片
 */
function placeRootIntoWrapper(
  doc: Document,
  clonedRoot: HTMLElement,
  params: { width: number; viewHeight: number; sliceTop: number; backgroundColor: string }
) {
  const { width, viewHeight, sliceTop, backgroundColor } = params

  // body 基础样式复位，避免 margin 影响
  doc.body.style.margin = '0'
  doc.body.style.padding = '0'
  doc.documentElement.style.backgroundColor = backgroundColor

  // 创建 wrapper 并作为唯一的渲染容器
  const wrapper = doc.createElement('div')
  wrapper.setAttribute('data-sider-capture-wrapper', 'true')
  wrapper.style.position = 'relative'
  wrapper.style.width = `${width}px`
  wrapper.style.height = `${viewHeight}px`
  wrapper.style.overflow = 'hidden'
  wrapper.style.backgroundColor = backgroundColor

  // 将克隆 root 置为 absolute 顶对齐，并按切片位移
  clonedRoot.style.position = 'absolute'
  clonedRoot.style.left = '0'
  clonedRoot.style.top = `-${sliceTop}px`
  clonedRoot.style.margin = '0'
  clonedRoot.style.transform = 'none'
  clonedRoot.style.transformOrigin = 'top left'
  clonedRoot.style.overflow = 'visible'

  // 将 wrapper 追加到 body 顶部，再把 root 移入 wrapper
  doc.body.insertBefore(wrapper, doc.body.firstChild)
  wrapper.appendChild(clonedRoot)
}

/**
 * 全局临时隐藏元素（visibility: hidden），返回恢复函数
 * - 常用于导出时隐藏悬浮按钮、指导性 overlay 等
 */
function hideElementsTemporarily(selectors: string[]): () => void {
  const nodes: HTMLElement[] = []
  selectors.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el) => {
      if (el instanceof HTMLElement) nodes.push(el)
    })
  })
  const prevs = nodes.map((n) => n.style.visibility)
  nodes.forEach((n) => (n.style.visibility = 'hidden'))
  return () => nodes.forEach((n, i) => (n.style.visibility = prevs[i]))
}

/**
 * 使用 html2canvas 渲染单张完整画布（未超限）
 * - 为避免顶部空白，仍使用 wrapper 技术将 root 置顶
 */
async function renderSingleCanvas(
  html2canvas: typeof html2canvasType,
  root: HTMLElement,
  opts: {
    width: number
    height: number
    scale: number
    backgroundColor: string
  }
) {
  const { width, height, scale, backgroundColor } = opts

  const MARK = 'data-sider-export-marker'
  const markerValue = String(Date.now())
  root.setAttribute(MARK, markerValue)

  try {
    const canvas = await html2canvas(root, {
      useCORS: true,
      allowTaint: false,
      backgroundColor,
      scale,
      logging: false,
      windowWidth: width,
      windowHeight: height,
      foreignObjectRendering: true,
      onclone: (doc) => {
        // 隐藏被标记排除的元素
        doc.querySelectorAll('[data-export-exclude="true"],[data-html2canvas-ignore="true"]').forEach((el) => {
          if (el instanceof HTMLElement) el.style.visibility = 'hidden'
        })
        const cloned = doc.querySelector(`[${MARK}="${markerValue}"]`) as HTMLElement | null
        if (cloned) {
          placeRootIntoWrapper(doc, cloned, {
            width,
            viewHeight: height,
            sliceTop: 0,
            backgroundColor,
          })
        }
      },
    })
    return canvas
  } finally {
    root.removeAttribute(MARK)
  }
}

/**
 * 分片渲染并拼接为“单张等比缩小”的最终画布
 * - 通过 wrapper + absolute 方式实现可靠的“滚动截图”，避免空白区域
 */
async function renderByTilingToSingleCanvas(
  html2canvas: typeof html2canvasType,
  root: HTMLElement,
  params: {
    width: number
    height: number
    captureScale: number
    targetMaxHeight: number
    sliceCssHeight: number
    backgroundColor: string
  }
) {
  const { width, height, captureScale, targetMaxHeight, sliceCssHeight, backgroundColor } = params

  // 目标输出尺寸（确保不超过 targetMaxHeight）
  const estCaptureHeightPx = Math.ceil(height * captureScale)
  const finalHeight = Math.min(targetMaxHeight, estCaptureHeightPx)
  const downRatio = finalHeight / estCaptureHeightPx
  const finalWidth = Math.max(1, Math.floor(width * captureScale * downRatio))

  const out = document.createElement('canvas')
  out.width = finalWidth
  out.height = finalHeight
  const outCtx = out.getContext('2d')
  if (!outCtx) throw new Error('导出失败：无法创建拼接画布的绘制上下文')
  outCtx.imageSmoothingEnabled = true
  ;(outCtx as any).imageSmoothingQuality = 'high'

  // 标记原始 root，以便在 onclone 中定位
  const MARK = 'data-sider-export-marker'
  const markerValue = String(Date.now())
  root.setAttribute(MARK, markerValue)

  try {
    const totalSlices = Math.ceil(height / sliceCssHeight)

    for (let i = 0; i < totalSlices; i++) {
      const top = i * sliceCssHeight
      const h = Math.min(sliceCssHeight, height - top)

      const sliceCanvas = await html2canvas(root, {
        useCORS: true,
        allowTaint: false,
        backgroundColor,
        scale: captureScale,
        logging: false,
        windowWidth: width,
        windowHeight: h,
        foreignObjectRendering: true,
        onclone: (doc) => {
          // 隐藏被标记排除的元素（在克隆文档中）
          doc.querySelectorAll('[data-export-exclude="true"],[data-html2canvas-ignore="true"]').forEach((el) => {
            if (el instanceof HTMLElement) el.style.visibility = 'hidden'
          })
          const cloned = doc.querySelector(`[${MARK}="${markerValue}"]`) as HTMLElement | null
          if (cloned) {
            placeRootIntoWrapper(doc, cloned, {
              width,
              viewHeight: h,
              sliceTop: top,
              backgroundColor,
            })
          }
        },
      })

      // 将切片按比例绘制到最终画布对应位置
      const drawY = Math.floor(top * captureScale * downRatio)
      const drawH = Math.floor(h * captureScale * downRatio)
      const drawW = finalWidth
      outCtx.drawImage(sliceCanvas, 0, 0, sliceCanvas.width, sliceCanvas.height, 0, drawY, drawW, drawH)

      // 稳态处理，避免连续大渲染阻塞
      await sleep(8)
    }
  } finally {
    root.removeAttribute(MARK)
  }

  return out
}

/**
 * 将元素导出为长图片（PNG）
 * - 默认在导出前将页面缩放至 90%，导出后恢复
 * - 优先单张：若预计高度超出安全阈值，采用“分片渲染 + 拼接 + 等比缩小”为一张图
 * - 支持排除选择器，避免悬浮元素进入截图
 */
export async function exportElementToLongImage(root: HTMLElement, opts: ImageExportOptions) {
  const {
    fileName,
    scale = 2,
    background = 'matchTheme',
    maxSingleImageHeight = 16000,
    sliceHeight = 2200,
    tempZoomPercent = 90,
    preferSingleImage = true,
    excludeSelectors = ['[data-export-exclude="true"]'],
  } = opts

  if (!root) throw new Error('未找到导出根元素')

  await waitImagesLoaded(root)

  // 导出期间临时缩放页面到指定比例，提高容纳能力
  let cleanupZoom: (() => void) | null = null
  // 导出期间临时隐藏元素
  let cleanupHidden: (() => void) | null = null

  try {
    if (tempZoomPercent && tempZoomPercent > 0 && tempZoomPercent !== 100) {
      const z = Math.max(0.1, Math.min(5, tempZoomPercent / 100))
      cleanupZoom = applyTempZoom(z)
      await stabilizeLayout()
    }

    if (excludeSelectors.length) {
      cleanupHidden = hideElementsTemporarily(excludeSelectors)
    }

    const html2canvasModule = await import('html2canvas')
    const html2canvas = (html2canvasModule.default ||
      (html2canvasModule as unknown as typeof html2canvasType)) as typeof html2canvasType

    // 背景与主题匹配
    const isDark = document.documentElement.classList.contains('dark')
    const bg = background === 'matchTheme' ? (isDark ? '#0f172a' : '#ffffff') : 'transparent'

    const { width, height } = measureExportSize(root)

    // 浏览器单次画布的安全阈值（经验值，略低于常见 16384 上限，留余量）
    const SAFE_SINGLE_CAPTURE_PX = 14000
    const estCanvasHeight = Math.ceil(height * scale)

    // ——— 单张优先：若可能超限，采用分片拼接后整体缩小为单张 ———
    if (preferSingleImage && estCanvasHeight > SAFE_SINGLE_CAPTURE_PX) {
      const out = await renderByTilingToSingleCanvas(html2canvas, root, {
        width,
        height,
        captureScale: scale,
        targetMaxHeight: maxSingleImageHeight,
        sliceCssHeight: Math.max(600, Math.floor(sliceHeight)),
        backgroundColor: bg,
      })
      const dataUrl = out.toDataURL('image/png')
      downloadDataURL(`${fileName}.png`, dataUrl)
      return
    }

    // ——— 直接单次渲染（未超限）：也走 wrapper 置顶，避免顶部空白 ———
    const canvas = await renderSingleCanvas(html2canvas, root, {
      width,
      height,
      scale,
      backgroundColor: bg,
    })

    // 若画布超过最大高度，整体缩小为单张
    if (preferSingleImage && canvas.height > maxSingleImageHeight) {
      const ratio = Math.max(0.1, maxSingleImageHeight / canvas.height)
      const out = document.createElement('canvas')
      out.width = Math.floor(canvas.width * ratio)
      out.height = Math.floor(canvas.height * ratio)
      const ctx = out.getContext('2d')
      if (!ctx) throw new Error('导出失败：无法创建绘制上下文')
      ctx.imageSmoothingEnabled = true
      ;(ctx as any).imageSmoothingQuality = 'high'
      ctx.drawImage(canvas, 0, 0, out.width, out.height)
      const dataUrl = out.toDataURL('image/png')
      downloadDataURL(`${fileName}.png`, dataUrl)
      return
    }

    // ——— 不走单张优先：输出多图分段 ———
    if (!preferSingleImage && canvas.height > maxSingleImageHeight) {
      const slice = Math.max(600, Math.floor(sliceHeight))
      const total = Math.ceil(height / slice)

      for (let i = 0; i < total; i++) {
        const h = Math.min(slice, height - i * slice)

        // 逐段单独渲染（wrapper 置顶），保证每段完整
        const part = await renderByTilingToSingleCanvas(html2canvas, root, {
          width,
          height: h,
          captureScale: scale,
          targetMaxHeight: Math.ceil(h * scale),
          sliceCssHeight: h,
          backgroundColor: bg,
        })

        const dataUrl = part.toDataURL('image/png')
        const suffix = `_第${i + 1}张`
        downloadDataURL(`${fileName}${suffix}.png`, dataUrl)
        await sleep(10)
      }
      return
    }

    // 单张即可
    const dataUrl = canvas.toDataURL('image/png')
    downloadDataURL(`${fileName}.png`, dataUrl)
  } finally {
    // 恢复页面缩放与可见性
    if (cleanupZoom) cleanupZoom()
    if (cleanupHidden) cleanupHidden()
    await stabilizeLayout()
  }
}
