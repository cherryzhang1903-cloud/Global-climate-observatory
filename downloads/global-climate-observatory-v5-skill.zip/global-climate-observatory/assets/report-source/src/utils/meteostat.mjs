/** Meteostat official annual dumps. No local hourly data fallback. */
function csvRows(text){
 const rows=[];let row=[],value='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(c===','&&!quoted){row.push(value);value='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(value);if(row.some(v=>v!==''))rows.push(row);row=[];value='';}else value+=c;}
 if(quoted)throw Error('Meteostat CSV引号格式异常');if(value||row.length){row.push(value);rows.push(row);}return rows;
}
const number=v=>v==null||String(v).trim()===''?null:Number.isFinite(Number(v))?Number(v):null;
const bounded=(v,min,max)=>v!==null&&v>=min&&v<=max?v:null;
export function parseMeteostatCsv(text,year){
 const records=csvRows(text.replace(/^\uFEFF/,''));if(!records.length)throw Error('Meteostat未返回数据');const headers=records.shift().map(s=>s.trim());const cols=Object.fromEntries(headers.map((v,i)=>[v,i]));
 for(const k of ['year','month','day','hour','temp','rhum'])if(cols[k]===undefined)throw Error('Meteostat数据缺少字段：'+k);
 const start=Date.UTC(year,0,1),end=Date.UTC(year+1,0,1),hours=(end-start)/3600000;const rows=Array.from({length:hours},(_,i)=>[new Date(start+i*3600000).toISOString().slice(0,19),null,null,null,null,null,null]);const seen=new Set(),modelIndices=[];let modelHours=0;
 for(const r of records){const get=k=>number(r[cols[k]]);if(get('year')!==year)continue;const month=get('month'),day=get('day'),hour=get('hour');if(!Number.isInteger(month)||month<1||month>12||!Number.isInteger(day)||day<1||!Number.isInteger(hour)||hour<0||hour>23)throw Error('Meteostat日期字段无效');const time=Date.UTC(year,month-1,day,hour),dt=new Date(time);if(dt.getUTCMonth()!==month-1)throw Error('Meteostat日期无效');const idx=(time-start)/3600000;if(idx<0||idx>=hours)continue;if(seen.has(idx))throw Error('Meteostat出现重复小时记录');seen.add(idx);
 const t=bounded(get('temp'),-100,65),h=bounded(get('rhum'),0,100);let d=bounded(get('dwpt'),-100,65);if(d!==null&&(t===null||d>t+.5))d=null;
 if(d===null&&t!==null&&h!==null&&h>0){const g=Math.log(h/100)+17.62*t/(243.12+t);d=243.12*g/(17.62-g);}
 const v=get('wspd'),p=get('prcp');rows[idx]=[rows[idx][0],t,d,h,p!==null&&p>=0?p:null,v!==null&&v>=0?v/3.6:null,bounded(get('pres'),100,1200)];
 if(['temp','rhum','prcp','wspd','pres'].some(k=>/model|forecast/i.test(r[cols[k+'_source']]||''))){modelHours++;modelIndices.push(idx);}
 }
 if(!seen.size)throw Error('Meteostat未提供该年度小时记录');return {rows,presentHours:seen.size,missingHours:hours-seen.size,modelHours,year,timezone:'UTC',presentIndices:[...seen],modelIndices};
}
export async function loadMeteostatHourly(id,year=2025,signal){
 if(!/^[A-Za-z0-9]{3,12}$/.test(id))throw Error('站点代码无效');const url=`https://data.meteostat.net/hourly/${year}/${encodeURIComponent(id)}.csv.gz`;const controller=new AbortController();const abort=()=>controller.abort();if(signal?.aborted)controller.abort();signal?.addEventListener('abort',abort);const timer=setTimeout(()=>controller.abort(),45000);
 try{const r=await fetch(url,{signal:controller.signal,cache:'default',credentials:'omit'});if(!r.ok)throw Error(r.status===404?'Meteostat暂未提供该站点2025年度数据（404）':`Meteostat服务返回${r.status}，请稍后重试`);const bytes=new Uint8Array(await r.arrayBuffer());let text;if(bytes[0]===31&&bytes[1]===139){if(!('DecompressionStream' in globalThis))throw Error('请使用新版Chrome、Edge或Firefox读取线上压缩数据');text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}else{text=new TextDecoder().decode(bytes);}return {...parseMeteostatCsv(text,year),url,fetchedAt:new Date().toISOString()};
 }catch(e){if(e.name==='AbortError')throw Error('Meteostat请求已取消或超过45秒，请检查网络后重试');if(e instanceof TypeError)throw Error('无法连接Meteostat，请检查网络或跨域访问限制后重试；V3不会读取本地逐小时文件');throw e;}finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
function localFormatter(timezone){if(!timezone)throw Error('本站缺少当地时区，不能将UTC当作当地时间');try{return new Intl.DateTimeFormat('en-CA',{timeZone:timezone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});}catch{throw Error('本站时区无效或浏览器暂不支持：'+timezone);}}
function localStamp(formatter,ms){const p=Object.fromEntries(formatter.formatToParts(new Date(ms)).map(v=>[v.type,v.value]));return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}`;}
export function boundaryYears(year,timezone){const f=localFormatter(timezone),start=Date.UTC(year,0,1),end=Date.UTC(year+1,0,1);const offset=ms=>Date.parse(localStamp(f,ms)+'Z')-ms;return [...new Set([...(offset(start)>0?[year-1]:[]),...(offset(end-3600000)<0?[year+1]:[])])];}
export function localizeAnnualData(dumps,year,timezone){
 const f=localFormatter(timezone),source=new Map(),present=new Set(),model=new Set();
 for(const d of dumps){for(const row of d.rows)source.set(row[0],row);for(const i of d.presentIndices||[])present.add(d.rows[i][0]);for(const i of d.modelIndices||[])model.add(d.rows[i][0]);}
 const rows=[],utcTimes=[];let presentHours=0,modelHours=0;const start=Date.UTC(year,0,1)-86400000,end=Date.UTC(year+1,0,1)+86400000;
 for(let ms=start;ms<end;ms+=3600000){const local=localStamp(f,ms);if(Number(local.slice(0,4))!==year)continue;const utc=new Date(ms).toISOString().slice(0,19),r=source.get(utc)||[utc,null,null,null,null,null,null];rows.push([local,...r.slice(1)]);utcTimes.push(utc+'Z');if(present.has(utc))presentHours++;if(model.has(utc))modelHours++;}
 return {rows,utcTimes,presentHours,missingHours:rows.length-presentHours,modelHours,year,timezone};
}
export async function loadMeteostatLocalHourly(id,year,timezone,signal){
 const boundaries=boundaryYears(year,timezone),main=await loadMeteostatHourly(id,year,signal),warnings=[];const extra=[];
 for(const y of boundaries){try{extra.push(await loadMeteostatHourly(id,y,signal));}catch(e){if(signal?.aborted)throw e;warnings.push(`${y}年跨年边界数据读取失败，缺少的当地小时保留为空：${e.message}`);}}
 return {...localizeAnnualData([main,...extra],year,timezone),url:main.url,urls:[main,...extra].map(d=>d.url),warnings,fetchedAt:new Date().toISOString()};
}
