/** 
 * 主页面组件 - 天气数据分析应用（含导出功能）
 * - 提供文件上传和数据可视化
 * - 支持深色/浅色模式切换（白底黑字 vs 深色）
 */
import React, { useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Alert, AlertDescription } from '../components/ui/alert';
import { 
  CloudRain, 
  Thermometer, 
  Droplets, 
  Calendar,
  MapPin,
  Clock,
  TrendingUp,
  BarChart3,
  Upload
} from 'lucide-react';
import TemperatureChart from '../components/TemperatureChart';
import HumidityChart from '../components/HumidityChart';
import MonthlyStatsChart from '../components/MonthlyStatsChart';
import MonthlyExtremeTemperatureChart from '../components/MonthlyExtremeTemperatureChart';
import DataSummary from '../components/DataSummary';
import DataUploader from '../components/DataUploader';
import DailyTemperatureChart from '../components/DailyTemperatureChart';
import HourlyTemperatureHumidityChart from '../components/HourlyTemperatureHumidityChart';
import HotHumidHoursChart from '../components/HotHumidHoursChart';
import ClimateSummary from '../components/ClimateSummary';
import ExportToolbar from '../components/ExportToolbar';
import ThemeToggle from '../components/ThemeToggle';
import YearlyHighHumidityHoursChart from '../components/YearlyHighHumidityHoursChart';
import HeatStressClassificationChart from '../components/HeatStressClassificationChart';

/** 天气配置 */
export interface WeatherConfig {
  /** 地点名称 */
  locationName: string;
  /** 纬度 */
  latitude: number;
  /** 经度 */
  longitude: number;
  /** 时区 */
  timezone: string;
  /** 开始日期 */
  startDate: string;
  /** 结束日期 */
  endDate: string;
  /** 高温阈值 */
  highTempThreshold: number;
  /** 低温阈值 */
  lowTempThreshold: number;
  /** 高湿阈值 */
  highHumidityThreshold: number;
  /** 低湿阈值 */
  lowHumidityThreshold: number;
}

/** 天气数据项 */
export interface WeatherData {
  /** ISO 时间 */
  datetime: string;
  /** 温度 ℃ */
  temperature: number;
  /** 相对湿度 % */
  humidity: number;
  /** 露点温度 ℃（来自 DWPT 列，可选） */
  dewPoint?: number;
  /** 降水 mm */
  precipitation: number;
  /** 风速 m/s */
  windSpeed: number;
  /** 气压 hPa */
  pressure: number;
}

/**
 * 主页面组件
 */
export default function Home() {
  const [config, setConfig] = useState<WeatherConfig | null>(null);
  const [weatherData, setWeatherData] = useState<WeatherData[]>([]);
  const [error, setError] = useState<string | null>(null);

  /** 导出根容器 ref（包裹分析结果区域） */
  const exportRootRef = useRef<HTMLDivElement>(null);

  /**
   * 处理上传数据分析请求
   */
  const handleUploadedDataAnalysis = (uploadConfig: WeatherConfig, uploadData: WeatherData[]) => {
    setConfig(uploadConfig);
    setWeatherData(uploadData);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-white p-4 text-slate-900 dark:bg-gradient-to-br dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 dark:text-white">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* 顶部工具区：主题切换 */}
        <div className="flex items-center justify-end">
          <ThemeToggle />
        </div>

        {/* 页面标题 */}
        <div className="space-y-4 py-8 text-center">
          <div className="flex items-center justify-center space-x-3">
            <CloudRain className="h-10 w-10 text-blue-500 dark:text-blue-400" />
            <h1 className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-4xl font-bold text-transparent dark:from-blue-400 dark:to-purple-400">
              天气数据分析系统
            </h1>
          </div>
          <p className="mx-auto max-w-2xl text-lg text-slate-600 dark:text-slate-300">
            上传天气数据文件，获取详细的气候分析和可视化图表
          </p>
        </div>

        {/* 数据上传区域（导出与打印时隐藏） */}
        <div data-export-exclude="true" data-html2canvas-ignore="true" className="print:hidden">
          <DataUploader onDataAnalyzed={handleUploadedDataAnalysis} />
        </div>

        {/* 错误提示 */}
        {error && (
          <Alert className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20">
            <AlertDescription className="text-red-700 dark:text-red-300">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* 数据分析结果 */}
        {config && weatherData.length > 0 && (
          <div className="space-y-6">
            {/* 基本信息 */}
            <Card className="border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800/50">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <CardTitle className="flex items-center space-x-2 text-slate-900 dark:text-white">
                      <MapPin className="h-5 w-5 text-green-600 dark:text-green-400" />
                      <span>分析区域: {config.locationName}</span>
                    </CardTitle>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Badge
                        variant="secondary"
                        className="bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200"
                      >
                        <Calendar className="mr-1 h-4 w-4" />
                        {config.startDate} 至 {config.endDate}
                      </Badge>
                      <Badge
                        variant="secondary"
                        className="bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200"
                      >
                        <Clock className="mr-1 h-4 w-4" />
                        {config.timezone}
                      </Badge>
                      <Badge
                        variant="secondary"
                        className="bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200"
                      >
                        数据点: {weatherData.length}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* 导出工具栏 */}
            <ExportToolbar rootRef={exportRootRef} config={config} dataCount={weatherData.length} />

            {/* 图表与分析内容导出根容器 */}
            <div
              ref={exportRootRef}
              data-export="weather-content"
              data-export-start="true"
              className="space-y-6"
            >
              {/* 数据概览 */}
              <DataSummary data={weatherData} config={config} />

              {/* 导航卡片 */}
              <div className="space-y-6">
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
                  <button className="rounded-lg border border-slate-200 bg-white p-4 text-left transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:bg-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <Thermometer className="h-6 w-6 text-red-500 dark:text-red-400" />
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">温度分析</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">年度温度变化趋势</p>
                      </div>
                    </div>
                  </button>

                  <button className="rounded-lg border border-slate-200 bg-white p-4 text-left transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:bg-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <Droplets className="h-6 w-6 text-blue-500 dark:text-blue-400" />
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">湿度分析</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">温湿度关系分析</p>
                      </div>
                    </div>
                  </button>

                  <button className="rounded-lg border border-slate-200 bg-white p-4 text-left transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:bg-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <BarChart3 className="h-6 w-6 text-purple-500 dark:text-purple-400" />
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">月度统计</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">综合月度分析</p>
                      </div>
                    </div>
                  </button>

                  <button className="rounded-lg border border-slate-200 bg-white p-4 text-left transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:bg-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <TrendingUp className="h-6 w-6 text-green-600 dark:text-green-400" />
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">每日温度</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">日最高最低温度</p>
                      </div>
                    </div>
                  </button>

                  <button className="rounded-lg border border-slate-200 bg-white p-4 text-left transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800/50 dark:hover:bg-slate-700/50">
                    <div className="flex items-center space-x-3">
                      <Clock className="h-6 w-6 text-cyan-600 dark:text-cyan-400" />
                      <div>
                        <h3 className="font-medium text-slate-900 dark:text-white">小时数据</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">全年每小时曲线</p>
                      </div>
                    </div>
                  </button>
                </div>

                {/* 温度分析 */}
                <TemperatureChart data={weatherData} config={config} />

                {/* 全年闷热小时数分布 */}
                <HotHumidHoursChart data={weatherData} config={config} />

                {/* 干热 / 湿热等级全年小时数统计 */}
                <HeatStressClassificationChart data={weatherData} config={config} />

                {/* 湿度分析 */}
                <HumidityChart data={weatherData} config={config} />

                {/* 高湿阈值小时数分析（新增） */}
                <YearlyHighHumidityHoursChart data={weatherData} config={config} />

                {/* 月度统计 */}
                <MonthlyStatsChart data={weatherData} config={config} />

                {/* 每日温度极值分析 */}
                <DailyTemperatureChart data={weatherData} config={config} />

                {/* 全年每小时温湿度曲线 */}
                <HourlyTemperatureHumidityChart data={weatherData} config={config} />
              </div>

              {/* 气候总结 */}
              <ClimateSummary data={weatherData} config={config} />
            </div>
          </div>
        )}

        {/* 空状态 */}
        {!config && (
          <Card className="border-dashed border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800/30">
            <CardContent className="p-12 text-center">
              <Upload className="mx-auto mb-4 h-16 w-16 text-slate-400 dark:text-slate-500" />
              <h3 className="mb-2 text-xl font-semibold text-slate-800 dark:text-slate-300">
                开始分析天气数据
              </h3>
              <p className="mb-4 text-slate-600 dark:text-slate-400">
                上传包含温度、湿度等气象要素的数据文件
              </p>
              <div className="flex flex-col items-center justify-center space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <div className="flex items-center space-x-2">
                  <Upload className="h-4 w-4 text-green-600 dark:text-green-400" />
                  <span>支持CSV、Excel格式文件</span>
                </div>
                <div className="flex items-center space-x-2">
                  <BarChart3 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  <span>自动生成多维度分析图表</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
