import { createRoot } from 'react-dom/client'
import './styles/print.css'
import App from './Entry'

const root = createRoot(document.getElementById('app')!)
if (window.parent !== window) document.documentElement.classList.add('embedded-report')
document.documentElement.classList.toggle('dark', localStorage.getItem('theme') === 'dark')
root.render(<App />)
