import React from 'react';
import StationReport from './pages/StationReport';
export default function Entry(){return <StationReport/>;}
