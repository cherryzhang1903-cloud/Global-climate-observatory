/** 
 * 应用路由入口（含主题初始化）
 * - 仅保留首页路由
 * - 新增：首次加载根据 localStorage 或系统偏好设置主题（切换依赖 html 的 .dark 类）
 */
import { HashRouter, Route, Routes } from 'react-router'
import { useEffect } from 'react'
import HomePage from './pages/Home'
import SavePageButton from './components/SavePageButton'

/** 应用 dark/light 主题到 html 标签 */
function applyTheme(theme: 'dark' | 'light') {
  const root = document.documentElement
  if (theme === 'dark') root.classList.add('dark')
  else root.classList.remove('dark')
}

/**
 * App 根组件
 */
export default function App() {
  useEffect(() => {
    // 读取本地主题设置，或使用系统偏好
    const saved = (localStorage.getItem('theme') as 'dark' | 'light' | null) ?? null
    let theme: 'dark' | 'light'
    if (saved === 'dark' || saved === 'light') {
      theme = saved
    } else {
      const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches
      theme = prefersDark ? 'dark' : 'light'
    }
    applyTheme(theme)
  }, [])

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
      </Routes>
      {/* 全局悬浮导出按钮：仅截取分析内容区域，排除示例下载区 */}
      <SavePageButton targetSelector="[data-export-start='true']" />
    </HashRouter>
  )
}
