/**
 * MonthlyExtremeTemperatureChart.tsx
 * 每月平均最高温度与平均最低温度折线图
 * - 将小时级数据聚合为“每日最高/最低”，再按月份求平均
 * - 适用于全年跨月的冷热对比与季节变化观察
 */

import React, { useMemo } from 'react'
import {
  ResponsiveContainer,
  ComposedChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Area,
  ReferenceLine,
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Thermometer, TrendingUp, TrendingDown } from 'lucide-react'
import type { WeatherConfig, WeatherData } from '../pages/Home'

/** 组件 Props */
interface MonthlyExtremeTemperatureChartProps {
  /** 原始小时级数据 */
  data: WeatherData[]
  /** 配置（用于标题显示等） */
  config: WeatherConfig
}

/** 月度行结构 */
interface MonthlyRow {
  month: number
  monthName: string
  avgDailyMax: number
  avgDailyMin: number
}

/** 将数字向下取整到 5 的倍数 */
function floorTo5(x: number) {
  return Math.floor(x / 5) * 5
}
/** 将数字向上取整到 5 的倍数 */
function ceilTo5(x: number) {
  return Math.ceil(x / 5) * 5
}

/**
 * 从小时数据生成“每月平均最高、平均最低温度”
 * 逻辑：
 * 1. 以“日”为单位统计当天小时温度的 max/min
 * 2. 按月份对每日 max/min 求平均
 */
function useMonthlyExtremes(data: WeatherData[]): MonthlyRow[] {
  return useMemo(() => {
    // dayKey -> { monthIdx, max, min }
    const dayMap = new Map<
      string,
      { monthIdx: number; max: number; min: number }
    >()

    data.forEach((item) => {
      const t = Number(item.temperature ?? 0)
      const d = new Date(item.datetime+'Z')
      if (isNaN(d.getTime())) return
      const y = d.getUTCFullYear()
      const m = d.getUTCMonth() // 0-11
      const day = d.getUTCDate()
      const key = `${y}-${m + 1}-${day}`

      const existed = dayMap.get(key)
      if (existed) {
        existed.max = Math.max(existed.max, t)
        existed.min = Math.min(existed.min, t)
      } else {
        dayMap.set(key, { monthIdx: m, max: t, min: t })
      }
    })

    // 初始化 12 月容器
    const buckets = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      monthName: new Date(2024, i, 1).toLocaleDateString('zh-CN', { month: 'short' }),
      maxSum: 0,
      minSum: 0,
      count: 0,
    }))

    // 将每天的极值聚合到各自月份
    dayMap.forEach((v) => {
      const b = buckets[v.monthIdx]
      b.maxSum += v.max
      b.minSum += v.min
      b.count += 1
    })

    // 输出月度平均极值
    return buckets.map((b) => ({
      month: b.month,
      monthName: b.monthName,
      avgDailyMax: b.count ? Math.round((b.maxSum / b.count) * 10) / 10 : 0,
      avgDailyMin: b.count ? Math.round((b.minSum / b.count) * 10) / 10 : 0,
    }))
  }, [data])
}

/** 自定义 Tooltip：单位清晰 */
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-800 border border-slate-600 rounded-lg p-3 shadow-lg">
      <p className="text-white font-medium">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-sm" style={{ color: p.color }}>
          {p.name}: {p.value}°C
        </p>
      ))}
    </div>
  )
}

/**
 * 每月平均最高/最低温度折线图
 * - 两条面积折线，色彩区分：最高（橙红）、最低（蓝青）
 * - 0 参考线，便于识别冷月
 * - 自适应轴域，留 10% 缓冲并对齐至 5 的倍数
 */
export default function MonthlyExtremeTemperatureChart({
  data,
  config,
}: MonthlyExtremeTemperatureChartProps) {
  const monthly = useMonthlyExtremes(data)

  const allVals = monthly.flatMap((m) => [m.avgDailyMax, m.avgDailyMin])
  const minV = Math.min(...allVals, 0)
  const maxV = Math.max(...allVals, 0)
  const pad = Math.max(2, (maxV - minV) * 0.1)
  const yMin = floorTo5(minV - pad)
  const yMax = Math.max(5, ceilTo5(maxV + pad))

  return (
    <Card className="bg-white border-slate-200 dark:bg-slate-800/50 dark:border-slate-700">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <Thermometer className="w-5 h-5 text-orange-500 dark:text-orange-400" />
              <span>{config.locationName} 每月平均最高/最低温度</span>
            </CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              基于每日极值聚合的月平均：冷热季节对比更直观
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline" className="border-orange-400 text-orange-500 dark:text-orange-400">
              <TrendingUp className="w-4 h-4 mr-1" /> 月平均最高
            </Badge>
            <Badge variant="outline" className="border-sky-400 text-sky-600 dark:text-sky-400">
              <TrendingDown className="w-4 h-4 mr-1" /> 月平均最低
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[360px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={monthly} margin={{ top: 20, right: 28, left: 12, bottom: 10 }}>
              <defs>
                <linearGradient id="maxTempGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f97316" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#f97316" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="minTempGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity={0.05} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-slate-700" />
              <XAxis dataKey="monthName" stroke="#475569" tick={{ fill: 'currentColor' }} />
              <YAxis
                stroke="#475569"
                domain={[yMin, yMax]}
                tick={{ fill: 'currentColor' }}
                label={{
                  value: '温度 (°C)',
                  angle: -90,
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fill: 'currentColor' },
                }}
              />
              <ReferenceLine y={0} stroke="#94a3b8" strokeDasharray="4 4" />
              <Tooltip content={<CustomTooltip />} />
              <Legend />

              {/* 平均最高温度（面积折线） */}
              <Area isAnimationActive={false}
                type="monotone"
                dataKey="avgDailyMax"
                name="月平均最高温度 (°C)"
                stroke="#f97316"
                strokeWidth={2}
                fill="url(#maxTempGrad)"
                dot={{ r: 3, strokeWidth: 1, stroke: '#f97316', fill: '#fff' }}
                activeDot={{ r: 5 }}
              />
              {/* 平均最低温度（面积折线） */}
              <Area isAnimationActive={false}
                type="monotone"
                dataKey="avgDailyMin"
                name="月平均最低温度 (°C)"
                stroke="#38bdf8"
                strokeWidth={2}
                fill="url(#minTempGrad)"
                dot={{ r: 3, strokeWidth: 1, stroke: '#38bdf8', fill: '#fff' }}
                activeDot={{ r: 5 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
