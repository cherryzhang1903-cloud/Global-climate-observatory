/**
 * SavePageButton.tsx
 * 悬浮的“保存为 PDF”按钮组件，捕获当前页面并导出为 A4 多页 PDF。
 * - 使用 html2canvas 截图，jsPDF 生成 PDF
 * - 默认捕获 #root，找不到则回退到 document.body
 */

import React, { useCallback, useMemo, useState } from 'react'
import { FileDown } from 'lucide-react'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

/** 组件属性 */
interface SavePageButtonProps {
  /** 选择器：要导出的 DOM 区域（可选），默认 '#root' */
  targetSelector?: string
  /** 导出文件名（不含扩展名），默认使用文档标题或 'page-export' */
  fileName?: string
}

/**
 * SavePageButton
 * - 固定在右下角的悬浮按钮
 * - 点击后导出当前页面为 A4 多页 PDF（自动分页）
 */
export default function SavePageButton({
  targetSelector = '#root',
  fileName,
}: SavePageButtonProps) {
  const [loading, setLoading] = useState(false)

  /** 获取导出文件名 */
  const exportName = useMemo(() => {
    const base = fileName?.trim() || document.title?.trim() || 'page-export'
    return base.replace(/[\\/:*?\"<>|]/g, '_')
  }, [fileName])

  /**
   * 依据页面背景计算截图背景
   * 避免深色主题下 PDF 背景变白导致对比度异常
   */
  const getBackgroundColor = () => {
    const bodyBg = getComputedStyle(document.body).backgroundColor
    if (bodyBg && bodyBg !== 'rgba(0, 0, 0, 0)' && bodyBg !== 'transparent') return bodyBg
    // 回退一层：根据 html 的暗色类给出更合适的默认
    const isDark = document.documentElement.classList.contains('dark')
    return isDark ? '#0f172a' : '#ffffff' // slate-900 vs white
  }

  /**
   * 将指定元素导出为 A4 多页 PDF
   */
  const exportToPDF = useCallback(async () => {
    try {
      setLoading(true)
      const target =
        (document.querySelector(targetSelector) as HTMLElement | null) ||
        (document.getElementById('root') as HTMLElement | null) ||
        (document.body as HTMLElement)

      // 以 2x scale 截图，提高清晰度；windowWidth/Height 保证长页面完整截取
      const canvas = await html2canvas(target, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: getBackgroundColor(),
        windowWidth: target.scrollWidth,
        windowHeight: target.scrollHeight,
      })

      const imgData = canvas.toDataURL('image/jpeg', 0.95) // 使用 JPEG，避免生成 PNG 文件
      const pdf = new jsPDF('p', 'mm', 'a4')

      const pageWidth = pdf.internal.pageSize.getWidth()
      const pageHeight = pdf.internal.pageSize.getHeight()

      // 将图像宽度缩放为页面宽度，高度按比例缩放
      const imgWidth = pageWidth
      const imgHeight = (canvas.height * imgWidth) / canvas.width

      // 多页分页处理
      let heightLeft = imgHeight
      let position = 0

      // 第一页
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      // 后续页
      while (heightLeft > 0) {
        pdf.addPage()
        position = heightLeft - imgHeight
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      pdf.save(`${exportName}.pdf`)
    } catch (err) {
      // 简单兜底提示
      console.error('Export PDF failed:', err)
      alert('导出失败，请重试或更换浏览器')
    } finally {
      setLoading(false)
    }
  }, [exportName, targetSelector])

  return (
    <button
      type="button"
      onClick={exportToPDF}
      disabled={loading}
      title={loading ? '正在导出...' : '保存为 PDF'}
      className={[
        'fixed bottom-6 right-6 z-50',
        'inline-flex items-center gap-2 rounded-full',
        'px-4 py-3 shadow-xl',
        'bg-blue-600 hover:bg-blue-700 text-white',
        'border border-blue-400/40',
        'transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-400',
      ].join(' ')}
      aria-label="保存为 PDF"
    >
      <FileDown className="w-5 h-5" />
      <span className="text-sm font-medium">{loading ? '导出中…' : '保存为 PDF'}</span>
    </button>
  )
}
