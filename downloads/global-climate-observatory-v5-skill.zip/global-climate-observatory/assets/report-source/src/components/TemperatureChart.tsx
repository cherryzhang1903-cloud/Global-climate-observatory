/**
 * 温度图表组件
 * 显示年度温度变化曲线和统计信息
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Thermometer, TrendingUp, TrendingDown, Calendar } from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface TemperatureChartProps {
  data: WeatherData[];
  config: WeatherConfig;
}

/**
 * 温度图表组件
 */
export default function TemperatureChart({ data, config }: TemperatureChartProps) {
  // 处理数据，按月份聚合
  const processMonthlyData = () => {
    const monthlyData = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      monthName: new Date(2024, i, 1).toLocaleDateString('zh-CN', { month: 'short' }),
      avgTemp: 0,
      maxTemp: -Infinity,
      minTemp: Infinity,
      highTempHours: 0,
      lowTempHours: 0,
      dataCount: 0
    }));

    data.forEach(item => {
      const date = new Date(item.datetime+'Z');
      const monthIndex = date.getUTCMonth();
      const monthData = monthlyData[monthIndex];
      
      monthData.avgTemp += item.temperature;
      monthData.maxTemp = Math.max(monthData.maxTemp, item.temperature);
      monthData.minTemp = Math.min(monthData.minTemp, item.temperature);
      monthData.dataCount++;
      
      if (item.temperature >= config.highTempThreshold) {
        monthData.highTempHours++;
      }
      if (item.temperature <= config.lowTempThreshold) {
        monthData.lowTempHours++;
      }
    });

    return monthlyData.map(item => ({
      ...item,
      avgTemp: item.dataCount > 0 ? Math.round((item.avgTemp / item.dataCount) * 10) / 10 : null,
      maxTemp: item.maxTemp === -Infinity ? null : item.maxTemp,
      minTemp: item.minTemp === Infinity ? null : item.minTemp
    }));
  };

  // 计算统计数据
  const calculateStats = () => {
    if (data.length === 0) return null;

    const temperatures = data.map(item => item.temperature);
    const maxTemp = Math.max(...temperatures);
    const minTemp = Math.min(...temperatures);
    const avgTemp = temperatures.reduce((sum, temp) => sum + temp, 0) / temperatures.length;
    const highTempHours = data.filter(item => item.temperature >= config.highTempThreshold).length;
    const lowTempHours = data.filter(item => item.temperature <= config.lowTempThreshold).length;

    return {
      maxTemp: Math.round(maxTemp * 10) / 10,
      minTemp: Math.round(minTemp * 10) / 10,
      avgTemp: Math.round(avgTemp * 10) / 10,
      highTempHours,
      lowTempHours,
      totalHours: data.length
    };
  };

  const monthlyData = processMonthlyData();
  const stats = calculateStats();

  // 计算温度数据的实际范围
  const getTemperatureRange = () => {
    if (monthlyData.length === 0) return { min: -20, max: 40 };
    
    const allTemps = monthlyData.flatMap(d => [d.maxTemp, d.minTemp, d.avgTemp]);
    const minTemp = Math.min(...allTemps);
    const maxTemp = Math.max(...allTemps);
    
    // 只留少量缓冲区，更贴近实际数据
    const buffer = Math.max(2, (maxTemp - minTemp) * 0.05); // 5%缓冲区，最少2度
    const minTick = Math.floor((minTemp - buffer) / 5) * 5;
    const maxTick = Math.ceil((maxTemp + buffer) / 5) * 5;
    
    return { min: minTick, max: maxTick };
  };

  const tempRange = getTemperatureRange();

  /**
   * 自定义工具提示
   */
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{`${label}月`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {`${entry.name}: ${entry.value}°C`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* 统计概览 */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/20 border-red-800/30">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-6 h-6 text-red-600 dark:text-red-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.maxTemp}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">最高温度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/20 border-blue-800/30">
            <CardContent className="p-4 text-center">
              <TrendingDown className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.minTemp}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">最低温度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900/20 to-green-800/20 border-green-800/30">
            <CardContent className="p-4 text-center">
              <Thermometer className="w-6 h-6 text-green-600 dark:text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">{stats.avgTemp}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">平均温度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/20 to-orange-800/20 border-orange-800/30">
            <CardContent className="p-4 text-center">
              <Calendar className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{stats.highTempHours}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">高温小时数</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/20 border-purple-800/30">
            <CardContent className="p-4 text-center">
              <Calendar className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{stats.lowTempHours}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">低温小时数</p>
            </CardContent>
          </Card>
        </div>
      )}



      {/* 温度分布统计 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white text-lg">高温小时数统计</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              温度 ≥ {config.highTempThreshold}°C 的小时数分布
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {monthlyData.map(month => (
                <div key={month.month} className="flex items-center justify-between">
                  <span className="text-slate-600 dark:text-slate-300 text-sm">{month.monthName}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-slate-50 dark:bg-slate-700 rounded-full h-2">
                      <div 
                        className="bg-red-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (month.highTempHours / Math.max(month.dataCount, 1)) * 100)}%` }}
                      />
                    </div>
                    <span className="text-red-600 dark:text-red-400 text-sm font-medium w-8">
                      {month.highTempHours}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white text-lg">低温小时数统计</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              温度 ≤ {config.lowTempThreshold}°C 的小时数分布
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {monthlyData.map(month => (
                <div key={month.month} className="flex items-center justify-between">
                  <span className="text-slate-600 dark:text-slate-300 text-sm">{month.monthName}</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-slate-50 dark:bg-slate-700 rounded-full h-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (month.lowTempHours / Math.max(month.dataCount, 1)) * 100)}%` }}
                      />
                    </div>
                    <span className="text-blue-600 dark:text-blue-400 text-sm font-medium w-8">
                      {month.lowTempHours}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}