/**
 * 数据上传组件
 * 支持上传天气数据文件进行分析
 */
import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Upload, 
  FileText, 
  Check, 
  AlertCircle, 
  Download,
  FileSpreadsheet,
  Calendar,
  MapPin,
  Eye,
  BarChart3,
  Thermometer,
  Droplets
} from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface DataUploaderProps {
  onDataAnalyzed: (config: WeatherConfig, data: WeatherData[]) => void;
}

interface ParsedData {
  data: WeatherData[];
  config: Partial<WeatherConfig>;
  summary: {
    totalRecords: number;
    dateRange: {
      start: string;
      end: string;
    };
    dataQuality: {
      completeness: number;
      missingFields: string[];
    };
  };
}

/**
 * 数据上传组件
 */
export default function DataUploader({ onDataAnalyzed }: DataUploaderProps) {
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [parsedData, setParsedData] = useState<ParsedData | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [locationSettings, setLocationSettings] = useState({
    locationName: '',
    latitude: 0,
    longitude: 0,
    timezone: 'UTC'
  });
  const [thresholdSettings, setThresholdSettings] = useState({
    highTempThreshold: 30,
    lowTempThreshold: -10,
    highHumidityThreshold: 70,
    lowHumidityThreshold: 40
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  /**
   * 解析CSV文件内容
   */
  const parseCSV = (content: string): any[] => {
    const lines = content.trim().split('\n');
    if (lines.length < 2) {
      throw new Error('CSV文件格式不正确，至少需要包含标题行和数据行');
    }

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',');
      if (values.length !== headers.length) continue;

      const row: any = {};
      headers.forEach((header, index) => {
        row[header] = values[index]?.trim();
      });
      data.push(row);
    }

    return data;
  };

  /**
   * 解析Excel文件内容
   */
  const parseExcel = async (file: File): Promise<any[]> => {
    // 动态导入xlsx库
    const XLSX = await import('xlsx');
    
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          
          // 获取第一个工作表
          const firstSheetName = workbook.SheetNames[0];
          if (!firstSheetName) {
            throw new Error('Excel文件中没有找到工作表');
          }
          
          const worksheet = workbook.Sheets[firstSheetName];
          
          // 将工作表转换为JSON格式
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
            header: 1,
            defval: ''
          });
          
          if (jsonData.length < 2) {
            throw new Error('Excel文件格式不正确，至少需要包含标题行和数据行');
          }
          
          // 转换为对象数组格式
          const headers = (jsonData[0] as any[]).map((h: any) => 
            String(h || '').trim().toLowerCase()
          );
          
          const dataRows = jsonData.slice(1).map((row: any[]) => {
            const rowObj: any = {};
            headers.forEach((header, index) => {
              const value = row[index];
              rowObj[header] = value !== undefined && value !== null ? String(value).trim() : '';
            });
            return rowObj;
          }).filter(row => {
            // 过滤掉空行
            return Object.values(row).some(val => val !== '');
          });
          
          resolve(dataRows);
        } catch (error) {
          reject(new Error(`Excel文件解析失败: ${error instanceof Error ? error.message : '未知错误'}`));
        }
      };
      
      reader.onerror = () => {
        reject(new Error('文件读取失败'));
      };
      
      reader.readAsArrayBuffer(file);
    });
  };

  /**
   * 标准化数据字段
   */
  const normalizeData = (rawData: any[]): WeatherData[] => {
    const fieldMappings: { [key: string]: string } = {
      'datetime': ['datetime', 'date', 'time', '时间', '日期'],
      'temperature': ['temperature', 'temp', 'tmean', '温度', '气温'],
      'humidity': ['humidity', 'rhum', 'rh', '湿度', '相对湿度'],
      'precipitation': ['precipitation', 'prcp', 'rain', '降水', '降雨量'],
      'windSpeed': ['windspeed', 'wind', 'wspd', '风速'],
      'pressure': ['pressure', 'pres', 'slp', '气压', '海平面气压'],
      'solarIrradiance': ['solarirradiance', 'solar', 'ghi', 'irradiance', '辐照度', '太阳辐照度']
    };

    const normalizedData: WeatherData[] = [];
    
    for (const row of rawData) {
      const normalizedRow: any = {};
      
      // 尝试映射字段
      for (const [standardField, possibleNames] of Object.entries(fieldMappings)) {
        for (const possibleName of possibleNames) {
          if (row[possibleName] !== undefined) {
            let value = row[possibleName];
            
            if (standardField === 'datetime') {
              // 处理日期时间字段
              try {
                const date = new Date(value);
                if (isNaN(date.getTime())) {
                  throw new Error('无效的日期格式');
                }
                normalizedRow[standardField] = date.toISOString();
              } catch {
                throw new Error(`无效的日期格式: ${value}`);
              }
            } else {
              // 处理数值字段
              const numValue = parseFloat(value);
              if (isNaN(numValue)) {
                normalizedRow[standardField] = 0; // 默认值
              } else {
                normalizedRow[standardField] = numValue;
              }
            }
            break;
          }
        }
      }

      // 检查必需字段
      if (!normalizedRow.datetime) {
        throw new Error('缺少日期时间字段，请确保数据包含 datetime、date 或 time 列');
      }

      // 设置默认值
      normalizedRow.temperature = normalizedRow.temperature || 0;
      normalizedRow.humidity = normalizedRow.humidity || 50;
      normalizedRow.precipitation = normalizedRow.precipitation || 0;
      normalizedRow.windSpeed = normalizedRow.windSpeed || 0;
      normalizedRow.pressure = normalizedRow.pressure || 1013;
      // 太阳辐照度为可选字段，不设置默认值

      normalizedData.push(normalizedRow as WeatherData);
    }

    return normalizedData;
  };

  /**
   * 分析数据并生成配置
   */
  const analyzeData = (data: WeatherData[]): ParsedData => {
    if (data.length === 0) {
      throw new Error('数据为空');
    }

    // 计算日期范围
    const dates = data.map(d => new Date(d.datetime));
    const startDate = new Date(Math.min(...dates.map(d => d.getTime())));
    const endDate = new Date(Math.max(...dates.map(d => d.getTime())));

    // 计算数据质量
    const totalFields = 6; // datetime, temperature, humidity, precipitation, windSpeed, pressure
    let missingFieldsCount = 0;
    const missingFields: string[] = [];

    // 检查数据完整性
    const sampleSize = Math.min(100, data.length);
    for (let i = 0; i < sampleSize; i++) {
      const item = data[i];
      if (!item.temperature && item.temperature !== 0) missingFieldsCount++;
      if (!item.humidity && item.humidity !== 0) missingFieldsCount++;
      if (!item.precipitation && item.precipitation !== 0) missingFieldsCount++;
      if (!item.windSpeed && item.windSpeed !== 0) missingFieldsCount++;
      if (!item.pressure && item.pressure !== 0) missingFieldsCount++;
    }

    const completeness = ((totalFields * sampleSize - missingFieldsCount) / (totalFields * sampleSize)) * 100;

    // 计算温度统计用于阈值推荐
    const temperatures = data.map(d => d.temperature).filter(t => t !== undefined && t !== null);
    const avgTemp = temperatures.reduce((sum, temp) => sum + temp, 0) / temperatures.length;
    const maxTemp = Math.max(...temperatures);
    const minTemp = Math.min(...temperatures);

    // 生成推荐配置
    const config: Partial<WeatherConfig> = {
      locationName: locationSettings.locationName || '上传数据地区',
      latitude: locationSettings.latitude,
      longitude: locationSettings.longitude,
      timezone: locationSettings.timezone,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      highTempThreshold: thresholdSettings.highTempThreshold,
      lowTempThreshold: thresholdSettings.lowTempThreshold,
      highHumidityThreshold: thresholdSettings.highHumidityThreshold,
      lowHumidityThreshold: thresholdSettings.lowHumidityThreshold
    };

    return {
      data,
      config,
      summary: {
        totalRecords: data.length,
        dateRange: {
          start: startDate.toLocaleDateString('zh-CN'),
          end: endDate.toLocaleDateString('zh-CN')
        },
        dataQuality: {
          completeness: Math.round(completeness * 10) / 10,
          missingFields
        }
      }
    };
  };

  /**
   * 处理文件上传
   */
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadStatus('uploading');
    setError(null);
    setProgress(0);

    try {
      // 验证文件类型
      const allowedTypes = ['.csv', '.txt', '.xlsx', '.xls'];
      const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
      
      if (!allowedTypes.includes(fileExtension)) {
        throw new Error(`不支持的文件格式: ${fileExtension}。支持的格式: ${allowedTypes.join(', ')}`);
      }

      // 验证文件大小（限制为10MB）
      if (file.size > 10 * 1024 * 1024) {
        throw new Error('文件大小超过限制（10MB）');
      }

      setProgress(20);
      setUploadStatus('processing');

      // 解析文件
      let rawData: any[];
      if (fileExtension === '.csv' || fileExtension === '.txt') {
        // 读取文本文件内容
        const content = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.onerror = () => reject(new Error('文件读取失败'));
          reader.readAsText(file, 'UTF-8');
        });
        
        setProgress(40);
        rawData = parseCSV(content);
      } else if (fileExtension === '.xlsx' || fileExtension === '.xls') {
        setProgress(30);
        rawData = await parseExcel(file);
        setProgress(50);
      } else {
        throw new Error('不支持的文件格式');
      }

      setProgress(60);

      // 标准化数据
      const normalizedData = normalizeData(rawData);
      
      setProgress(80);

      // 分析数据
      const analyzedData = analyzeData(normalizedData);
      
      setProgress(100);
      setParsedData(analyzedData);
      setUploadStatus('success');
      setShowSettings(true); // 上传成功后显示设置区域

    } catch (err) {
      setError(err instanceof Error ? err.message : '文件处理失败');
      setUploadStatus('error');
    }
  };

  /**
   * 开始数据分析
   */
  const handleStartAnalysis = () => {
    if (!parsedData) return;

    // 验证必要字段
    if (!locationSettings.locationName.trim()) {
      setError('请输入地区名称');
      return;
    }

    const fullConfig: WeatherConfig = {
      locationName: locationSettings.locationName,
      latitude: locationSettings.latitude,
      longitude: locationSettings.longitude,
      timezone: locationSettings.timezone,
      startDate: parsedData.config.startDate || '',
      endDate: parsedData.config.endDate || '',
      highTempThreshold: thresholdSettings.highTempThreshold,
      lowTempThreshold: thresholdSettings.lowTempThreshold,
      highHumidityThreshold: thresholdSettings.highHumidityThreshold,
      lowHumidityThreshold: thresholdSettings.lowHumidityThreshold
    };

    onDataAnalyzed(fullConfig, parsedData.data);
  };

  /**
   * 重置上传状态
   */
  const handleReset = () => {
    setUploadStatus('idle');
    setProgress(0);
    setError(null);
    setParsedData(null);
    setShowPreview(false);
    setShowSettings(false);
    setLocationSettings({
      locationName: '',
      latitude: 0,
      longitude: 0,
      timezone: 'UTC'
    });
    setThresholdSettings({
      highTempThreshold: 30,
      lowTempThreshold: -10,
      highHumidityThreshold: 70,
      lowHumidityThreshold: 40
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  /**
   * 预设地区配置
   */
  const presetLocations = [
    { name: 'Ljubljana', lat: 46.2167, lng: 14.4833, timezone: 'Europe/Ljubljana' },
    { name: 'Beijing', lat: 39.9042, lng: 116.4074, timezone: 'Asia/Shanghai' },
    { name: 'Shanghai', lat: 31.2304, lng: 121.4737, timezone: 'Asia/Shanghai' },
    { name: 'New York', lat: 40.7128, lng: -74.0060, timezone: 'America/New_York' },
    { name: 'London', lat: 51.5074, lng: -0.1278, timezone: 'Europe/London' },
    { name: 'Paris', lat: 48.8566, lng: 2.3522, timezone: 'Europe/Paris' },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503, timezone: 'Asia/Tokyo' },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093, timezone: 'Australia/Sydney' }
  ];

  /**
   * 处理预设地区选择
   */
  const handleLocationSelect = (locationName: string) => {
    const location = presetLocations.find(loc => loc.name === locationName);
    if (location) {
      setLocationSettings({
        locationName: location.name,
        latitude: location.lat,
        longitude: location.lng,
        timezone: location.timezone
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* 文件上传区域 */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Upload className="w-5 h-5 text-green-400" />
            <CardTitle className="text-white">上传天气数据文件</CardTitle>
          </div>
          <CardDescription className="text-slate-300">
            支持CSV、Excel格式的天气数据文件，最大10MB
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 文件格式说明 */}
          <div className="bg-slate-700/30 rounded-lg p-4">
            <h4 className="text-white font-medium mb-3 flex items-center space-x-2">
              <FileText className="w-4 h-4 text-blue-400" />
              <span>数据格式要求</span>
            </h4>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-300">
                <div>
                  <p className="font-medium text-slate-200 mb-2">必需字段：</p>
                  <ul className="space-y-1">
                    <li>• datetime/date/time - 日期时间</li>
                    <li>• temperature/temp - 温度 (°C)</li>
                  </ul>
                </div>
                <div>
                  <p className="font-medium text-slate-200 mb-2">可选字段：</p>
                  <ul className="space-y-1">
                    <li>• humidity/rh - 湿度 (%)</li>
                    <li>• precipitation/rain - 降水量 (mm)</li>
                    <li>• windspeed/wind - 风速 (m/s)</li>
                    <li>• pressure/pres - 气压 (hPa)</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-slate-600/30 rounded-lg p-3">
                <p className="font-medium text-slate-200 mb-2 flex items-center space-x-2">
                  <FileSpreadsheet className="w-4 h-4 text-green-400" />
                  <span>支持格式：</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="border-green-400 text-green-400">
                    CSV (.csv)
                  </Badge>
                  <Badge variant="outline" className="border-blue-400 text-blue-400">
                    Excel (.xlsx)
                  </Badge>
                  <Badge variant="outline" className="border-blue-400 text-blue-400">
                    Excel (.xls)
                  </Badge>
                  <Badge variant="outline" className="border-gray-400 text-gray-400">
                    Text (.txt)
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* 文件上传控件 */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="file-upload" className="text-slate-300">
                选择文件
              </Label>
              <Input
                id="file-upload"
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt,.xlsx,.xls"
                onChange={handleFileUpload}
                disabled={uploadStatus === 'uploading' || uploadStatus === 'processing'}
                className="bg-slate-800 border-slate-600 text-white file:bg-slate-700 file:text-white file:border-0 file:mr-4"
              />
            </div>

            {/* 上传进度 */}
            {(uploadStatus === 'uploading' || uploadStatus === 'processing') && (
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <FileSpreadsheet className="w-4 h-4 text-blue-400 animate-pulse" />
                  <span className="text-white text-sm">
                    {uploadStatus === 'uploading' ? '正在上传文件...' : '正在处理数据...'}
                  </span>
                </div>
                <Progress value={progress} className="w-full" />
                <p className="text-xs text-slate-400">进度: {progress}%</p>
              </div>
            )}

            {/* 错误提示 */}
            {error && (
              <Alert className="bg-red-900/20 border-red-800">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-300">
                  {error}
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 数据预览和分析 */}
      {parsedData && uploadStatus === 'success' && (
        <div className="space-y-6">
          {/* 地区信息和阈值设置 */}
          {showSettings && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* 地区信息设置 */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-5 h-5 text-blue-400" />
                    <CardTitle className="text-white">地区信息</CardTitle>
                  </div>
                  <CardDescription className="text-slate-300">
                    请设置数据对应的地理位置信息
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="location-select" className="text-slate-300 text-sm">
                      快速选择地区
                    </Label>
                    <select
                      className="w-full bg-slate-800 border border-slate-600 text-white rounded-md px-3 py-2"
                      onChange={(e) => e.target.value && handleLocationSelect(e.target.value)}
                      value=""
                    >
                      <option value="">选择预设地区</option>
                      {presetLocations.map(location => (
                        <option key={location.name} value={location.name}>
                          {location.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="locationName" className="text-slate-300 text-sm">
                      地区名称 *
                    </Label>
                    <Input
                      id="locationName"
                      value={locationSettings.locationName}
                      onChange={(e) => setLocationSettings(prev => ({ ...prev, locationName: e.target.value }))}
                      className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400"
                      placeholder="输入地区名称"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="latitude" className="text-slate-300 text-sm">
                        纬度
                      </Label>
                      <Input
                        id="latitude"
                        type="number"
                        step="0.0001"
                        value={locationSettings.latitude}
                        onChange={(e) => setLocationSettings(prev => ({ ...prev, latitude: parseFloat(e.target.value) || 0 }))}
                        className="bg-slate-800 border-slate-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="longitude" className="text-slate-300 text-sm">
                        经度
                      </Label>
                      <Input
                        id="longitude"
                        type="number"
                        step="0.0001"
                        value={locationSettings.longitude}
                        onChange={(e) => setLocationSettings(prev => ({ ...prev, longitude: parseFloat(e.target.value) || 0 }))}
                        className="bg-slate-800 border-slate-600 text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="timezone" className="text-slate-300 text-sm">
                      时区
                    </Label>
                    <Input
                      id="timezone"
                      value={locationSettings.timezone}
                      onChange={(e) => setLocationSettings(prev => ({ ...prev, timezone: e.target.value }))}
                      className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400"
                      placeholder="例如: Asia/Shanghai"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* 阈值设置 */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Thermometer className="w-5 h-5 text-orange-400" />
                    <CardTitle className="text-white">分析阈值</CardTitle>
                  </div>
                  <CardDescription className="text-slate-300">
                    设置温度和湿度的高低阈值用于统计分析
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Thermometer className="w-4 h-4 text-orange-400" />
                      <span className="text-sm text-white">温度阈值 (°C)</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="highTempThreshold" className="text-slate-400 text-xs">
                          高温阈值
                        </Label>
                        <Input
                          id="highTempThreshold"
                          type="number"
                          value={thresholdSettings.highTempThreshold}
                          onChange={(e) => setThresholdSettings(prev => ({ ...prev, highTempThreshold: parseFloat(e.target.value) || 0 }))}
                          className="bg-slate-800 border-slate-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lowTempThreshold" className="text-slate-400 text-xs">
                          低温阈值
                        </Label>
                        <Input
                          id="lowTempThreshold"
                          type="number"
                          value={thresholdSettings.lowTempThreshold}
                          onChange={(e) => setThresholdSettings(prev => ({ ...prev, lowTempThreshold: parseFloat(e.target.value) || 0 }))}
                          className="bg-slate-800 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Droplets className="w-4 h-4 text-blue-400" />
                      <span className="text-sm text-white">湿度阈值 (%)</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="highHumidityThreshold" className="text-slate-400 text-xs">
                          高湿度阈值
                        </Label>
                        <Input
                          id="highHumidityThreshold"
                          type="number"
                          value={thresholdSettings.highHumidityThreshold}
                          onChange={(e) => setThresholdSettings(prev => ({ ...prev, highHumidityThreshold: parseFloat(e.target.value) || 0 }))}
                          className="bg-slate-800 border-slate-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lowHumidityThreshold" className="text-slate-400 text-xs">
                          低湿度阈值
                        </Label>
                        <Input
                          id="lowHumidityThreshold"
                          type="number"
                          value={thresholdSettings.lowHumidityThreshold}
                          onChange={(e) => setThresholdSettings(prev => ({ ...prev, lowHumidityThreshold: parseFloat(e.target.value) || 0 }))}
                          className="bg-slate-800 border-slate-600 text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-600">
                    <div className="text-xs text-slate-400 space-y-1">
                      <p>• 高温/低温阈值用于统计极端温度出现频次</p>
                      <p>• 高湿度/低湿度阈值用于分析湿度分布特征</p>
                      <p>• 建议根据当地气候特征设置合理阈值</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* 数据概览 */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Check className="w-5 h-5 text-green-400" />
                  <CardTitle className="text-white">数据上传成功</CardTitle>
                </div>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => setShowPreview(!showPreview)}
                    variant="outline"
                    size="sm"
                    className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    {showPreview ? '隐藏预览' : '数据预览'}
                  </Button>
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    size="sm"
                    className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    重新上传
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="text-center p-4 bg-slate-700/30 rounded-lg">
                  <Calendar className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{parsedData.summary.totalRecords}</p>
                  <p className="text-sm text-slate-300">数据记录数</p>
                </div>
                <div className="text-center p-4 bg-slate-700/30 rounded-lg">
                  <MapPin className="w-6 h-6 text-green-400 mx-auto mb-2" />
                  <p className="text-lg font-bold text-white">
                    {parsedData.summary.dateRange.start} - {parsedData.summary.dateRange.end}
                  </p>
                  <p className="text-sm text-slate-300">时间范围</p>
                </div>
                <div className="text-center p-4 bg-slate-700/30 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-purple-400 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-white">{parsedData.summary.dataQuality.completeness}%</p>
                  <p className="text-sm text-slate-300">数据完整度</p>
                </div>
              </div>

              <Separator className="bg-slate-600 my-4" />

              <div className="flex justify-center space-x-4">
                <Button
                  onClick={handleStartAnalysis}
                  disabled={!locationSettings.locationName.trim()}
                  className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  开始气候分析
                </Button>
                {!locationSettings.locationName.trim() && (
                  <p className="text-sm text-yellow-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    请先设置地区信息
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 数据预览表格 */}
          {showPreview && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">数据预览</CardTitle>
                <CardDescription className="text-slate-300">
                  显示前10条记录
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-slate-300">
                    <thead>
                      <tr className="border-b border-slate-600">
                        <th className="text-left py-2 px-3">日期时间</th>
                        <th className="text-center py-2 px-3">温度(°C)</th>
                        <th className="text-center py-2 px-3">湿度(%)</th>
                        <th className="text-center py-2 px-3">降水(mm)</th>
                        <th className="text-center py-2 px-3">风速(m/s)</th>
                        <th className="text-center py-2 px-3">气压(hPa)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {parsedData.data.slice(0, 10).map((item, index) => (
                        <tr key={index} className="border-b border-slate-700">
                          <td className="py-2 px-3 text-white">
                            {new Date(item.datetime).toLocaleString('zh-CN')}
                          </td>
                          <td className="text-center py-2 px-3 text-red-400">
                            {item.temperature.toFixed(1)}
                          </td>
                          <td className="text-center py-2 px-3 text-blue-400">
                            {item.humidity.toFixed(1)}
                          </td>
                          <td className="text-center py-2 px-3 text-green-400">
                            {item.precipitation.toFixed(1)}
                          </td>
                          <td className="text-center py-2 px-3 text-purple-400">
                            {item.windSpeed.toFixed(1)}
                          </td>
                          <td className="text-center py-2 px-3 text-yellow-400">
                            {item.pressure.toFixed(1)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* 示例数据下载 */}
      <Card className="bg-slate-800/50 border-slate-700 border-dashed">
        <CardContent className="p-6 text-center">
          <Download className="w-12 h-12 text-slate-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-300 mb-2">
            需要示例数据？
          </h3>
          <p className="text-slate-400 mb-4">
            下载标准格式的示例文件，了解正确的数据格式
          </p>
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-center">
            <Button
              onClick={() => {
                // 生成示例CSV内容
                const sampleData = [
                  'datetime,temperature,humidity,precipitation,windspeed,pressure',
                  '2024-01-01 00:00:00,5.2,65,0.0,3.5,1013.2',
                  '2024-01-01 01:00:00,4.8,67,0.0,3.2,1013.5',
                  '2024-01-01 02:00:00,4.5,69,0.1,2.8,1013.8',
                  '2024-01-01 03:00:00,4.2,71,0.2,2.5,1014.1',
                  '2024-01-01 04:00:00,3.9,73,0.0,2.2,1014.4',
                  '2024-01-01 05:00:00,3.7,75,0.0,2.0,1014.6',
                  '2024-01-01 06:00:00,4.1,73,0.0,2.3,1014.3'
                ].join('\n');

                // 创建下载链接
                const blob = new Blob([sampleData], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'weather_sample.csv';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
              }}
              variant="outline"
              className="bg-transparent border-green-500 text-green-400 hover:bg-green-900/20"
            >
              <Download className="w-4 h-4 mr-2" />
              下载CSV示例
            </Button>
            
            <Button
              onClick={async () => {
                try {
                  // 动态导入xlsx库创建Excel文件
                  const XLSX = await import('xlsx');
                  
                  // 创建示例数据
                  const sampleData = [
                    {
                      datetime: '2024-01-01 00:00:00',
                      temperature: 5.2,
                      humidity: 65,
                      precipitation: 0.0,
                      windspeed: 3.5,
                      pressure: 1013.2
                    },
                    {
                      datetime: '2024-01-01 01:00:00',  
                      temperature: 4.8,
                      humidity: 67,
                      precipitation: 0.0,
                      windspeed: 3.2,
                      pressure: 1013.5
                    },
                    {
                      datetime: '2024-01-01 02:00:00',
                      temperature: 4.5,
                      humidity: 69,
                      precipitation: 0.1,
                      windspeed: 2.8,
                      pressure: 1013.8
                    },
                    {
                      datetime: '2024-01-01 03:00:00',
                      temperature: 4.2,
                      humidity: 71,
                      precipitation: 0.2,
                      windspeed: 2.5,
                      pressure: 1014.1
                    },
                    {
                      datetime: '2024-01-01 04:00:00',
                      temperature: 3.9,
                      humidity: 73,
                      precipitation: 0.0,
                      windspeed: 2.2,
                      pressure: 1014.4
                    },
                    {
                      datetime: '2024-01-01 05:00:00',
                      temperature: 3.7,
                      humidity: 75,
                      precipitation: 0.0,
                      windspeed: 2.0,
                      pressure: 1014.6
                    },
                    {
                      datetime: '2024-01-01 06:00:00',
                      temperature: 4.1,
                      humidity: 73,
                      precipitation: 0.0,
                      windspeed: 2.3,
                      pressure: 1014.3
                    }
                  ];
                  
                  // 创建工作表
                  const worksheet = XLSX.utils.json_to_sheet(sampleData);
                  
                  // 创建工作簿
                  const workbook = XLSX.utils.book_new();
                  XLSX.utils.book_append_sheet(workbook, worksheet, 'WeatherData');
                  
                  // 生成Excel文件
                  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
                  
                  // 创建下载链接
                  const blob = new Blob([excelBuffer], { 
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
                  });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'weather_sample.xlsx';
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                } catch (error) {
                  console.error('生成Excel文件失败:', error);
                  alert('生成Excel文件失败，请稍后再试');
                }
              }}
              variant="outline"
              className="bg-transparent border-blue-500 text-blue-400 hover:bg-blue-900/20"
            >
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              下载Excel示例
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
