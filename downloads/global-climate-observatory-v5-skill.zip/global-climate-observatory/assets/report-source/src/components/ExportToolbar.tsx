/** 
 * 导出工具栏
 * - 功能：导出长图片、打印页面
 * - 自适应深浅模式
 */
import React, { useState } from 'react'
import { Button } from './ui/button'
import { Card, CardContent } from './ui/card'
import { Image as ImageIcon, Loader2, Printer } from 'lucide-react'
import type { WeatherConfig } from '../pages/Home'
import { exportElementToLongImage } from '../utils/exporters'

/** 组件 Props */
interface ExportToolbarProps {
  /** 导出根区域（分析结果容器） */
  rootRef: React.RefObject<HTMLElement>
  /** 配置，用于文件名 */
  config: WeatherConfig
  /** 数据条数，用于禁用态与提示 */
  dataCount: number
}

/**
 * 导出工具栏组件
 * - 禁用逻辑：仅依赖是否存在数据和是否正在执行
 * - 点击时解析导出根节点：rootRef.current → [data-export-start="true"] → [data-export="weather-content"]
 * - 打印页面：调用 window.print()，并在打印样式中缩放为 90%
 */
export default function ExportToolbar({ rootRef, config, dataCount }: ExportToolbarProps) {
  const [running, setRunning] = useState<'none' | 'img' | 'print'>('none')

  /** 是否允许点击：仅依赖数据是否存在和执行状态 */
  const disabled = !dataCount || running !== 'none'
  const baseName = `${config.locationName}_气候分析`

  /** 获取导出根节点（点击时获取） */
  const getRootEl = (): HTMLElement | null => {
    const direct = rootRef.current
    if (direct) return direct
    const byAttr =
      (document.querySelector('[data-export-start="true"]') ||
        document.querySelector('[data-export="weather-content"]')) as HTMLElement | null
    return byAttr
  }

  /** 导出长图片 */
  const handleExportImage = async () => {
    const root = getRootEl()
    if (!root) {
      alert('未找到分析区域，请确认页面中存在 data-export-start 或 data-export="weather-content" 的容器。')
      return
    }
    try {
      setRunning('img')
      await exportElementToLongImage(root, {
        fileName: baseName,
        background: 'matchTheme',
        scale: 2,
        maxSingleImageHeight: 16000,
        sliceHeight: 2200,
      })
    } catch (e) {
      console.error(e)
      alert(e instanceof Error ? e.message : '导出长图片失败，请重试')
    } finally {
      setRunning('none')
    }
  }

  /** 打印页面：滚至顶部，轻量稳定布局，再触发原生打印 */
  const handlePrint = async () => {
    try {
      setRunning('print')
      // 滚动到页首，避免从中间开始打印
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior })
      // 轻量稳定：触发一次 resize + 两帧 RAF
      window.dispatchEvent(new Event('resize'))
      await new Promise((r) => requestAnimationFrame(() => r(undefined)))
      await new Promise((r) => requestAnimationFrame(() => r(undefined)))
      // 小延时确保布局稳定
      setTimeout(() => window.print(), 50)
    } finally {
      // 打印是阻塞式对话框，返回后复位状态
      setTimeout(() => setRunning('none'), 300)
    }
  }

  return (
    <Card className="bg-white border-slate-200 dark:bg-slate-800/60 dark:border-slate-700">
      <CardContent className="p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="text-sm text-slate-600 dark:text-slate-300">
          导出长图片或直接打印整页（打印时自动缩放至 90%）
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleExportImage}
            disabled={disabled}
            className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white"
          >
            {running === 'img' ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                导出中...
              </>
            ) : (
              <>
                <ImageIcon className="w-4 h-4 mr-2" />
                导出长图片
              </>
            )}
          </Button>

          <Button
            onClick={handlePrint}
            disabled={!dataCount || running !== 'none'}
            variant="outline"
            className="bg-white text-slate-900 border-slate-300 hover:bg-slate-50 dark:bg-transparent dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
          >
            {running === 'print' ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                正在准备...
              </>
            ) : (
              <>
                <Printer className="w-4 h-4 mr-2" />
                打印页面
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
