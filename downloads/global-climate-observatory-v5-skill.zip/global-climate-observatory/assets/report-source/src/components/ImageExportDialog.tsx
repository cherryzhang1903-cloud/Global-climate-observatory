/**
 * 导出图片对话框组件（增强：支持手动选择范围 + 确认后自动导出）
 * - 新增“确认后自动开始导出”开关（默认开启）
 * - 覆盖层确认后自动关闭并立即按所选范围开始导出（可关闭该开关以手动触发）
 */

import React, { useMemo, useRef, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import {
  Image as ImageIcon,
  Download,
  Settings,
  CheckCircle,
  AlertCircle,
  Scissors,
  ClipboardCopy,
  Ruler,
} from 'lucide-react';
import type { WeatherConfig } from '../pages/Home';
import RangeSelectOverlay, { RangeSelection } from './RangeSelectOverlay';

/**
 * 导出选项接口
 */
interface ImageExportOptions {
  fileName: string;
  format: 'png' | 'jpeg';
  scale: 1 | 1.5 | 2;
  background: 'matchTheme' | 'transparent';
  quality: number; // 仅对 jpeg 有效，0-1
  splitLongImage: boolean; // 是否分段导出多张
  sliceHeight: number; // 分段导出时的每张高度（画布像素）
}

/** 下载 dataURL 工具函数 */
function downloadDataURL(fileName: string, dataUrl: string): void {
  const a = document.createElement('a');
  a.href = dataUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** 等待一段时间 */
function sleep(ms: number): Promise<void> {
  return new Promise((res) => setTimeout(res, ms));
}

/** 等待若干动画帧 */
async function nextFrames(count = 2): Promise<void> {
  for (let i = 0; i < count; i++) {
    await new Promise((res) => requestAnimationFrame(() => res(undefined)));
  }
}

/** 触发多次 resize，以强制图表完成自适应布局 */
async function pulseResize(times = 2, gap = 80): Promise<void> {
  for (let i = 0; i < times; i++) {
    window.dispatchEvent(new Event('resize'));
    await sleep(gap);
  }
}

/**
 * 自动滚动遍历分析区域，确保懒加载/图表布局完成
 * 逻辑：滚动到起点 -> 按视口高度步进滚动至底部 -> 回到起点 -> 多次 resize + 两帧 RAF
 */
async function autoScrollAndStabilize(root: HTMLElement): Promise<void> {
  const rect = root.getBoundingClientRect();
  const startTop = window.scrollY + rect.top;
  const rootHeight = Math.max(rect.height, root.scrollHeight, root.clientHeight);

  // 滚到起点
  window.scrollTo({ top: startTop });
  window.dispatchEvent(new Event('scroll'));
  await sleep(120);

  const step = Math.max(200, Math.floor(window.innerHeight * 0.9));
  const endTop = startTop + rootHeight - window.innerHeight * 0.5;

  for (let y = startTop; y < endTop; y += step) {
    window.scrollTo({ top: y });
    window.dispatchEvent(new Event('scroll'));
    await sleep(120);
  }

  // 回到起点
  window.scrollTo({ top: startTop });
  window.dispatchEvent(new Event('scroll'));
  await sleep(120);

  // 等待图片加载
  const imgs = Array.from(root.querySelectorAll('img'));
  await Promise.all(
    imgs.map((img) => {
      if ((img as HTMLImageElement).complete) return Promise.resolve();
      return new Promise<void>((res) => {
        img.addEventListener('load', () => res(), { once: true });
        img.addEventListener('error', () => res(), { once: true });
      });
    })
  );

  // 强制布局稳定
  await pulseResize(2, 80);
  await nextFrames(2);
}

/**
 * 计算容器内实际内容底部（相对容器顶部的 CSS 像素），扣除 padding-bottom，避免底部空白
 */
function getVisualContentHeight(container: HTMLElement): number {
  const containerRect = container.getBoundingClientRect();
  let maxBottom = 0;
  const all = container.querySelectorAll('*');

  // 遍历可见后代，计算相对容器顶部的最大 bottom，得到真实底部
  all.forEach((el) => {
    const node = el as HTMLElement;
    const style = window.getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden') return;
    if (!node.offsetParent && node !== container) return;
    const rect = node.getBoundingClientRect();
    const bottom = rect.bottom - containerRect.top;
    if (bottom > maxBottom) maxBottom = bottom;
  });

  const styles = window.getComputedStyle(container);
  const paddingBottom = parseFloat(styles.paddingBottom || '0') || 0;

  // 至少不小于可见高度（扣除 padding-bottom）
  const clientH = container.clientHeight; // 含 padding
  const base = Math.max(maxBottom - paddingBottom, clientH - paddingBottom, 0);
  return Math.ceil(base);
}

/** 尝试复制图片到剪贴板 */
async function copyCanvasToClipboard(
  canvas: HTMLCanvasElement,
  mime: 'image/png' | 'image/jpeg',
  quality?: number
) {
  if (!('clipboard' in navigator) || !(window as any).ClipboardItem) {
    throw new Error('当前浏览器不支持直接复制到剪贴板');
  }
  const blob: Blob | null = await new Promise((res) =>
    canvas.toBlob(res as any, mime, quality)
  );
  if (!blob) throw new Error('生成图片失败，无法复制');
  const item = new (window as any).ClipboardItem({ [mime]: blob });
  await (navigator as any).clipboard.write([item]);
}

/** 组件 props */
interface ImageExportDialogProps {
  config: WeatherConfig;
  dataCount: number;
}

/**
 * 导出图片对话框组件（新增：手动选择范围 + 确认后自动导出）
 */
export default function ImageExportDialog({
  config,
  dataCount,
}: ImageExportDialogProps) {
  const [open, setOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>(
    'idle'
  );
  const [error, setError] = useState<string | null>(null);
  const lastCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [options, setOptions] = useState<ImageExportOptions>({
    fileName: `${config.locationName}_气候分析_图片导出`,
    format: 'png',
    scale: 2,
    background: 'matchTheme',
    quality: 0.92,
    splitLongImage: false,
    sliceHeight: 2200,
  });

  /** 手动范围（CSS 像素，相对导出根顶部），null 表示导出全部有效内容 */
  const [manualRange, setManualRange] = useState<RangeSelection | null>(null);
  /** 是否显示范围选择覆盖层 */
  const [showSelector, setShowSelector] = useState(false);
  /** 覆盖层确认后自动导出 */
  const [autoExportAfterSelect, setAutoExportAfterSelect] = useState<boolean>(true);

  /** 重置弹窗状态 */
  const reset = () => {
    setStatus('idle');
    setExporting(false);
    setProgress(0);
    setError(null);
    lastCanvasRef.current = null;
    setManualRange(null);
    setOptions((prev) => ({
      ...prev,
      fileName: `${config.locationName}_气候分析_图片导出`,
    }));
    setAutoExportAfterSelect(true);
  };

  /** 估算文件大小（基于裁剪后区域） */
  const estimateFileSize = useMemo(() => {
    return () => {
      const root = (document.querySelector('[data-export-start="true"]') ||
        document.querySelector('[data-export="weather-content"]')) as
        | HTMLElement
        | null;
      if (!root) return '未知';
      const widthCss = root.getBoundingClientRect().width || 0;
      let heightCss = getVisualContentHeight(root);
      if (manualRange) {
        const h = Math.max(
          0,
          Math.min(heightCss, manualRange.end) - Math.max(0, manualRange.start)
        );
        heightCss = Math.max(0, h);
      }
      if (!widthCss || !heightCss) return '未知';

      const pixels = widthCss * heightCss * Math.pow(Number(options.scale), 2);
      let mbPerMP =
        options.format === 'png' ? 1.05 : 0.5 * (options.quality / 0.92);
      const sizeMB = (pixels / 1_000_000) * mbPerMP;
      if (options.splitLongImage) {
        // 分段导出多图，整体体积略增加
        return `约 ${(sizeMB * 1.1).toFixed(1)} MB（分段多图）`;
      }
      return `约 ${sizeMB.toFixed(1)} MB`;
    };
  }, [options.format, options.quality, options.scale, options.splitLongImage, manualRange]);

  /** 选择范围：打开覆盖层 */
  const openSelector = async () => {
    setError(null);
    const root = (document.querySelector('[data-export-start="true"]') ||
      document.querySelector('[data-export="weather-content"]')) as
      | HTMLElement
      | null;
    if (!root) {
      setError('未找到分析区域（缺少 data-export-start 或 data-export="weather-content"）');
      return;
    }
    setShowSelector(true);
  };

  /**
   * 执行导出为图片（支持手动范围覆盖）
   * @param rangeOverride 若传入则优先使用该范围，否则使用当前 state 的 manualRange
   */
  const handleExport = async (rangeOverride?: RangeSelection | null) => {
    try {
      setExporting(true);
      setStatus('processing');
      setProgress(5);
      setError(null);

      const root = (document.querySelector('[data-export-start="true"]') ||
        document.querySelector('[data-export="weather-content"]')) as
        | HTMLElement
        | null;

      if (!root) {
        throw new Error(
          '未找到可导出的分析区域（缺少 data-export-start 或 data-export="weather-content"）'
        );
      }

      // 自动滚动与稳定
      setProgress(12);
      await autoScrollAndStabilize(root);
      setProgress(22);

      const html2canvasModule = await import('html2canvas');
      const html2canvas =
        html2canvasModule.default as typeof import('html2canvas').default;

      // 直接渲染“起始容器”作为根
      const scale = options.scale;
      const isDark = document.documentElement.classList.contains('dark');\n      const bg = options.background === 'matchTheme' ? (isDark ? '#0f172a' : '#ffffff') : 'transparent';

      setProgress(32);
      const canvas = await html2canvas(root, {
        useCORS: true,
        allowTaint: false,
        backgroundColor: bg,
        scale, // 清晰度
        scrollX: 0,
        scrollY: 0,
        logging: false,
        foreignObjectRendering: true,
        /**
         * 仅将“导出根容器之外”的 sticky 元素静态化，避免遮挡；保持根容器内几何不变，确保选择坐标与导出一致
         */
        onclone: (doc) => {
          const cloneRoot =
            (doc.querySelector('[data-export-start="true"]') ||
              doc.querySelector('[data-export="weather-content"]')) as
              | HTMLElement
              | null;
          const stickyNodes = Array.from(
            doc.querySelectorAll<HTMLElement>('.sticky')
          );
          stickyNodes.forEach((el) => {
            if (cloneRoot && cloneRoot.contains(el)) return; // 保持根容器内部 sticky 不变
            // 仅处理容器外部 sticky，防止遮盖
            el.style.position = 'static';
            el.style.top = 'auto';
            el.style.transform = 'none';
          });
        },
      });

      setProgress(62);

      // 计算画布像素比（严格使用 BCR 宽度，确保与选择坐标一致）
      const widthCss = root.getBoundingClientRect().width || 1;
      const pixelRatio = canvas.width / Math.max(1, Math.round(widthCss));
      const visualHeightCss = getVisualContentHeight(root);

      // 计算裁剪区域（像素）
      const appliedRange = rangeOverride ?? manualRange ?? null;
      let startPx = 0;
      let cutHeightPx = Math.min(
        canvas.height,
        Math.max(1, Math.round(visualHeightCss * pixelRatio))
      );

      if (appliedRange) {
        const sCss = Math.max(0, Math.min(visualHeightCss, appliedRange.start));
        const eCss = Math.max(0, Math.min(visualHeightCss, appliedRange.end));
        const s = Math.min(sCss, eCss);
        const e = Math.max(sCss, eCss);
        startPx = Math.max(0, Math.round(s * pixelRatio));
        cutHeightPx = Math.max(
          1,
          Math.min(canvas.height - startPx, Math.round((e - s) * pixelRatio))
        );
      }

      // 输出逻辑：单张或分段多张
      const mime: 'image/png' | 'image/jpeg' =
        options.format === 'png' ? 'image/png' : 'image/jpeg';

      if (!options.splitLongImage) {
        // 单张
        const outCanvas = document.createElement('canvas');
        outCanvas.width = canvas.width;
        outCanvas.height = cutHeightPx;
        const outCtx = outCanvas.getContext('2d');
        if (!outCtx) throw new Error('导出失败：无法创建绘图上下文');
        outCtx.drawImage(
          canvas,
          0,
          startPx,
          canvas.width,
          cutHeightPx,
          0,
          0,
          outCanvas.width,
          outCanvas.height
        );

        lastCanvasRef.current = outCanvas;

        setProgress(88);
        const dataUrl =
          options.format === 'png'
            ? outCanvas.toDataURL(mime)
            : outCanvas.toDataURL(mime, options.quality);

        const date = new Date().toLocaleDateString('zh-CN').replace(/\//g, '-');
        const fileName = `${options.fileName}_${date}.${options.format}`;
        downloadDataURL(fileName, dataUrl);

        setProgress(100);
        setStatus('success');
      } else {
        // 分段多图（从 startPx 开始切）
        const slice = Math.max(600, Math.floor(options.sliceHeight)); // 画布像素
        const totalSlices = Math.max(1, Math.ceil(cutHeightPx / slice));

        for (let i = 0; i < totalSlices; i++) {
          const y = startPx + i * slice;
          const h = Math.min(slice, cutHeightPx - i * slice);

          const outCanvas = document.createElement('canvas');
          outCanvas.width = canvas.width;
          outCanvas.height = h;
          const ctx = outCanvas.getContext('2d');
          if (!ctx) throw new Error('导出失败：无法创建绘图上下文');

          ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, outCanvas.width, outCanvas.height);

          // 保存第一张用于“复制到剪贴板”
          if (i === 0) lastCanvasRef.current = outCanvas;

          const dataUrl =
            options.format === 'png'
              ? outCanvas.toDataURL(mime)
              : outCanvas.toDataURL(mime, options.quality);

          const date = new Date().toLocaleDateString('zh-CN').replace(/\//g, '-');
          const fileName = `${options.fileName}_${date}_第${i + 1}张.${options.format}`;
          downloadDataURL(fileName, dataUrl);

          const base = 62;
          const span = 36;
          setProgress(base + Math.round(((i + 1) / totalSlices) * span));
          await nextFrames(1);
        }

        setStatus('success');
      }

      // 自动收起弹窗，保留 1.5s 显示成功提示
      setTimeout(() => {
        setOpen(false);
        reset();
      }, 1500);
    } catch (e) {
      console.error(e);
      setStatus('error');
      setError(e instanceof Error ? e.message : '导出失败，请重试');
    } finally {
      setExporting(false);
    }
  };

  /** 复制到剪贴板（成功导出后可用） */
  const handleCopyToClipboard = async () => {
    try {
      const canvas = lastCanvasRef.current;
      if (!canvas) throw new Error('暂无可复制的图片，请先导出一次');
      const mime: 'image/png' | 'image/jpeg' =
        options.format === 'png' ? 'image/png' : 'image/jpeg';
      await copyCanvasToClipboard(canvas, mime, options.quality);
      setStatus('success');
    } catch (e) {
      setStatus('error');
      setError(e instanceof Error ? e.message : '复制失败，请重试');
    }
  };

  // 导出范围概览文案
  const rangeInfo = useMemo(() => {
    if (!manualRange) return '全部有效内容';
    const h = Math.max(0, manualRange.end - manualRange.start);
    return `手动范围：起 ${Math.round(manualRange.start)}px → 止 ${Math.round(
      manualRange.end
    )}px（高度 ${Math.round(h)}px）`;
  }, [manualRange]);

  return (
    <>
      <Dialog
        open={open}
        onOpenChange={(v) => {
          setOpen(v);
          if (v) reset();
        }}
      >
        <DialogTrigger asChild>
          <Button
            className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white"
            disabled={!dataCount}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            导出图片
          </Button>
        </DialogTrigger>

        <DialogContent className="max-w-xl bg-slate-800 border-slate-700 text-white max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white text-lg flex items-center">
              <ImageIcon className="w-5 h-5 mr-2 text-cyan-400" />
              导出整页为图片（支持手动范围）
            </DialogTitle>
            <DialogDescription className="text-slate-300">
              可手动选择导出起点与终点；自动滚动并稳定布局，从分析起始处导出；修复遮挡并保持与选择时一致的几何布局。
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* 导出范围 */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Ruler className="w-4 h-4 text-cyan-400" />
                <h3 className="font-medium">导出范围</h3>
              </div>

              <div className="flex flex-wrap gap-2 items-center">
                <Button
                  variant="outline"
                  className="bg-white text-slate-700 border-slate-300 hover:bg-slate-50 dark:bg-transparent dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  onClick={openSelector}
                >
                  选择范围
                </Button>
                {manualRange && (
                  <Button
                    variant="outline"
                    className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700"
                    onClick={() => setManualRange(null)}
                  >
                    清除选择
                  </Button>
                )}

                {/* 确认后自动导出开关 */}
                <div className="flex items-center gap-2 ml-2">
                  <Switch
                    checked={autoExportAfterSelect}
                    onCheckedChange={setAutoExportAfterSelect}
                    id="auto-export-switch"
                  />
                  <Label htmlFor="auto-export-switch" className="text-slate-300">
                    确认后自动开始导出
                  </Label>
                </div>

                <div className="text-xs text-slate-400">{rangeInfo}</div>
              </div>
            </div>

            <Separator className="bg-slate-600" />

            {/* 基本设置 */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Settings className="w-4 h-4 text-blue-400" />
                <h3 className="font-medium">导出选项</h3>
              </div>

              <div className="space-y-2">
                <Label htmlFor="img-filename" className="text-slate-300">
                  文件名
                </Label>
                <Input
                  id="img-filename"
                  value={options.fileName}
                  onChange={(e) =>
                    setOptions((p) => ({ ...p, fileName: e.target.value }))
                  }
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="输入文件名"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">格式</Label>
                  <select
                    value={options.format}
                    onChange={(e) =>
                      setOptions((p) => ({
                        ...p,
                        format: e.target.value as 'png' | 'jpeg',
                      }))
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white rounded-md px-3 py-2"
                  >
                    <option value="png">PNG（清晰，无损）</option>
                    <option value="jpeg">JPEG（体积更小）</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-300">清晰度（缩放）</Label>
                  <select
                    value={String(options.scale)}
                    onChange={(e) =>
                      setOptions((p) => ({
                        ...p,
                        scale: Number(e.target.value) as 1 | 1.5 | 2,
                      }))
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white rounded-md px-3 py-2"
                  >
                    <option value="1">标准 (1x)</option>
                    <option value="1.5">高清 (1.5x)</option>
                    <option value="2">超清 (2x)</option>
                  </select>
                </div>
              </div>

              {options.format === 'jpeg' && (
                <div className="space-y-2">
                  <Label className="text-slate-300">JPEG 质量</Label>
                  <input
                    type="range"
                    min={0.3}
                    max={1}
                    step={0.02}
                    value={options.quality}
                    onChange={(e) =>
                      setOptions((p) => ({ ...p, quality: Number(e.target.value) }))
                    }
                    className="w-full accent-cyan-500"
                  />
                  <div className="text-xs text-slate-400">
                    当前质量：{Math.round(options.quality * 100)}%
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">背景</Label>
                  <select
                    value={options.background}
                    onChange={(e) =>
                      setOptions((p) => ({
                        ...p,
                        background: e.target.value as 'matchTheme' | 'transparent',
                      }))
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white rounded-md px-3 py-2"
                  >
                    <option value="matchTheme">匹配主题背景（深色）</option>
                    <option value="transparent">透明背景（PNG）</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label className="text-slate-300">分段导出</Label>
                  <div className="flex items-center gap-2">
                    <input
                      id="splitLongImage"
                      type="checkbox"
                      checked={options.splitLongImage}
                      onChange={(e) =>
                        setOptions((p) => ({ ...p, splitLongImage: e.target.checked }))
                      }
                    />
                    <Label
                      htmlFor="splitLongImage"
                      className="text-slate-300 flex items-center gap-2"
                    >
                      <Scissors className="w-4 h-4 text-cyan-400" />
                      将超长内容切成多张图片
                    </Label>
                  </div>
                  {options.splitLongImage && (
                    <div className="flex items-center gap-2 mt-2">
                      <Label className="text-slate-300">每张高度(px，画布像素)</Label>
                      <Input
                        type="number"
                        value={options.sliceHeight}
                        onChange={(e) => {
                          const v = Number(e.target.value || 2200);
                          setOptions((p) => ({
                            ...p,
                            sliceHeight: Math.max(600, Math.floor(v)),
                          }));
                        }}
                        className="bg-slate-700 border-slate-600 text-white w-36"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            <Separator className="bg-slate-600" />

            {/* 预估信息（基于裁剪后区域） */}
            <div className="grid grid-cols-2 gap-4 text-sm bg-slate-700/30 rounded-md p-3">
              <div>
                <span className="text-slate-400">预估大小：</span>
                <span className="ml-2 text-white font-medium">{estimateFileSize()}</span>
              </div>
              <div>
                <span className="text-slate-400">数据记录：</span>
                <span className="ml-2 text-cyan-400 font-medium">{dataCount} 条</span>
              </div>
            </div>

            {/* 导出进度 */}
            {exporting && (
              <div className="space-y-2">
                <Progress value={progress} />
                <div className="text-xs text-slate-400">
                  进度：{progress}%（包含预滚动与布局稳定步骤）
                </div>
              </div>
            )}

            {/* 状态提示与二次操作 */}
            {status === 'success' && (
              <Alert className="bg-green-900/20 border-green-800">
                <CheckCircle className="w-4 h-4" />
                <AlertDescription className="text-green-300">
                  导出成功！如需可直接复制到剪贴板。
                </AlertDescription>
              </Alert>
            )}
            {status === 'error' && error && (
              <Alert className="bg-red-900/20 border-red-800">
                <AlertCircle className="w-4 h-4" />
                <AlertDescription className="text-red-300">{error}</AlertDescription>
              </Alert>
            )}

            {/* 操作 */}
            <div className="flex flex-wrap justify-end gap-3">
              <Button
                variant="outline"
                className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700"
                disabled={exporting}
                onClick={() => setOpen(false)}
              >
                取消
              </Button>
              <Button
                variant="outline"
                className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700"
                disabled={exporting}
                onClick={handleCopyToClipboard}
              >
                <ClipboardCopy className="w-4 h-4 mr-2" />
                复制到剪贴板
              </Button>
              <Button
                onClick={() => handleExport()}
                disabled={exporting || !dataCount}
                className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white"
              >
                {exporting ? (
                  <>
                    <Download className="w-4 h-4 mr-2 animate-pulse" />
                    导出中...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    开始导出
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 范围选择覆盖层（仅在需要时显示） */}
      {showSelector && (
        <RangeSelectOverlay
          root={
            (document.querySelector('[data-export-start="true"]') ||
              document.querySelector('[data-export="weather-content"]')) as HTMLElement
          }
          initial={manualRange}
          onCancel={() => setShowSelector(false)}
          onConfirm={(range) => {
            setManualRange(range);
            setShowSelector(false);
            // 若用户开启“确认后自动导出”，则立刻按该范围开始导出
            if (autoExportAfterSelect && !exporting) {
              // 略延迟确保覆盖层卸载完成
              setTimeout(() => {
                handleExport(range);
              }, 60);
            }
          }}
        />
      )}
    </>
  );
}
