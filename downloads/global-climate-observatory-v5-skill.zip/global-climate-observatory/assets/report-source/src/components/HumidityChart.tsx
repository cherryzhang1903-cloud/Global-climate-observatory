import {aggregateReport,valid,max,min} from '../utils/stats.mjs';
/**
 * 湿度图表组件
 * 显示温湿度关系和湿度变化趋势
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ReferenceLine } from 'recharts';
import { Droplets, Thermometer, TrendingUp, TrendingDown } from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface HumidityChartProps {
  data: WeatherData[];
  config: WeatherConfig;
}

/**
 * 湿度图表组件
 */
export default function HumidityChart({ data, config }: HumidityChartProps) {
  // 处理月度数据
  const jointRows=data.filter(r=>valid(r.temperature)&&valid(r.humidity));
  const processMonthlyData=()=>aggregateReport(data,config).months.map(m=>{const h=data.filter(r=>Number(r.datetime.slice(5,7))===m.month).map(r=>r.humidity).filter(valid);return {...m,maxHumidity:max(h),minHumidity:min(h),dataCount:h.length};});

  // 处理温湿度散点数据（全部采样，按月份分组）
  const processScatterData = () => {
    return jointRows.map(item => {
      const date = new Date(item.datetime+'Z');
      return {
        temperature: item.temperature,
        humidity: item.humidity,
        month: date.getUTCMonth() + 1,
        monthName: date.toLocaleDateString('zh-CN', { month: 'short' }),
        datetime: item.datetime,
        date: date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })
      };
    });
  };

  // 计算统计数据
  const calculateStats = () => {
    if (data.length === 0) return null;

    const humidities = data.map(item => item.humidity).filter(valid);
    const maxHumidity = Math.max(...humidities);
    const minHumidity = Math.min(...humidities);
    const avgHumidity = humidities.reduce((sum, humidity) => sum + humidity, 0) / humidities.length;

    // 计算高温高湿和低温高湿小时数
    const highTempHighHumidity = data.filter(item => 
      item.temperature >= config.highTempThreshold && item.humidity >= config.highHumidityThreshold
    ).length;
    
    const lowTempHighHumidity = data.filter(item => 
      item.temperature <= config.lowTempThreshold && item.humidity >= config.highHumidityThreshold
    ).length;

    return {
      maxHumidity: Math.round(maxHumidity * 10) / 10,
      minHumidity: Math.round(minHumidity * 10) / 10,
      avgHumidity: Math.round(avgHumidity * 10) / 10,
      highTempHighHumidity,
      lowTempHighHumidity,
      totalHours: humidities.length
    };
  };

  const monthlyData = processMonthlyData();
  const scatterData = processScatterData();
  const stats = calculateStats();

  // 计算散点图温度数据的实际范围
  const getScatterTemperatureRange = () => {
    if (scatterData.length === 0) return { min: -20, max: 40 };
    
    const temperatures = scatterData.map(d => d.temperature);
    const minTemp = Math.min(...temperatures);
    const maxTemp = Math.max(...temperatures);
    
    // 向下和向上取整到5的倍数
    const minTick = Math.floor(minTemp / 5) * 5 - 5;
    const maxTick = Math.ceil(maxTemp / 5) * 5 + 5;
    
    return { min: minTick, max: maxTick };
  };

  const scatterTempRange = getScatterTemperatureRange();

  /**
   * 自定义工具提示
   */
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{`${label}月`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name.includes('湿度') ? 
                `${entry.name}: ${entry.value}%` : 
                `${entry.name}: ${entry.value}°C`
              }
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  /**
   * 散点图工具提示
   */
  const ScatterTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{data.monthName}</p>
          <p className="text-slate-600 dark:text-slate-300 text-xs">{data.date}</p>
          <p className="text-blue-600 dark:text-blue-400 text-sm">{`湿度: ${data.humidity}%`}</p>
          <p className="text-red-600 dark:text-red-400 text-sm">{`温度: ${data.temperature}°C`}</p>
        </div>
      );
    }
    return null;
  };

  /**
   * 季节颜色映射 - 四季分色方案
   */
  const getMonthColor = (month: number): string => {
    // 春季(3-5月): 绿色
    if (month >= 3 && month <= 5) return '#22c55e';
    // 夏季(6-8月): 红色 
    if (month >= 6 && month <= 8) return '#ef4444';
    // 秋季(9-11月): 橙色
    if (month >= 9 && month <= 11) return '#f59e0b';
    // 冬季(12,1,2月): 蓝色
    return '#3b82f6';
  };

  /**
   * 获取季节名称
   */
  const getSeasonName = (month: number): string => {
    if (month >= 3 && month <= 5) return '春季';
    if (month >= 6 && month <= 8) return '夏季';
    if (month >= 9 && month <= 11) return '秋季';
    return '冬季';
  };

  /**
   * 按月份分组散点数据
   */
  const getScatterDataByMonth = () => {
    const monthlyData: { [key: number]: any[] } = {};
    
    scatterData.forEach(item => {
      if (!monthlyData[item.month]) {
        monthlyData[item.month] = [];
      }
      monthlyData[item.month].push(item);
    });
    
    return monthlyData;
  };

  const scatterDataByMonth = getScatterDataByMonth();

  return (
    <div className="space-y-6">
      {/* 统计概览 */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/20 border-blue-800/30">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.maxHumidity}%</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">最高湿度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-900/20 to-cyan-800/20 border-cyan-800/30">
            <CardContent className="p-4 text-center">
              <TrendingDown className="w-6 h-6 text-cyan-600 dark:text-cyan-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-cyan-600 dark:text-cyan-400">{stats.minHumidity}%</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">最低湿度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-teal-900/20 to-teal-800/20 border-teal-800/30">
            <CardContent className="p-4 text-center">
              <Droplets className="w-6 h-6 text-teal-600 dark:text-teal-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-teal-600 dark:text-teal-400">{stats.avgHumidity}%</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">平均湿度</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/20 to-orange-800/20 border-orange-800/30">
            <CardContent className="p-4 text-center">
              <Thermometer className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{stats.highTempHighHumidity}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">高温高湿小时数</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/20 border-purple-800/30">
            <CardContent className="p-4 text-center">
              <Droplets className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{stats.lowTempHighHumidity}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">低温高湿小时数</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 温湿度月度变化图 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
                <Droplets className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>{config.locationName} 温湿度月度变化</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                月度平均温度与湿度对比分析
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              <Badge variant="outline" className="border-blue-400 text-blue-600 dark:text-blue-400">
                湿度 (%)
              </Badge>
              <Badge variant="outline" className="border-red-400 text-red-600 dark:text-red-400">
                温度 (°C)
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="monthName" 
                  stroke="#9ca3af"
                  fontSize={12}
                />
                <YAxis 
                  yAxisId="humidity"
                  stroke="#3b82f6"
                  fontSize={12}
                  label={{ value: '湿度 (%)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#3b82f6' } }}
                />
                <YAxis 
                  yAxisId="temp"
                  orientation="right"
                  stroke="#ef4444"
                  fontSize={12}
                  label={{ value: '温度 (°C)', angle: 90, position: 'insideRight', style: { textAnchor: 'middle', fill: '#ef4444' } }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                
                {/* 湿度柱状图 */}
                <Bar isAnimationActive={false} 
                  yAxisId="humidity"
                  dataKey="avgHumidity" 
                  fill="#3b82f6"
                  fillOpacity={0.6}
                  name="平均湿度"
                  radius={[2, 2, 0, 0]}
                />
                
                {/* 温度线图 */}
                <Line isAnimationActive={false}
                  yAxisId="temp"
                  type="monotone"
                  dataKey="avgTemp"
                  stroke="#ef4444"
                  strokeWidth={3}
                  dot={{ fill: '#ef4444', strokeWidth: 2, r: 4 }}
                  name="平均温度"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 温湿度散点关系图 */}
      <Card className="bg-gradient-to-br from-white to-slate-50 dark:from-slate-800/60 dark:to-slate-900/40 border-slate-200 dark:border-slate-600/50 backdrop-blur-sm shadow-2xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
                <Thermometer className="w-5 h-5 text-red-600 dark:text-red-400" />
                <Droplets className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>温度与湿度相关性分析</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                全年 {scatterData.length} 个数据点，按月份颜色区分展示温湿度关系模式
              </CardDescription>
            </div>
            <div className="text-right">
              <Badge variant="outline" className="border-purple-400 text-purple-600 dark:text-purple-400">
                全数据采样
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[480px] mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 30, right: 40, left: 40, bottom: 60 }}>
                <CartesianGrid 
                  strokeDasharray="2 2" 
                  stroke="#4b5563" 
                  strokeOpacity={0.3}
                />
                <XAxis 
                  type="number"
                  dataKey="temperature"
                  stroke="#d1d5db"
                  fontSize={11}
                  domain={[scatterTempRange.min, scatterTempRange.max]}
                  ticks={Array.from({ length: (scatterTempRange.max - scatterTempRange.min) / 5 + 1 }, (_, i) => scatterTempRange.min + i * 5)}
                  interval={0}
                  label={{ 
                    value: '温度 (°C)', 
                    position: 'insideBottom', 
                    offset: -5, 
                    style: { 
                      textAnchor: 'middle', 
                      fill: '#d1d5db',
                      fontSize: '12px',
                      fontWeight: '500'
                    } 
                  }}
                  tickLine={{ stroke: '#6b7280', strokeWidth: 1 }}
                  axisLine={{ stroke: '#6b7280', strokeWidth: 1 }}
                />
                <YAxis 
                  type="number"
                  dataKey="humidity"
                  stroke="#d1d5db"
                  fontSize={11}
                  label={{ 
                    value: '湿度 (%)', 
                    angle: -90, 
                    position: 'insideLeft', 
                    style: { 
                      textAnchor: 'middle', 
                      fill: '#d1d5db',
                      fontSize: '12px',
                      fontWeight: '500'
                    } 
                  }}
                  tickLine={{ stroke: '#6b7280', strokeWidth: 1 }}
                  axisLine={{ stroke: '#6b7280', strokeWidth: 1 }}
                />
                <Tooltip content={<ScatterTooltip />} />
                
                {/* 湿度70%参考线 */}
                <ReferenceLine 
                  y={config.highHumidityThreshold} 
                  stroke="#06b6d4" 
                  strokeDasharray="8 4" 
                  strokeWidth={2}
                  strokeOpacity={0.8}
                  label={{ 
                    value: `湿度${config.highHumidityThreshold}%`, 
                    position: "topRight",
                    style: { 
                      fill: "#06b6d4", 
                      fontSize: "11px", 
                      fontWeight: "500" 
                    }
                  }}
                />
                
                {/* 温度30°C参考线 */}
                <ReferenceLine 
                  x={config.highTempThreshold} 
                  stroke="#fbbf24" 
                  strokeDasharray="6 6" 
                  strokeWidth={2}
                  strokeOpacity={0.9}
                  label={{ 
                    value: `${config.highTempThreshold}°C`, 
                    position: "topLeft",
                    style: { 
                      fill: "#fbbf24", 
                      fontSize: "11px", 
                      fontWeight: "500" 
                    }
                  }}
                />
                
                {/* 按月份渲染不同颜色的散点 - 极简化配置 */}
                {Object.entries(scatterDataByMonth).map(([month, monthData]) => (
                  <Scatter isAnimationActive={false} 
                    key={month}
                    data={monthData} 
                    fill={getMonthColor(parseInt(month))}
                    shape={(props: any) => (<circle cx={props.cx} cy={props.cy} r={2.5} fill={props.fill} fillOpacity={0.85} />)}
                  />
                ))}
              </ScatterChart>
            </ResponsiveContainer>
          </div>
          
          {/* 月份颜色图例 */}
          {/* 相关性统计信息 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-gradient-to-br from-purple-900/30 to-purple-800/20 rounded-xl border border-purple-700/30 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full mr-2"></div>
                <p className="text-xs text-purple-600 dark:text-purple-200 font-medium">数据完整率</p>
              </div>
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-1">
                {calculateStats() ? (calculateStats()!.totalHours / data.length * 100).toFixed(1) : 0}%
              </p>
              <div className="w-full bg-slate-50 dark:bg-slate-700/50 rounded-full h-1.5">
                <div 
                  className="bg-gradient-to-r from-purple-500 to-purple-400 h-1.5 rounded-full transition-all duration-500"
                  style={{ width: `${calculateStats() ? (calculateStats()!.totalHours / data.length * 100) : 0}%` }}
                ></div>
              </div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-cyan-900/30 to-cyan-800/20 rounded-xl border border-cyan-700/30 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <div className="w-2 h-2 bg-cyan-400 rounded-full mr-2"></div>
                <p className="text-xs text-cyan-600 dark:text-cyan-200 font-medium">分析数据点</p>
              </div>
              <p className="text-3xl font-bold text-cyan-600 dark:text-cyan-400 mb-1">{scatterData.length.toLocaleString()}</p>
              <p className="text-xs text-cyan-600 dark:text-cyan-300">个时间点</p>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-br from-yellow-900/30 to-yellow-800/20 rounded-xl border border-yellow-700/30 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-2">
                <div className="w-2 h-2 bg-yellow-400 rounded-full mr-2"></div>
                <p className="text-xs text-yellow-200 font-medium">皮尔逊相关系数</p>
              </div>
              <p className="text-3xl font-bold text-yellow-400 mb-1">
                {(() => {
                  const temps = scatterData.map(d => d.temperature);
                  const hums = scatterData.map(d => d.humidity);
                  const n = temps.length;
                  if (n === 0) return '0.000';
                  
                  const sumX = temps.reduce((a, b) => a + b, 0);
                  const sumY = hums.reduce((a, b) => a + b, 0);
                  const sumXY = temps.reduce((sum, xi, i) => sum + xi * hums[i], 0);
                  const sumXX = temps.reduce((sum, xi) => sum + xi * xi, 0);
                  const sumYY = hums.reduce((sum, yi) => sum + yi * yi, 0);
                  
                  const numerator = n * sumXY - sumX * sumY;
                  const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));
                  
                  const correlation = denominator === 0 ? 0 : numerator / denominator;
                  return correlation.toFixed(3);
                })()}
              </p>
              <div className="flex items-center justify-center space-x-1 text-xs text-yellow-300">
                <span>r值</span>
                <div className="w-1 h-1 bg-yellow-400 rounded-full"></div>
                <span>
                  {(() => {
                    const r = parseFloat((() => {
                      const temps = scatterData.map(d => d.temperature);
                      const hums = scatterData.map(d => d.humidity);
                      const n = temps.length;
                      if (n === 0) return '0';
                      
                      const sumX = temps.reduce((a, b) => a + b, 0);
                      const sumY = hums.reduce((a, b) => a + b, 0);
                      const sumXY = temps.reduce((sum, xi, i) => sum + xi * hums[i], 0);
                      const sumXX = temps.reduce((sum, xi) => sum + xi * xi, 0);
                      const sumYY = hums.reduce((sum, yi) => sum + yi * yi, 0);
                      
                      const numerator = n * sumXY - sumX * sumY;
                      const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));
                      
                      return denominator === 0 ? '0' : (numerator / denominator).toFixed(3);
                    })());
                    
                    if (Math.abs(r) > 0.7) return '强相关';
                    if (Math.abs(r) > 0.3) return '中等相关';
                    return '弱相关';
                  })()}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-700/30 rounded-lg p-4">
            <h4 className="text-slate-900 dark:text-white font-medium mb-3 text-center">月份颜色图例</h4>
            <div className="grid grid-cols-6 md:grid-cols-12 gap-2">
              {Array.from({ length: 12 }, (_, i) => i + 1).map(month => {
                const monthName = new Date(2024, month - 1, 1).toLocaleDateString('zh-CN', { month: 'short' });
                const dataCount = scatterDataByMonth[month]?.length || 0;
                return (
                  <div key={month} className="flex flex-col items-center space-y-1">
                    <div 
                      className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600"
                      style={{ backgroundColor: getMonthColor(month) }}
                    />
                    <span className="text-xs text-slate-600 dark:text-slate-300">{monthName}</span>
                    <span className="text-xs text-slate-400">{dataCount}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-3 text-xs text-slate-400 text-center">
              数字表示该月份的数据点数量
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 湿度分布统计 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white text-lg">低湿度分布</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              湿度 &lt; {config.lowHumidityThreshold}% 的小时数
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {monthlyData.map(month => {
                // 按本站有效湿度记录计算
                const lowHumidityHours = month.validHumidity ? month.humidityBands[0] : '—';
                return (
                  <div key={month.month} className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-300">{month.monthName}</span>
                    <span className="text-yellow-400 font-medium">{lowHumidityHours}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white text-lg">适宜湿度分布</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              湿度 {config.lowHumidityThreshold}–{config.highHumidityThreshold}% 的小时数
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {monthlyData.map(month => {
                const comfortableHours = month.validHumidity ? month.humidityBands[1] : '—';
                return (
                  <div key={month.month} className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-300">{month.monthName}</span>
                    <span className="text-green-600 dark:text-green-400 font-medium">{comfortableHours}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
          <CardHeader>
            <CardTitle className="text-slate-900 dark:text-white text-lg">高湿度分布</CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              湿度 &gt; {config.highHumidityThreshold}% 的小时数
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {monthlyData.map(month => {
                const highHumidityHours = month.validHumidity ? month.humidityBands[2] : '—';
                return (
                  <div key={month.month} className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-300">{month.monthName}</span>
                    <span className="text-blue-600 dark:text-blue-400 font-medium">{highHumidityHours}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
