/**
 * YearlyHighHumidityHoursChart.tsx
 * 全年高湿小时数分布图
 * - 统计各月相对湿度 ≥75% 与 ≥85% 的小时数
 * - 用并列柱状图展示阈值对比，并给出全年汇总信息
 */

import React, { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Droplets, Activity } from 'lucide-react'
import type { WeatherConfig, WeatherData } from '../pages/Home'

/**
 * 高湿小时数图表的属性
 */
interface YearlyHighHumidityHoursChartProps {
  /** 小时级天气数据 */
  data: WeatherData[]
  /** 配置信息（用于标题展示） */
  config: WeatherConfig
}

/**
 * 月度高湿统计结构
 */
interface MonthlyHighHumidityRow {
  /** 月份（1-12） */
  month: number
  /** 本地化的月份名称（如 “1月”） */
  monthName: string
  /** 湿度 ≥75% 的小时数 */
  hours75: number
  /** 湿度 ≥85% 的小时数 */
  hours85: number
}

/**
 * 将小时级数据聚合为各月高湿小时数
 * - 湿度 ≥75% 计入 hours75
 * - 湿度 ≥85% 计入 hours85（hours85 自然不大于 hours75）
 */
function useMonthlyHighHumidity(data: WeatherData[]): MonthlyHighHumidityRow[] {
  return useMemo(() => {
    const months = Array.from<MonthlyHighHumidityRow, MonthlyHighHumidityRow>(
      { length: 12 },
      (_, i) => ({
        month: i + 1,
        monthName: new Date(2024, i, 1).toLocaleDateString('zh-CN', { month: 'short' }),
        hours75: 0,
        hours85: 0,
      }),
    )

    data.forEach((item) => {
      const d = new Date(item.datetime+'Z')
      if (Number.isNaN(d.getTime())) return
      const m = d.getUTCMonth() // 0-11
      const humidity = Number(item.humidity ?? 0)
      if (humidity >= 75) {
        months[m].hours75 += 1
      }
      if (humidity >= 85) {
        months[m].hours85 += 1
      }
    })

    return months
  }, [data])
}

/**
 * 高湿小时数图表自定义 Tooltip
 * 显示对应月份在两个阈值上的小时数
 */
function HighHumidityTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null

  return (
    <div className="rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-xs shadow-lg">
      <p className="mb-1 font-medium text-white">{label}</p>
      {payload.map((entry: any, index: number) => (
        <p key={index} style={{ color: entry.color }}>
          {entry.name}: {entry.value} 小时
        </p>
      ))}
    </div>
  )
}

/**
 * 全年高湿小时数分析图表
 * - 对比湿度 ≥75% 与 ≥85% 的月度小时数
 * - 上方展示全年汇总与占比信息
 */
export default function YearlyHighHumidityHoursChart({
  data,
  config,
}: YearlyHighHumidityHoursChartProps) {
  const monthly = useMonthlyHighHumidity(data)

  const totalHours = data.length
  const total75 = monthly.reduce((sum, m) => sum + m.hours75, 0)
  const total85 = monthly.reduce((sum, m) => sum + m.hours85, 0)

  const pct75 = totalHours ? ((total75 / totalHours) * 100).toFixed(1) : '0.0'
  const pct85 = totalHours ? ((total85 / totalHours) * 100).toFixed(1) : '0.0'

  return (
    <Card className="border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800/60">
      <CardHeader className="pb-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <Droplets className="h-5 w-5 text-cyan-500 dark:text-cyan-400" />
              <span>{config.locationName} 全年高湿小时数分析</span>
            </CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              统计全年湿度 ≥75% 与 ≥85% 的小时数，并按月份展示分布
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="border-cyan-400 text-cyan-500 dark:text-cyan-300">
              湿度 ≥ 75% 小时
            </Badge>
            <Badge variant="outline" className="border-emerald-400 text-emerald-500 dark:text-emerald-300">
              湿度 ≥ 85% 小时
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* 汇总统计卡片 */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">湿度 ≥ 75%</p>
                <p className="mt-1 text-2xl font-semibold text-slate-900 dark:text-white">
                  {total75.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  占有效湿度小时数的 {pct75}%
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-cyan-100 text-cyan-600 dark:bg-cyan-900/40 dark:text-cyan-300">
                <Droplets className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">湿度 ≥ 85%</p>
                <p className="mt-1 text-2xl font-semibold text-slate-900 dark:text-white">
                  {total85.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  占有效湿度小时数的 {pct85}%
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300">
                <Activity className="h-5 w-5" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">有效湿度小时数</p>
                <p className="mt-1 text-2xl font-semibold text-slate-900 dark:text-white">
                  {totalHours.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  仅统计有效湿度记录
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 柱状图：月度分布 */}
        <div className="h-[320px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthly}
              margin={{
                top: 16,
                right: 24,
                left: 8,
                bottom: 8,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" className="dark:stroke-slate-700" />
              <XAxis
                dataKey="monthName"
                stroke="#64748b"
                tick={{ fontSize: 12, fill: 'currentColor' }}
              />
              <YAxis
                stroke="#64748b"
                tick={{ fontSize: 12, fill: 'currentColor' }}
                label={{
                  value: '小时数',
                  angle: -90,
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fill: 'currentColor' },
                }}
              />
              <Tooltip content={<HighHumidityTooltip />} />
              <Legend />
              <Bar isAnimationActive={false}
                dataKey="hours75"
                name="湿度 ≥ 75% 小时数"
                fill="#22c55e"
                radius={[3, 3, 0, 0]}
              />
              <Bar isAnimationActive={false}
                dataKey="hours85"
                name="湿度 ≥ 85% 小时数"
                fill="#0ea5e9"
                radius={[3, 3, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
