/**
 * 配置表单组件
 * 用于收集天气数据分析的配置参数
 */
import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { MapPin, Calendar, Thermometer, Droplets, Play } from 'lucide-react';
import type { WeatherConfig } from '../pages/Home';

interface ConfigFormProps {
  onSubmit: (config: WeatherConfig) => void;
  loading: boolean;
}

/**
 * 配置表单组件
 */
export default function ConfigForm({ onSubmit, loading }: ConfigFormProps) {
  const [formData, setFormData] = useState<WeatherConfig>({
    locationName: 'Ljubljana',
    latitude: 46.2167,
    longitude: 14.4833,
    timezone: 'Europe/Ljubljana',
    startDate: '2024-01-01',
    endDate: '2024-12-31',
    highTempThreshold: 30,
    lowTempThreshold: -10,
    highHumidityThreshold: 70,
    lowHumidityThreshold: 40
  });

  /**
   * 预设地区配置
   */
  const presetLocations = [
    { name: 'Ljubljana', lat: 46.2167, lng: 14.4833, timezone: 'Europe/Ljubljana' },
    { name: 'Beijing', lat: 39.9042, lng: 116.4074, timezone: 'Asia/Shanghai' },
    { name: 'Shanghai', lat: 31.2304, lng: 121.4737, timezone: 'Asia/Shanghai' },
    { name: 'New York', lat: 40.7128, lng: -74.0060, timezone: 'America/New_York' },
    { name: 'London', lat: 51.5074, lng: -0.1278, timezone: 'Europe/London' },
    { name: 'Paris', lat: 48.8566, lng: 2.3522, timezone: 'Europe/Paris' },
    { name: 'Tokyo', lat: 35.6762, lng: 139.6503, timezone: 'Asia/Tokyo' },
    { name: 'Sydney', lat: -33.8688, lng: 151.2093, timezone: 'Australia/Sydney' }
  ];

  /**
   * 处理表单输入变化
   */
  const handleInputChange = (field: keyof WeatherConfig, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  /**
   * 处理预设地区选择
   */
  const handleLocationSelect = (locationName: string) => {
    const location = presetLocations.find(loc => loc.name === locationName);
    if (location) {
      setFormData(prev => ({
        ...prev,
        locationName: location.name,
        latitude: location.lat,
        longitude: location.lng,
        timezone: location.timezone
      }));
    }
  };

  /**
   * 表单验证
   */
  const validateForm = (): boolean => {
    if (!formData.locationName.trim()) return false;
    if (isNaN(formData.latitude) || isNaN(formData.longitude)) return false;
    if (!formData.startDate || !formData.endDate) return false;
    if (new Date(formData.startDate) >= new Date(formData.endDate)) return false;
    return true;
  };

  /**
   * 提交表单
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm() && !loading) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* 地区信息 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-slate-700/30 border-slate-600">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-blue-400" />
              <CardTitle className="text-sm text-white">地区信息</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="location-select" className="text-slate-300 text-sm">
                快速选择地区
              </Label>
              <Select onValueChange={handleLocationSelect}>
                <SelectTrigger className="bg-slate-800 border-slate-600 text-white">
                  <SelectValue placeholder="选择预设地区" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {presetLocations.map(location => (
                    <SelectItem 
                      key={location.name} 
                      value={location.name}
                      className="text-white focus:bg-slate-700"
                    >
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="locationName" className="text-slate-300 text-sm">
                地区名称
              </Label>
              <Input
                id="locationName"
                value={formData.locationName}
                onChange={(e) => handleInputChange('locationName', e.target.value)}
                className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400"
                placeholder="输入地区名称"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="latitude" className="text-slate-300 text-sm">
                  纬度
                </Label>
                <Input
                  id="latitude"
                  type="number"
                  step="0.0001"
                  value={formData.latitude}
                  onChange={(e) => handleInputChange('latitude', parseFloat(e.target.value))}
                  className="bg-slate-800 border-slate-600 text-white"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="longitude" className="text-slate-300 text-sm">
                  经度
                </Label>
                <Input
                  id="longitude"
                  type="number"
                  step="0.0001"
                  value={formData.longitude}
                  onChange={(e) => handleInputChange('longitude', parseFloat(e.target.value))}
                  className="bg-slate-800 border-slate-600 text-white"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="timezone" className="text-slate-300 text-sm">
                时区
              </Label>
              <Input
                id="timezone"
                value={formData.timezone}
                onChange={(e) => handleInputChange('timezone', e.target.value)}
                className="bg-slate-800 border-slate-600 text-white placeholder:text-slate-400"
                placeholder="例如: Asia/Shanghai"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* 时间范围和阈值 */}
        <Card className="bg-slate-700/30 border-slate-600">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-green-400" />
              <CardTitle className="text-sm text-white">时间范围与阈值</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="startDate" className="text-slate-300 text-sm">
                  开始日期
                </Label>
                <Input
                  id="startDate"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => handleInputChange('startDate', e.target.value)}
                  className="bg-slate-800 border-slate-600 text-white"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate" className="text-slate-300 text-sm">
                  结束日期
                </Label>
                <Input
                  id="endDate"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange('endDate', e.target.value)}
                  className="bg-slate-800 border-slate-600 text-white"
                  required
                />
              </div>
            </div>

            <Separator className="bg-slate-600" />

            <div className="space-y-3">
              <div className="flex items-center space-x-2 mb-2">
                <Thermometer className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-white">温度阈值 (°C)</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="highTempThreshold" className="text-slate-400 text-xs">
                    高温阈值
                  </Label>
                  <Input
                    id="highTempThreshold"
                    type="number"
                    value={formData.highTempThreshold}
                    onChange={(e) => handleInputChange('highTempThreshold', parseFloat(e.target.value))}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lowTempThreshold" className="text-slate-400 text-xs">
                    低温阈值
                  </Label>
                  <Input
                    id="lowTempThreshold"
                    type="number"
                    value={formData.lowTempThreshold}
                    onChange={(e) => handleInputChange('lowTempThreshold', parseFloat(e.target.value))}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2 mb-2">
                <Droplets className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-white">湿度阈值 (%)</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="highHumidityThreshold" className="text-slate-400 text-xs">
                    高湿度阈值
                  </Label>
                  <Input
                    id="highHumidityThreshold"
                    type="number"
                    value={formData.highHumidityThreshold}
                    onChange={(e) => handleInputChange('highHumidityThreshold', parseFloat(e.target.value))}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lowHumidityThreshold" className="text-slate-400 text-xs">
                    低湿度阈值
                  </Label>
                  <Input
                    id="lowHumidityThreshold"
                    type="number"
                    value={formData.lowHumidityThreshold}
                    onChange={(e) => handleInputChange('lowHumidityThreshold', parseFloat(e.target.value))}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 提交按钮 */}
      <div className="flex justify-center">
        <Button
          type="submit"
          disabled={loading || !validateForm()}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-2 rounded-lg transition-all duration-200 flex items-center space-x-2"
        >
          <Play className="w-4 h-4" />
          <span>{loading ? '分析中...' : '开始分析'}</span>
        </Button>
      </div>
    </form>
  );
}