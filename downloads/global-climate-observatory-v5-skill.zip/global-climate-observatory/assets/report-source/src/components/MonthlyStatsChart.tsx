import {aggregateReport} from '../utils/stats.mjs'
/**
 * MonthlyStatsChart.tsx
 * 月度综合统计（双轴 0 对齐、四柱并列）
 * - 温度：月“日最高均值”“日最低均值”（左轴）
 * - 湿度：月平均（右轴）
 * - 降水：月累计（右轴）
 * - 右轴通过计算下界与左轴 0 位置对齐，确保两侧 0 刻度重合
 */

import React, { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { BarChart3 } from 'lucide-react'
import type { WeatherConfig, WeatherData } from '../pages/Home'

/** 月度数据行 */
interface MonthlyRow {
  month: number
  monthName: string
  avgDailyMax: number
  avgDailyMin: number
  avgHumidity: number
  totalPrecip: number
}

/** 将数字向下取整到 step 的整数倍 */
function floorTo(x: number, step = 5) {
  if (!isFinite(x)) return 0
  return Math.floor(x / step) * step
}
/** 将数字向上取整到 step 的整数倍 */
function ceilTo(x: number, step = 5) {
  if (!isFinite(x)) return step
  return Math.ceil(x / step) * step
}

/** 选取 [1,2,5]×10^k 的友好上界（用于右轴 max） */
function niceCeil(maxVal: number): number {
  if (!isFinite(maxVal) || maxVal <= 0) return 100
  const exp = Math.pow(10, Math.floor(Math.log10(maxVal)))
  const scaled = maxVal / exp
  const steps = [1, 2, 5, 10]
  const step = steps.find((s) => scaled <= s) ?? 10
  return step * exp
}

/**
 * 从小时级数据生成月度统计
 * - 先按“日”求当天的最高/最低温度，再对每月求平均
 * - 湿度：直接对当月小时湿度均值
 * - 降水：当月小时降水累计
 */
function useMonthlyStats(data: WeatherData[]): MonthlyRow[] {return useMemo(()=>aggregateReport(data).months,[data])}

function useAlignedDomains(rows: MonthlyRow[]) {
  return useMemo(() => {
    const leftValues = rows.flatMap((r) => [r.avgDailyMax, r.avgDailyMin])
    let lMin = Math.min(...leftValues, 0)
    let lMax = Math.max(...leftValues, 0)
    if (!isFinite(lMin) || !isFinite(lMax)) {
      lMin = -5
      lMax = 5
    }
    if (lMin === lMax) {
      lMin -= 5
      lMax += 5
    }
    const pad = Math.max(2, (lMax - lMin) * 0.1)
    let leftMin = floorTo(lMin - pad, 5)
    let leftMax = ceilTo(lMax + pad, 5)
    if (leftMin === leftMax) {
      leftMin -= 5
      leftMax += 5
    }

    // 右轴 max 基于湿度/降水（两者不同量纲，但仅用于定位）
    const rightRawMax = Math.max(
      0,
      ...rows.map((r) => r.avgHumidity),
      ...rows.map((r) => r.totalPrecip)
    )
    let rightMax = niceCeil(rightRawMax || 100)
    if (!isFinite(rightMax) || rightMax <= 0) rightMax = 100

    // 计算左轴 0 的相对位置 z
    const span = leftMax - leftMin
    let z = span > 0 ? (0 - leftMin) / span : 0.5
    // 限制在 (0,1) 内，避免极端情况
    z = Math.min(0.95, Math.max(0.05, z))

    // 右轴下界，确保 0 对齐
    let rightMin = -(z / (1 - z)) * rightMax
    if (!isFinite(rightMin)) rightMin = -0.25 * rightMax
    if (rightMin === rightMax) rightMin = -rightMax

    return {
      left: [leftMin, leftMax] as [number, number],
      right: [rightMin, rightMax] as [number, number],
    }
  }, [rows])
}

/** Tooltip：单位区分 */
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-slate-800 border border-slate-600 rounded-md px-3 py-2 text-sm shadow-lg">
      <div className="text-white font-medium mb-1">{label}</div>
      {payload.map((p: any, i: number) => {
        const name: string = p.name || ''
        const unit =
          name.includes('温度') ? '°C' : name.includes('湿度') ? '%' : name.includes('降水') ? 'mm' : ''
        return (
          <div key={i} className="flex items-center gap-2" style={{ color: p.color }}>
            <span>{name}</span>
            <span className="text-white/90">{typeof p.value === 'number' ? p.value : '--'}{unit}</span>
          </div>
        )
      })}
    </div>
  )
}

/**
 * 月度综合统计（四柱并列，双轴 0 对齐）
 */
export default function MonthlyStatsChart({
  data,
  config,
}: {
  data: WeatherData[]
  config: WeatherConfig
}) {
  const rows = useMonthlyStats(data)
  const domains = useAlignedDomains(rows)

  return (
    <Card className="bg-white border-slate-200 dark:bg-slate-800/50 dark:border-slate-700">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <BarChart3 className="w-5 h-5 text-purple-500 dark:text-purple-400" />
              <span>{config.locationName} 月度综合统计</span>
            </CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              各月份温度（最高/最低）、湿度与降水量对比（双轴 0 对齐）
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline" className="border-rose-400 text-rose-500 dark:text-rose-400">
              月平均最高温
            </Badge>
            <Badge variant="outline" className="border-amber-400 text-amber-500 dark:text-amber-400">
              月平均最低温
            </Badge>
            <Badge variant="outline" className="border-sky-400 text-sky-600 dark:text-sky-400">
              平均湿度
            </Badge>
            <Badge variant="outline" className="border-emerald-400 text-emerald-600 dark:text-emerald-400">
              总降水量
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[380px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={rows}
              margin={{ top: 20, right: 28, left: 12, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="monthName" stroke="#475569" tick={{ fill: 'currentColor' }} />
              <YAxis
                yAxisId="left"
                orientation="left"
                domain={domains.left}
                stroke="#475569"
                tick={{ fill: 'currentColor' }}
                label={{
                  value: '温度 (°C)',
                  angle: -90,
                  position: 'insideLeft',
                  style: { textAnchor: 'middle', fill: 'currentColor' },
                }}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tickFormatter={(v)=>Number(v).toFixed(0)}
                domain={domains.right}
                stroke="#475569"
                tick={{ fill: 'currentColor' }}
                label={{
                  value: '湿度 (%) / 降水量 (mm)',
                  angle: -90,
                  position: 'insideRight',
                  style: { textAnchor: 'middle', fill: 'currentColor' },
                }}
              />

              <Tooltip content={<CustomTooltip />} />
              <Legend />

              {/* 温度（左轴） */}
              <Bar isAnimationActive={false}
                yAxisId="left"
                dataKey="avgDailyMax"
                name="月平均最高温度 (°C)"
                fill="#ef4444"
                radius={[4, 4, 0, 0]}
                maxBarSize={20}
              />
              <Bar isAnimationActive={false}
                yAxisId="left"
                dataKey="avgDailyMin"
                name="月平均最低温度 (°C)"
                fill="#f59e0b"
                radius={[4, 4, 0, 0]}
                maxBarSize={20}
              />

              {/* 湿度与降水（右轴） */}
              <Bar isAnimationActive={false}
                yAxisId="right"
                dataKey="avgHumidity"
                name="平均湿度 (%)"
                fill="#38bdf8"
                radius={[4, 4, 0, 0]}
                maxBarSize={20}
              />
              <Bar isAnimationActive={false}
                yAxisId="right"
                dataKey="totalPrecip"
                name="总降水量 (mm)"
                fill="#34d399"
                radius={[4, 4, 0, 0]}
                maxBarSize={20}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
