/**
 * 气候总结组件
 * 基于数据分析生成当地气候特征总结
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  CloudRain, 
  Thermometer, 
  Droplets, 
  Wind,
  Sun,
  Snowflake,
  Umbrella,
  MapPin,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Info,
  Calendar,
  Activity
} from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface ClimateSummaryProps {
  data: WeatherData[];
  config: WeatherConfig;
}

interface ClimateAnalysis {
  temperatureProfile: {
    type: string;
    description: string;
    avgTemp: number;
    maxTemp: number;
    minTemp: number;
    range: number;
    icon: any;
  };
  precipitationProfile: {
    type: string;
    description: string;
    totalPrecip: number;
    rainyDays: number;
    avgPrecip: number;
    icon: any;
  };
  humidityProfile: {
    type: string;
    description: string;
    avgHumidity: number;
    comfortLevel: string;
    icon: any;
  };
  seasonalCharacteristics: {
    dominant: string;
    description: string;
    months: string[];
  };
  extremeWeather: {
    hotDays: number;
    coldDays: number;
    muggyHours: number;
    riskLevel: string;
  };
  climateType: {
    classification: string;
    description: string;
    characteristics: string[];
  };
  livingAdvice: {
    clothing: string[];
    activities: string[];
    precautions: string[];
  };
}

/**
 * 气候总结组件
 */
export default function ClimateSummary({ data, config }: ClimateSummaryProps) {
  
  /**
   * 分析气候特征
   */
  const analyzeClimate = (): ClimateAnalysis => {
    if (data.length === 0) {
      return getDefaultAnalysis();
    }

    // 基础统计
    const temperatures = data.map(d => d.temperature);
    const humidities = data.map(d => d.humidity);
    const precipitations = data.map(d => d.precipitation);
    
    const avgTemp = temperatures.reduce((sum, t) => sum + t, 0) / temperatures.length;
    const maxTemp = Math.max(...temperatures);
    const minTemp = Math.min(...temperatures);
    const tempRange = maxTemp - minTemp;
    
    const avgHumidity = humidities.reduce((sum, h) => sum + h, 0) / humidities.length;
    const totalPrecip = precipitations.reduce((sum, p) => sum + p, 0);
    const rainyDays = data.filter(d => d.precipitation > 0.1).length / 24; // 转换为天数
    const avgPrecip = totalPrecip / (data.length / 24);

    // 极端天气统计
    const hotDays = data.filter(d => d.temperature >= config.highTempThreshold).length / 24;
    const coldDays = data.filter(d => d.temperature <= config.lowTempThreshold).length / 24;
    const muggyHours = data.filter(d => 
      d.temperature >= config.highTempThreshold && 
      d.humidity >= config.highHumidityThreshold
    ).length;

    // 季节分析
    const seasonalData = analyzeSeasons();

    // 温度特征分析
    const temperatureProfile = analyzeTemperature(avgTemp, tempRange, maxTemp, minTemp);
    
    // 降水特征分析
    const precipitationProfile = analyzePrecipitation(totalPrecip, rainyDays, avgPrecip);
    
    // 湿度特征分析
    const humidityProfile = analyzeHumidity(avgHumidity);
    
    // 气候类型判断
    const climateType = classifyClimate(avgTemp, totalPrecip, tempRange, avgHumidity);
    
    // 极端天气评估
    const extremeWeather = {
      hotDays: Math.round(hotDays),
      coldDays: Math.round(coldDays),
      muggyHours,
      riskLevel: assessRiskLevel(hotDays, coldDays, muggyHours)
    };

    // 生活建议
    const livingAdvice = generateLivingAdvice(climateType, extremeWeather, avgTemp, avgHumidity);

    return {
      temperatureProfile,
      precipitationProfile,
      humidityProfile,
      seasonalCharacteristics: seasonalData,
      extremeWeather,
      climateType,
      livingAdvice
    };
  };

  /**
   * 分析季节特征
   */
  const analyzeSeasons = () => {
    const seasons = [
      { name: '春季', months: [2, 3, 4], temps: [] as number[] },
      { name: '夏季', months: [5, 6, 7], temps: [] as number[] },
      { name: '秋季', months: [8, 9, 10], temps: [] as number[] },
      { name: '冬季', months: [11, 0, 1], temps: [] as number[] }
    ];

    data.forEach(item => {
      const month = new Date(item.datetime).getMonth();
      seasons.forEach(season => {
        if (season.months.includes(month)) {
          season.temps.push(item.temperature);
        }
      });
    });

    const seasonAvgs = seasons.map(season => ({
      name: season.name,
      avgTemp: season.temps.length > 0 ? 
        season.temps.reduce((sum, t) => sum + t, 0) / season.temps.length : 0
    }));

    const dominant = seasonAvgs.reduce((max, season) => 
      season.avgTemp > max.avgTemp ? season : max
    );

    let description = '';
    let monthsList: string[] = [];

    if (dominant.name === '夏季') {
      description = '典型的夏季主导型气候，温暖湿润';
      monthsList = ['6月', '7月', '8月'];
    } else if (dominant.name === '冬季') {
      description = '冬季特征明显，寒冷干燥';
      monthsList = ['12月', '1月', '2月'];
    } else if (dominant.name === '春季') {
      description = '春季温和，适宜居住';
      monthsList = ['3月', '4月', '5月'];
    } else {
      description = '秋季凉爽，气候宜人';
      monthsList = ['9月', '10月', '11月'];
    }

    return {
      dominant: dominant.name,
      description,
      months: monthsList
    };
  };

  /**
   * 分析温度特征
   */
  const analyzeTemperature = (avgTemp: number, range: number, maxTemp: number, minTemp: number) => {
    let type = '';
    let description = '';
    let icon = Thermometer;

    if (avgTemp >= 25) {
      type = '热带气候';
      description = '全年高温，炎热潮湿';
      icon = Sun;
    } else if (avgTemp >= 15) {
      type = '温带气候';
      description = '四季分明，温度适中';
      icon = Thermometer;
    } else if (avgTemp >= 5) {
      type = '冷温带气候';
      description = '偏冷，冬季较长';
      icon = Snowflake;
    } else {
      type = '寒带气候';
      description = '全年低温，寒冷干燥';
      icon = Snowflake;
    }

    return {
      type,
      description,
      avgTemp: Math.round(avgTemp * 10) / 10,
      maxTemp: Math.round(maxTemp * 10) / 10,
      minTemp: Math.round(minTemp * 10) / 10,
      range: Math.round(range * 10) / 10,
      icon
    };
  };

  /**
   * 分析降水特征
   */
  const analyzePrecipitation = (totalPrecip: number, rainyDays: number, avgPrecip: number) => {
    let type = '';
    let description = '';
    let icon = CloudRain;

    if (totalPrecip >= 1500) {
      type = '多雨气候';
      description = '降水丰沛，雨水充足';
      icon = CloudRain;
    } else if (totalPrecip >= 800) {
      type = '湿润气候';
      description = '降水适中，湿润宜人';
      icon = Umbrella;
    } else if (totalPrecip >= 400) {
      type = '半湿润气候';
      description = '降水偏少，相对干燥';
      icon = CloudRain;
    } else {
      type = '干旱气候';
      description = '降水稀少，干旱少雨';
      icon = Sun;
    }

    return {
      type,
      description,
      totalPrecip: Math.round(totalPrecip * 10) / 10,
      rainyDays: Math.round(rainyDays),
      avgPrecip: Math.round(avgPrecip * 10) / 10,
      icon
    };
  };

  /**
   * 分析湿度特征
   */
  const analyzeHumidity = (avgHumidity: number) => {
    let type = '';
    let description = '';
    let comfortLevel = '';
    let icon = Droplets;

    if (avgHumidity >= 80) {
      type = '高湿气候';
      description = '空气湿润，体感闷热';
      comfortLevel = '较不舒适';
    } else if (avgHumidity >= 60) {
      type = '湿润气候';
      description = '湿度适中，较为舒适';
      comfortLevel = '较舒适';
    } else if (avgHumidity >= 40) {
      type = '适中湿度';
      description = '湿度理想，非常舒适';
      comfortLevel = '非常舒适';
    } else {
      type = '干燥气候';
      description = '空气干燥，需要保湿';
      comfortLevel = '偏干燥';
    }

    return {
      type,
      description,
      avgHumidity: Math.round(avgHumidity * 10) / 10,
      comfortLevel,
      icon
    };
  };

  /**
   * 气候类型分类
   */
  const classifyClimate = (avgTemp: number, totalPrecip: number, tempRange: number, avgHumidity: number) => {
    let classification = '';
    let description = '';
    let characteristics: string[] = [];

    // 柯本气候分类的简化版本
    if (avgTemp >= 18 && totalPrecip >= 1000) {
      classification = '热带湿润气候 (Af)';
      description = '全年高温多雨，植被繁茂';
      characteristics = ['全年高温', '雷雨频繁', '湿度很高', '植被茂盛'];
    } else if (avgTemp >= 15 && totalPrecip >= 500) {
      classification = '亚热带湿润气候 (Cfa)';
      description = '温暖湿润，四季分明';
      characteristics = ['夏季炎热', '冬季温和', '降水均匀', '适宜居住'];
    } else if (avgTemp >= 10 && totalPrecip >= 400) {
      classification = '温带海洋性气候 (Cfb)';
      description = '温和湿润，温差较小';
      characteristics = ['全年温和', '降水均匀', '湿度适中', '气候稳定'];
    } else if (avgTemp >= 5 && tempRange >= 25) {
      classification = '温带大陆性气候 (Dfa/Dfb)';
      description = '冬寒夏热，温差较大';
      characteristics = ['季节分明', '温差较大', '冬季严寒', '夏季炎热'];
    } else if (avgTemp < 5) {
      classification = '寒带气候 (ET/EF)';
      description = '全年低温，生长期短';
      characteristics = ['全年低温', '冬季漫长', '夏季短暂', '植被稀少'];
    } else {
      classification = '温带半干旱气候 (BSk)';
      description = '温度适中，降水偏少';
      characteristics = ['温度适中', '降水偏少', '昼夜温差大', '相对干燥'];
    }

    return {
      classification,
      description,
      characteristics
    };
  };

  /**
   * 评估风险等级
   */
  const assessRiskLevel = (hotDays: number, coldDays: number, muggyHours: number): string => {
    const totalRiskDays = hotDays + coldDays;
    const muggyRiskDays = muggyHours / 24;

    if (totalRiskDays >= 60 || muggyRiskDays >= 30) {
      return '高风险';
    } else if (totalRiskDays >= 30 || muggyRiskDays >= 15) {
      return '中等风险';
    } else {
      return '低风险';
    }
  };

  /**
   * 生成生活建议
   */
  const generateLivingAdvice = (climateType: any, extremeWeather: any, avgTemp: number, avgHumidity: number) => {
    const clothing: string[] = [];
    const activities: string[] = [];
    const precautions: string[] = [];

    // 服装建议
    if (avgTemp >= 25) {
      clothing.push('轻薄透气的夏装', '防晒帽和太阳镜', '透气性好的鞋履');
    } else if (avgTemp >= 15) {
      clothing.push('春秋季服装', '可调节的外套', '舒适的休闲装');
    } else {
      clothing.push('保暖衣物', '厚外套或羽绒服', '保暖鞋袜');
    }

    if (avgHumidity >= 70) {
      clothing.push('速干材质服装', '透气内衣');
    }

    // 活动建议
    if (extremeWeather.riskLevel === '低风险') {
      activities.push('全年适宜户外运动', '登山徒步', '野外露营');
    } else if (extremeWeather.riskLevel === '中等风险') {
      activities.push('春秋季户外活动', '室内运动为主', '避开极端天气');
    } else {
      activities.push('以室内活动为主', '极端天气避免外出', '选择气候适宜时段');
    }

    // 注意事项
    if (extremeWeather.hotDays >= 30) {
      precautions.push('夏季注意防暑降温', '及时补充水分', '避免中午外出');
    }
    if (extremeWeather.coldDays >= 30) {
      precautions.push('冬季注意保暖防寒', '预防感冒', '室内保持温暖');
    }
    if (extremeWeather.muggyHours >= 200) {
      precautions.push('注意防潮除湿', '保持室内通风', '预防霉菌滋生');
    }
    if (avgHumidity < 40) {
      precautions.push('注意皮肤保湿', '使用加湿器', '多喝水补充水分');
    }

    return {
      clothing,
      activities,
      precautions
    };
  };

  /**
   * 默认分析结果
   */
  const getDefaultAnalysis = (): ClimateAnalysis => {
    return {
      temperatureProfile: {
        type: '数据不足',
        description: '无法分析温度特征',
        avgTemp: 0,
        maxTemp: 0,
        minTemp: 0,
        range: 0,
        icon: Thermometer
      },
      precipitationProfile: {
        type: '数据不足',
        description: '无法分析降水特征',
        totalPrecip: 0,
        rainyDays: 0,
        avgPrecip: 0,
        icon: CloudRain
      },
      humidityProfile: {
        type: '数据不足',
        description: '无法分析湿度特征',
        avgHumidity: 0,
        comfortLevel: '未知',
        icon: Droplets
      },
      seasonalCharacteristics: {
        dominant: '未知',
        description: '数据不足，无法分析季节特征',
        months: []
      },
      extremeWeather: {
        hotDays: 0,
        coldDays: 0,
        muggyHours: 0,
        riskLevel: '未知'
      },
      climateType: {
        classification: '未分类',
        description: '数据不足，无法进行气候分类',
        characteristics: []
      },
      livingAdvice: {
        clothing: ['请上传数据后查看建议'],
        activities: ['请上传数据后查看建议'],
        precautions: ['请上传数据后查看建议']
      }
    };
  };

  const analysis = analyzeClimate();

  return (
    <div className="space-y-6">
      {/* 总结标题 */}
      <Card className="bg-gradient-to-br from-indigo-900/20 to-purple-900/20 border-indigo-800/30">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-2">
            <MapPin className="w-8 h-8 text-indigo-400" />
            <CardTitle className="text-2xl text-white">
              {config.locationName} 气候分析总结
            </CardTitle>
          </div>
          <CardDescription className="text-slate-300 text-lg">
            基于 {data.length} 小时气象数据的综合分析报告
          </CardDescription>
        </CardHeader>
      </Card>

      {/* 气候特征概览 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 温度特征 */}
        <Card className="bg-gradient-to-br from-red-900/20 to-orange-900/20 border-red-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center space-x-2">
              <analysis.temperatureProfile.icon className="w-6 h-6 text-red-400" />
              <CardTitle className="text-lg text-white">{analysis.temperatureProfile.type}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-slate-300 text-sm">{analysis.temperatureProfile.description}</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">年均温度</span>
                <span className="text-red-400 font-medium">{analysis.temperatureProfile.avgTemp}°C</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">温度范围</span>
                <span className="text-orange-400 font-medium">{analysis.temperatureProfile.range}°C</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">最高: {analysis.temperatureProfile.maxTemp}°C</span>
                <span className="text-slate-500">最低: {analysis.temperatureProfile.minTemp}°C</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 降水特征 */}
        <Card className="bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center space-x-2">
              <analysis.precipitationProfile.icon className="w-6 h-6 text-blue-400" />
              <CardTitle className="text-lg text-white">{analysis.precipitationProfile.type}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-slate-300 text-sm">{analysis.precipitationProfile.description}</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">年降水量</span>
                <span className="text-blue-400 font-medium">{analysis.precipitationProfile.totalPrecip}mm</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">雨天数</span>
                <span className="text-cyan-400 font-medium">{analysis.precipitationProfile.rainyDays}天</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">日均: {analysis.precipitationProfile.avgPrecip}mm</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 湿度特征 */}
        <Card className="bg-gradient-to-br from-teal-900/20 to-green-900/20 border-teal-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center space-x-2">
              <analysis.humidityProfile.icon className="w-6 h-6 text-teal-400" />
              <CardTitle className="text-lg text-white">{analysis.humidityProfile.type}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-slate-300 text-sm">{analysis.humidityProfile.description}</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">平均湿度</span>
                <span className="text-teal-400 font-medium">{analysis.humidityProfile.avgHumidity}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">舒适度</span>
                <Badge 
                  variant="outline" 
                  className={`
                    ${analysis.humidityProfile.comfortLevel === '非常舒适' ? 'border-green-400 text-green-400' :
                      analysis.humidityProfile.comfortLevel === '较舒适' ? 'border-yellow-400 text-yellow-400' :
                      'border-orange-400 text-orange-400'}
                  `}
                >
                  {analysis.humidityProfile.comfortLevel}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 气候分类和季节特征 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 气候分类 */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Activity className="w-5 h-5 text-purple-400" />
              <span>气候类型分类</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-4 bg-purple-900/20 rounded-lg border border-purple-800/30">
              <h3 className="text-xl font-bold text-purple-400 mb-2">
                {analysis.climateType.classification}
              </h3>
              <p className="text-slate-300 text-sm">
                {analysis.climateType.description}
              </p>
            </div>
            
            <div className="space-y-2">
              <h4 className="text-white font-medium">主要特征:</h4>
              <div className="grid grid-cols-2 gap-2">
                {analysis.climateType.characteristics.map((char, index) => (
                  <Badge 
                    key={index} 
                    variant="outline" 
                    className="border-purple-400 text-purple-400 justify-center"
                  >
                    {char}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 季节特征 */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-amber-400" />
              <span>季节特征分析</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center p-4 bg-amber-900/20 rounded-lg border border-amber-800/30">
              <h3 className="text-xl font-bold text-amber-400 mb-2">
                {analysis.seasonalCharacteristics.dominant}主导
              </h3>
              <p className="text-slate-300 text-sm">
                {analysis.seasonalCharacteristics.description}
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="text-white font-medium">主要月份:</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.seasonalCharacteristics.months.map((month, index) => (
                  <Badge 
                    key={index}
                    variant="outline" 
                    className="border-amber-400 text-amber-400"
                  >
                    {month}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 极端天气风险评估 */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <span>极端天气风险评估</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-red-900/20 rounded-lg">
              <Sun className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-red-400">{analysis.extremeWeather.hotDays}</p>
              <p className="text-sm text-slate-300">高温天数</p>
            </div>
            
            <div className="text-center p-4 bg-blue-900/20 rounded-lg">
              <Snowflake className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-400">{analysis.extremeWeather.coldDays}</p>
              <p className="text-sm text-slate-300">低温天数</p>
            </div>
            
            <div className="text-center p-4 bg-orange-900/20 rounded-lg">
              <Droplets className="w-8 h-8 text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-400">{analysis.extremeWeather.muggyHours}</p>
              <p className="text-sm text-slate-300">闷热小时数</p>
            </div>
            
            <div className="text-center p-4 bg-slate-700/30 rounded-lg">
              <AlertTriangle className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <Badge 
                variant="outline" 
                className={`
                  text-lg px-3 py-1 ${
                    analysis.extremeWeather.riskLevel === '高风险' ? 'border-red-400 text-red-400' :
                    analysis.extremeWeather.riskLevel === '中等风险' ? 'border-yellow-400 text-yellow-400' :
                    'border-green-400 text-green-400'
                  }
                `}
              >
                {analysis.extremeWeather.riskLevel}
              </Badge>
              <p className="text-sm text-slate-300 mt-2">综合风险</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 生活建议 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 服装建议 */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>服装建议</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.livingAdvice.clothing.map((item, index) => (
                <li key={index} className="flex items-start space-x-2 text-slate-300">
                  <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* 活动建议 */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              <span>活动建议</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.livingAdvice.activities.map((item, index) => (
                <li key={index} className="flex items-start space-x-2 text-slate-300">
                  <TrendingUp className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* 注意事项 */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Info className="w-5 h-5 text-amber-400" />
              <span>注意事项</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.livingAdvice.precautions.map((item, index) => (
                <li key={index} className="flex items-start space-x-2 text-slate-300">
                  <Info className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* 结语 */}
      <Card className="bg-gradient-to-r from-slate-800/50 to-slate-700/50 border-slate-600">
        <CardContent className="p-6 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <MapPin className="w-6 h-6 text-indigo-400" />
            <h3 className="text-xl font-semibold text-white">分析总结</h3>
          </div>
          <p className="text-slate-300 leading-relaxed max-w-4xl mx-auto">
            基于全年 {data.length} 小时的气象数据分析，{config.locationName} 属于
            <span className="text-purple-400 font-medium"> {analysis.climateType.classification}</span>。
            该地区{analysis.temperatureProfile.description.toLowerCase()}，
            {analysis.precipitationProfile.description.toLowerCase()}，
            {analysis.humidityProfile.description.toLowerCase()}。
            建议居民根据当地气候特点合理安排生活和工作，特别注意
            <span className="text-yellow-400 font-medium"> {analysis.extremeWeather.riskLevel}</span>
            的极端天气影响。
          </p>
          <div className="mt-4 text-xs text-slate-400">
            * 本分析基于实际气象数据，仅供参考。具体天气变化请关注当地气象预报。
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
