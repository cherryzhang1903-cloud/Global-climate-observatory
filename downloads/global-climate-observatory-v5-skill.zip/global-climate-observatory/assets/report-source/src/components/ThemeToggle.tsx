/**
 * 主题切换按钮
 * - 切换 html 的 .dark 类，实现深浅模式
 * - 持久化到 localStorage('theme')
 */
import React, { useEffect, useState } from 'react'
import { Button } from './ui/button'
import { Moon, Sun } from 'lucide-react'

/** 读取当前是否为暗色主题 */
function getIsDark(): boolean {
  return document.documentElement.classList.contains('dark')
}

/** 应用主题到 html */
function setTheme(theme: 'dark' | 'light') {
  if (theme === 'dark') document.documentElement.classList.add('dark')
  else document.documentElement.classList.remove('dark')
  localStorage.setItem('theme', theme)
  // 可选：派发事件，便于其他组件订阅
  window.dispatchEvent(new CustomEvent('themechange', { detail: { theme } }))
}

/** 主题切换按钮组件 */
export default function ThemeToggle() {
  const [isDark, setIsDark] = useState<boolean>(true)

  useEffect(() => {
    // 初始同步
    setIsDark(getIsDark())
    const handler = () => setIsDark(getIsDark())
    window.addEventListener('themechange', handler as EventListener)
    return () => window.removeEventListener('themechange', handler as EventListener)
  }, [])

  const toggle = () => {
    const next = isDark ? 'light' : 'dark'
    setTheme(next)
    setIsDark(!isDark)
  }

  return (
    <Button
      variant="outline"
      onClick={toggle}
      aria-label="切换主题"
      className="bg-white text-slate-900 border-slate-300 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-600 dark:hover:bg-slate-700"
    >
      {isDark ? (
        <>
          <Sun className="w-4 h-4 mr-2 text-amber-400" />
          浅色模式
        </>
      ) : (
        <>
          <Moon className="w-4 h-4 mr-2 text-cyan-400" />
          深色模式
        </>
      )}
    </Button>
  )
}
