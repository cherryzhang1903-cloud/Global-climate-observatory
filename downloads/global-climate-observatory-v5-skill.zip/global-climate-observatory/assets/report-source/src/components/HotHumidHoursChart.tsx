/**
 * 全年闷热小时数柱状图组件
 * 显示每月闷热小时数的分布情况
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Sun, Droplets, Thermometer, Calendar } from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface HotHumidHoursChartProps {
  data: WeatherData[];
  config: WeatherConfig;
}

interface DailyHotHumidData {
  date: string;
  dateStr: string;
  hotHumidHours: number;
  totalHours: number;
  percentage: number;
  avgTemp: number;
  avgHumidity: number;
  hotHours: number;
  humidHours: number;
  month: number;
  day: number;
}

interface MonthlyHotHumidData {
  month: number;
  monthName: string;
  shortName: string;
  hotHumidHours: number;
  totalHours: number;
  percentage: number;
  avgTemp: number;
  avgHumidity: number;
  hotHours: number;
  humidHours: number;
}

/**
 * 全年闷热小时数柱状图组件
 */
export default function HotHumidHoursChart({ data, config }: HotHumidHoursChartProps) {
  // 处理每日闷热小时数据
  const processDailyHotHumidData = (): DailyHotHumidData[] => {
    const dailyMap = new Map<string, {
      hotHumidHours: number;
      totalHours: number;
      hotHours: number;
      humidHours: number;
      tempSum: number;
      humiditySum: number;
      date: Date;
    }>();

    // 按日期分组
    data.forEach(item => {
      const date = new Date(item.datetime+'Z');
      const dateKey = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
      
      if (!dailyMap.has(dateKey)) {
        dailyMap.set(dateKey, {
          hotHumidHours: 0,
          totalHours: 0,
          hotHours: 0,
          humidHours: 0,
          tempSum: 0,
          humiditySum: 0,
          date: new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()))
        });
      }
      
      const dayData = dailyMap.get(dateKey)!;
      dayData.totalHours++;
      dayData.tempSum += item.temperature;
      dayData.humiditySum += item.humidity;
      
      // 闷热条件：高温且高湿
      if (item.temperature >= config.highTempThreshold && 
          item.humidity >= config.highHumidityThreshold) {
        dayData.hotHumidHours++;
      }
      
      // 单独统计高温小时数
      if (item.temperature >= config.highTempThreshold) {
        dayData.hotHours++;
      }
      
      // 单独统计高湿度小时数
      if (item.humidity >= config.highHumidityThreshold) {
        dayData.humidHours++;
      }
    });

    const dailyData: DailyHotHumidData[] = [];
    dailyMap.forEach((dayData, dateKey) => {
      if (dayData.totalHours === 0) return;
      
      dailyData.push({
        date: dateKey,
        dateStr: `${dayData.date.getUTCMonth() + 1}/${dayData.date.getUTCDate()}`,
        hotHumidHours: dayData.hotHumidHours,
        totalHours: dayData.totalHours,
        percentage: Math.round((dayData.hotHumidHours / dayData.totalHours) * 100 * 10) / 10,
        avgTemp: Math.round((dayData.tempSum / dayData.totalHours) * 10) / 10,
        avgHumidity: Math.round((dayData.humiditySum / dayData.totalHours) * 10) / 10,
        hotHours: dayData.hotHours,
        humidHours: dayData.humidHours,
        month: dayData.date.getUTCMonth() + 1,
        day: dayData.date.getUTCDate()
      });
    });

    return dailyData.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  // 处理月度闷热小时数据
  const processMonthlyHotHumidData = (): MonthlyHotHumidData[] => {
    const monthlyData = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      monthName: new Date(2024, i, 1).toLocaleDateString('zh-CN', { month: 'long' }),
      shortName: new Date(2024, i, 1).toLocaleDateString('zh-CN', { month: 'short' }),
      hotHumidHours: 0,
      totalHours: 0,
      percentage: 0,
      avgTemp: 0,
      avgHumidity: 0,
      hotHours: 0,
      humidHours: 0,
      tempSum: 0,
      humiditySum: 0
    }));

    data.forEach(item => {
      const date = new Date(item.datetime+'Z');
      const monthIndex = date.getUTCMonth();
      const monthData = monthlyData[monthIndex];
      
      monthData.totalHours++;
      monthData.tempSum += item.temperature;
      monthData.humiditySum += item.humidity;
      
      // 闷热条件：高温且高湿
      if (item.temperature >= config.highTempThreshold && 
          item.humidity >= config.highHumidityThreshold) {
        monthData.hotHumidHours++;
      }
      
      // 单独统计高温小时数
      if (item.temperature >= config.highTempThreshold) {
        monthData.hotHours++;
      }
      
      // 单独统计高湿度小时数
      if (item.humidity >= config.highHumidityThreshold) {
        monthData.humidHours++;
      }
    });

    return monthlyData.map(item => ({
      month: item.month,
      monthName: item.monthName,
      shortName: item.shortName,
      hotHumidHours: item.hotHumidHours,
      totalHours: item.totalHours,
      percentage: item.totalHours > 0 ? Math.round((item.hotHumidHours / item.totalHours) * 100 * 10) / 10 : 0,
      avgTemp: item.totalHours > 0 ? Math.round((item.tempSum / item.totalHours) * 10) / 10 : 0,
      avgHumidity: item.totalHours > 0 ? Math.round((item.humiditySum / item.totalHours) * 10) / 10 : 0,
      hotHours: item.hotHours,
      humidHours: item.humidHours
    }));
  };

  // 计算年度统计
  const calculateYearlyStats = (dailyData: DailyHotHumidData[]) => {
    const totalHotHumidHours = dailyData.reduce((sum, day) => sum + day.hotHumidHours, 0);
    const totalHours = dailyData.reduce((sum, day) => sum + day.totalHours, 0);
    const peakDay = dailyData.reduce((peak, day) => 
      day.hotHumidHours > peak.hotHumidHours ? day : peak
    );
    const avgPercentage = totalHours > 0 ? Math.round((totalHotHumidHours / totalHours) * 100 * 10) / 10 : 0;
    
    // 计算最热的月份
    const monthlyStats = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      hotHumidHours: 0
    }));
    
    dailyData.forEach(day => {
      monthlyStats[day.month - 1].hotHumidHours += day.hotHumidHours;
    });
    
    const peakMonth = monthlyStats.reduce((peak, month) => 
      month.hotHumidHours > peak.hotHumidHours ? month : peak
    );

    return {
      totalHotHumidHours,
      totalHours,
      peakDay,
      peakMonth: {
        month: peakMonth.month,
        shortName: new Date(2024, peakMonth.month - 1, 1).toLocaleDateString('zh-CN', { month: 'short' })
      },
      avgPercentage,
      peakDayHours: peakDay.hotHumidHours,
      totalDays: dailyData.length
    };
  };

  const dailyData = processDailyHotHumidData();
  const monthlyData = processMonthlyHotHumidData();
  const yearlyStats = calculateYearlyStats(dailyData);

  /**
   * 每日数据工具提示
   */
  const DailyTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">日期: {label}</p>
          <p className="text-orange-600 dark:text-orange-400 text-sm">闷热小时数: {data.hotHumidHours}/24小时</p>
          <p className="text-yellow-400 text-sm">闷热占比: {data.percentage}%</p>
          <p className="text-red-600 dark:text-red-400 text-sm">日平均温度: {data.avgTemp}°C</p>
          <p className="text-blue-600 dark:text-blue-400 text-sm">日平均湿度: {data.avgHumidity}%</p>
          <p className="text-green-600 dark:text-green-400 text-sm">高温小时: {data.hotHours}</p>
          <p className="text-cyan-600 dark:text-cyan-400 text-sm">高湿小时: {data.humidHours}</p>
        </div>
      );
    }
    return null;
  };

  /**
   * 月度数据工具提示
   */
  const MonthlyTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{label}</p>
          <p className="text-orange-600 dark:text-orange-400 text-sm">闷热小时数: {data.hotHumidHours}</p>
          <p className="text-yellow-400 text-sm">占比: {data.percentage}%</p>
          <p className="text-red-600 dark:text-red-400 text-sm">平均温度: {data.avgTemp}°C</p>
          <p className="text-blue-600 dark:text-blue-400 text-sm">平均湿度: {data.avgHumidity}%</p>
          <p className="text-slate-600 dark:text-slate-300 text-xs">总小时数: {data.totalHours}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* 年度闷热统计概览 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-orange-900/20 to-red-900/20 border-orange-800/30">
          <CardContent className="p-4 text-center">
            <Sun className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{yearlyStats.totalHotHumidHours}</p>
            <p className="text-xs text-slate-600 dark:text-slate-300">全年闷热小时</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-900/20 to-orange-900/20 border-yellow-800/30">
          <CardContent className="p-4 text-center">
            <Thermometer className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-yellow-400">{yearlyStats.avgPercentage}%</p>
            <p className="text-xs text-slate-600 dark:text-slate-300">全年占比</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-900/20 to-pink-900/20 border-red-800/30">
          <CardContent className="p-4 text-center">
            <Calendar className="w-6 h-6 text-red-600 dark:text-red-400 mx-auto mb-2" />
            <p className="text-lg font-bold text-red-600 dark:text-red-400">{yearlyStats.totalHotHumidHours ? yearlyStats.peakDay.dateStr : '无事件'}</p>
            <p className="text-xs text-slate-600 dark:text-slate-300">闷热峰值日</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/20 to-purple-900/20 border-pink-800/30">
          <CardContent className="p-4 text-center">
            <Droplets className="w-6 h-6 text-pink-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-pink-400">{yearlyStats.peakDayHours}</p>
            <p className="text-xs text-slate-600 dark:text-slate-300">单日最高小时</p>
          </CardContent>
        </Card>
      </div>

      {/* 全年每日闷热小时数分布曲线 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
                <Sun className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                <span>{config.locationName} 全年每日闷热小时数分布</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                闷热条件：温度 ≥ {config.highTempThreshold}°C 且 湿度 ≥ {config.highHumidityThreshold}% (显示 {dailyData.length} 天数据)
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              <Badge variant="outline" className="border-orange-400 text-orange-600 dark:text-orange-400">
                每日闷热小时
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailyData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="dateStr" 
                  stroke="#9ca3af"
                  fontSize={9}
                  interval={Math.max(0, Math.floor(dailyData.length / 25))}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                  tick={{ fontSize: 9 }}
                />
                <YAxis 
                  stroke="#9ca3af"
                  fontSize={12}
                  domain={[0, 24]}
                  ticks={[0, 6, 12, 18, 24]}
                  label={{ value: '闷热小时数 (小时/天)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9ca3af' } }}
                />
                <Tooltip content={<DailyTooltip />} />
                <Legend />
                
                {/* 每日闷热小时数曲线 */}
                <Line isAnimationActive={false}
                  type="monotone"
                  dataKey="hotHumidHours"
                  stroke="#fb923c"
                  strokeWidth={2}
                  dot={false}
                  name="闷热小时数"
                />
                
                {/* 12小时参考线（一半时间闷热） */}
                <Line isAnimationActive={false}
                  type="monotone"
                  dataKey={() => 12}
                  stroke="#f59e0b"
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  dot={false}
                  name="12小时参考线"
                />
                
                {/* 18小时参考线（3/4时间闷热） */}
                <Line isAnimationActive={false}
                  type="monotone"
                  dataKey={() => 18}
                  stroke="#ef4444"
                  strokeDasharray="3 3"
                  strokeWidth={2}
                  dot={false}
                  name="18小时参考线"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 高温vs闷热小时数对比分析 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
            <Thermometer className="w-5 h-5 text-red-600 dark:text-red-400" />
            <span>高温vs闷热小时数对比</span>
          </CardTitle>
          <CardDescription className="text-slate-600 dark:text-slate-300">
            单纯高温与闷热条件（高温+高湿）的小时数对比分析
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="shortName" 
                  stroke="#9ca3af"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9ca3af"
                  fontSize={12}
                  label={{ value: '小时数', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9ca3af' } }}
                />
                <Tooltip content={<MonthlyTooltip />} />
                <Legend />
                
                <Bar isAnimationActive={false} dataKey="hotHours" fill="#ef4444" name="高温小时数" radius={[2, 2, 0, 0]} />
                <Bar isAnimationActive={false} dataKey="hotHumidHours" fill="#fb923c" name="闷热小时数" radius={[2, 2, 0, 0]} />
                <Bar isAnimationActive={false} dataKey="humidHours" fill="#3b82f6" name="高湿小时数" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
