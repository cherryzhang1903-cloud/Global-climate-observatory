/**
 * 数据概览组件
 * 显示天气数据的关键统计信息
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Thermometer, 
  Droplets, 
  Wind, 
  Gauge, 
  CloudRain,
  Sun,
  Cloud,
  Snowflake,
  Zap
} from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface DataSummaryProps {
  data: WeatherData[];
  config: WeatherConfig;
}

/**
 * 数据概览组件
 */
export default function DataSummary({ data, config }: DataSummaryProps) {
  // 计算综合统计数据
  const calculateSummaryStats = () => {
    if (data.length === 0) return null;

    const temperatures = data.map(d => d.temperature);
    const humidities = data.map(d => d.humidity);
    const precipitations = data.map(d => d.precipitation);
    const windSpeeds = data.map(d => d.windSpeed);
    const pressures = data.map(d => d.pressure);


    // 基础统计
    const tempStats = {
      max: Math.max(...temperatures),
      min: Math.min(...temperatures),
      avg: temperatures.reduce((sum, temp) => sum + temp, 0) / temperatures.length
    };

    const humidityStats = {
      max: Math.max(...humidities),
      min: Math.min(...humidities),
      avg: humidities.reduce((sum, humidity) => sum + humidity, 0) / humidities.length
    };

    const precipitationStats = {
      total: precipitations.reduce((sum, precip) => sum + precip, 0),
      max: Math.max(...precipitations),
      avg: precipitations.reduce((sum, precip) => sum + precip, 0) / precipitations.length
    };

    const windStats = {
      max: Math.max(...windSpeeds),
      avg: windSpeeds.reduce((sum, wind) => sum + wind, 0) / windSpeeds.length
    };

    const pressureStats = {
      max: Math.max(...pressures),
      min: Math.min(...pressures),
      avg: pressures.reduce((sum, pressure) => sum + pressure, 0) / pressures.length
    };



    // 特殊天气统计
    const specialWeather = {
      highTempHours: data.filter(d => d.temperature >= config.highTempThreshold).length,
      extremeHot35Hours: data.filter(d => d.temperature >= 35).length,
      extremeHot40Hours: data.filter(d => d.temperature >= 40).length,
      lowTempHours: data.filter(d => d.temperature <= config.lowTempThreshold).length,
      rainyHours: data.filter(d => d.precipitation > 0.1).length,
      windyHours: data.filter(d => d.windSpeed > 10).length,
      comfortableHours: data.filter(d => 
        d.temperature >= 18 && d.temperature <= 25 && 
        d.humidity >= 40 && d.humidity <= 60
      ).length,
      hotHumidHours: data.filter(d => 
        d.temperature >= config.highTempThreshold && 
        d.humidity >= config.highHumidityThreshold
      ).length,
      coldHumidHours: data.filter(d => 
        d.temperature <= config.lowTempThreshold && 
        d.humidity >= config.highHumidityThreshold
      ).length
    };

    return {
      tempStats: {
        ...tempStats,
        max: Math.round(tempStats.max * 10) / 10,
        min: Math.round(tempStats.min * 10) / 10,
        avg: Math.round(tempStats.avg * 10) / 10
      },
      humidityStats: {
        ...humidityStats,
        avg: Math.round(humidityStats.avg * 10) / 10
      },
      precipitationStats: {
        ...precipitationStats,
        total: Math.round(precipitationStats.total * 10) / 10,
        max: Math.round(precipitationStats.max * 10) / 10,
        avg: Math.round(precipitationStats.avg * 10) / 10
      },
      windStats: {
        ...windStats,
        max: Math.round(windStats.max * 10) / 10,
        avg: Math.round(windStats.avg * 10) / 10
      },
      pressureStats: {
        ...pressureStats,
        max: Math.round(pressureStats.max * 10) / 10,
        min: Math.round(pressureStats.min * 10) / 10,
        avg: Math.round(pressureStats.avg * 10) / 10
      },

      specialWeather,
      totalHours: data.length
    };
  };

  const stats = calculateSummaryStats();

  if (!stats) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="p-6 text-center text-slate-400">
          暂无数据统计
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* 基础气象要素统计 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 温度统计 */}
        <Card className="bg-gradient-to-br from-red-900/20 to-orange-900/20 border-red-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Thermometer className="w-6 h-6 text-red-400" />
              <Badge variant="outline" className="border-red-400 text-red-400 text-xs">
                °C
              </Badge>
            </div>
            <CardTitle className="text-lg text-white">温度统计</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">最高</span>
              <span className="text-lg font-bold text-red-400">{stats.tempStats.max}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">平均</span>
              <span className="text-lg font-bold text-orange-400">{stats.tempStats.avg}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">最低</span>
              <span className="text-lg font-bold text-blue-400">{stats.tempStats.min}</span>
            </div>
          </CardContent>
        </Card>

        {/* 湿度统计 */}
        <Card className="bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-blue-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Droplets className="w-6 h-6 text-blue-400" />
              <Badge variant="outline" className="border-blue-400 text-blue-400 text-xs">
                %
              </Badge>
            </div>
            <CardTitle className="text-lg text-white">湿度统计</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">最高</span>
              <span className="text-lg font-bold text-blue-400">{stats.humidityStats.max}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">平均</span>
              <span className="text-lg font-bold text-cyan-400">{stats.humidityStats.avg}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">最低</span>
              <span className="text-lg font-bold text-slate-400">{stats.humidityStats.min}</span>
            </div>
          </CardContent>
        </Card>

        {/* 降水统计 */}
        <Card className="bg-gradient-to-br from-green-900/20 to-emerald-900/20 border-green-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CloudRain className="w-6 h-6 text-green-400" />
              <Badge variant="outline" className="border-green-400 text-green-400 text-xs">
                mm
              </Badge>
            </div>
            <CardTitle className="text-lg text-white">降水统计</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">总量</span>
              <span className="text-lg font-bold text-green-400">{stats.precipitationStats.total}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">单日最大</span>
              <span className="text-lg font-bold text-emerald-400">{stats.precipitationStats.max}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">日均</span>
              <span className="text-lg font-bold text-teal-400">{stats.precipitationStats.avg}</span>
            </div>
          </CardContent>
        </Card>

        {/* 风速统计 */}
        <Card className="bg-gradient-to-br from-purple-900/20 to-indigo-900/20 border-purple-800/30">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Wind className="w-6 h-6 text-purple-400" />
              <Badge variant="outline" className="border-purple-400 text-purple-400 text-xs">
                m/s
              </Badge>
            </div>
            <CardTitle className="text-lg text-white">风速统计</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">最大</span>
              <span className="text-lg font-bold text-purple-400">{stats.windStats.max}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">平均</span>
              <span className="text-lg font-bold text-indigo-400">{stats.windStats.avg}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-300">气压</span>
              <span className="text-lg font-bold text-violet-400">{stats.pressureStats.avg}</span>
            </div>
          </CardContent>
        </Card>


      </div>

      {/* 特殊天气统计 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Sun className="w-5 h-5 text-yellow-400" />
              <span>特殊天气统计</span>
            </CardTitle>
            <CardDescription className="text-slate-300">
              各种特殊天气现象的出现频次
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sun className="w-4 h-4 text-red-400" />
                  <span className="text-slate-300">高温小时数 (≥{config.highTempThreshold}°C)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.highTempHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-red-400 font-medium w-8">{stats.specialWeather.highTempHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sun className="w-4 h-4 text-orange-500" />
                  <span className="text-slate-300">极端高温 (≥35°C)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.extremeHot35Hours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-orange-500 font-medium w-8">{stats.specialWeather.extremeHot35Hours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sun className="w-4 h-4 text-red-600" />
                  <span className="text-slate-300">危险高温 (≥40°C)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.extremeHot40Hours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-red-600 font-medium w-8">{stats.specialWeather.extremeHot40Hours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Snowflake className="w-4 h-4 text-blue-400" />
                  <span className="text-slate-300">低温小时数 (≤{config.lowTempThreshold}°C)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.lowTempHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-blue-400 font-medium w-8">{stats.specialWeather.lowTempHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CloudRain className="w-4 h-4 text-green-400" />
                  <span className="text-slate-300">降水小时数 (&gt;0.1mm)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.rainyHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-green-400 font-medium w-8">{stats.specialWeather.rainyHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Wind className="w-4 h-4 text-purple-400" />
                  <span className="text-slate-300">大风小时数 (&gt;10m/s)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.windyHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-purple-400 font-medium w-8">{stats.specialWeather.windyHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Cloud className="w-4 h-4 text-teal-400" />
                  <span className="text-slate-300">舒适小时数 (18-25°C, 40-60%)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.comfortableHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-teal-400 font-medium w-8">{stats.specialWeather.comfortableHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Sun className="w-4 h-4 text-orange-400" />
                  <Droplets className="w-4 h-4 text-red-400" />
                  <span className="text-slate-300">闷热小时数 (≥{config.highTempThreshold}°C & ≥{config.highHumidityThreshold}%)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.hotHumidHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-orange-400 font-medium w-8">{stats.specialWeather.hotHumidHours}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Snowflake className="w-4 h-4 text-cyan-400" />
                  <Droplets className="w-4 h-4 text-blue-600" />
                  <span className="text-slate-300">湿冷小时数 (≤{config.lowTempThreshold}°C & ≥{config.highHumidityThreshold}%)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Progress 
                    value={(stats.specialWeather.coldHumidHours / stats.totalHours) * 100} 
                    className="w-20 h-2" 
                  />
                  <span className="text-cyan-400 font-medium w-8">{stats.specialWeather.coldHumidHours}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Gauge className="w-5 h-5 text-amber-400" />
              <span>数据质量报告</span>
            </CardTitle>
            <CardDescription className="text-slate-300">
              数据完整性和质量评估
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-slate-700/30 rounded-lg">
                <p className="text-2xl font-bold text-green-400">{stats.totalHours}</p>
                <p className="text-sm text-slate-300">总小时数</p>
              </div>
              <div className="text-center p-4 bg-slate-700/30 rounded-lg">
                <p className="text-2xl font-bold text-blue-400">100%</p>
                <p className="text-sm text-slate-300">数据完整率</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-300 text-sm">温度数据</span>
                <Badge variant="outline" className="border-green-400 text-green-400">
                  完整
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300 text-sm">湿度数据</span>
                <Badge variant="outline" className="border-green-400 text-green-400">
                  完整
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300 text-sm">降水数据</span>
                <Badge variant="outline" className="border-green-400 text-green-400">
                  完整
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300 text-sm">风速数据</span>
                <Badge variant="outline" className="border-green-400 text-green-400">
                  完整
                </Badge>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-600">
              <p className="text-xs text-slate-400">
                数据时间范围: {config.startDate} 至 {config.endDate}
              </p>
              <p className="text-xs text-slate-400">
                数据来源: 模拟气象数据生成器
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}