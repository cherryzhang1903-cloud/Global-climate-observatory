import {aggregateReport} from '../utils/stats.mjs'
/**
 * HeatStressClassificationChart.tsx
 * 干热 / 湿热等级全年小时数统计组件
 *
 * - 优先使用上传数据中已有的 DWPT / dewPoint 列作为露点温度
 * - 若无 DWPT，则使用温度 T 与相对湿度估算露点温度
 * - 按截图给出的 HH1–HH4（湿热）、AH1–AH4（干热）分级规则统计小时数
 * - 结果通过汇总卡片 + 柱状图 + 等级明细表展示
 */

import React, { useMemo } from 'react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Flame, Droplets } from 'lucide-react'
import type { WeatherConfig, WeatherData } from '../pages/Home'

/** 干热 / 湿热等级编码（湿热） */
type HumidLevel = 'HH1' | 'HH2' | 'HH3' | 'HH4'
/** 干热 / 湿热等级编码（干热） */
type DryLevel = 'AH1' | 'AH2' | 'AH3' | 'AH4'

/**
 * 组件属性：传入小时级天气数据与配置
 */
interface HeatStressClassificationChartProps {
  /** 小时级天气数据 */
  data: WeatherData[]
  /** 配置信息（仅用于标题展示） */
  config: WeatherConfig
}

/**
 * 使用温度和相对湿度估算露点温度（DWPT，单位 ℃）
 * - 采用 Magnus 公式近似：适用于一般气候分析
 * - 若数据异常（湿度 ≤0 或 >100 等）则返回 null
 */
function estimateDewPoint(tempC: number, humidityPercent: number): number | null {
  if (!Number.isFinite(tempC) || !Number.isFinite(humidityPercent)) return null
  if (humidityPercent <= 0 || humidityPercent > 100) return null

  const a = 17.62
  const b = 243.12
  const rh = humidityPercent / 100
  const alpha = (a * tempC) / (b + tempC) + Math.log(rh)
  const dewPoint = (b * alpha) / (a - alpha)

  return dewPoint
}

/**
 * 从单条记录中获取露点温度：
 * - 优先使用上传文件中已有的字段：dewPoint / DWPT / dwpt / DewPoint / dew_point
 * - 若不存在或为无效数值，则退回到温度 + 相对湿度估算
 */
function getDewPointFromRecord(item: WeatherData): number | null {
  const raw =
    // 推荐字段
    (item as any).dewPoint ??
    // 常见原始列名
    (item as any).DWPT ??
    (item as any).dwpt ??
    (item as any)['DewPoint'] ??
    (item as any)['dew_point']

  const numeric = Number(raw)
  if (Number.isFinite(numeric)) {
    return numeric
  }

  // 兜底：用温度 + 相对湿度估算
  const temp = Number((item as any).temperature)
  const rh = Number((item as any).humidity)
  return estimateDewPoint(temp, rh)
}

/**
 * 干热 / 湿热等级统计结果结构
 */
interface HeatStressStats {
  /** 湿热等级统计（HH1–HH4） */
  humid: Record<HumidLevel, number>
  /** 干热等级统计（AH1–AH4） */
  dry: Record<DryLevel, number>
  /** 有效参与分级计算的总小时数（具备有效 DWPT 与温度） */
  classifiedHours: number
  /** 原始数据总小时数（即 data.length） */
  totalHours: number
}

/**
 * 依据温度 T 与露点温度 DWPT，对全年数据进行干热 / 湿热等级统计
 *
 * 湿热分级（HH）——与截图保持一致：
 *  - HH1：26 ≤ T ＜ 30 且 20 ≤ DWPT ＜ 24
 *  - HH2：26 ≤ T ＜ 30 且 DWPT ≥ 24，或 30 ≤ T ＜ 35 且 20 ≤ DWPT ＜ 24
 *  - HH3：30 ≤ T ＜ 35 且 DWPT ≥ 24，或 T ≥ 35 且 20 ≤ DWPT ＜ 24
 *  - HH4：T ≥ 35 且 DWPT ≥ 24
 *
 * 干热分级（AH）：
 *  - AH1：35 ≤ T ＜ 40 且 10 ＜ DWPT ≤ 15
 *  - AH2：35 ≤ T ＜ 40 且 DWPT ≤ 10，或 T ≥ 40 且 10 ＜ DWPT ≤ 15
 *  - AH3：T ≥ 40 且 5 ＜ DWPT ≤ 10
 *  - AH4：T ≥ 40 且 DWPT ≤ 5
 */
function useHeatStressStats(data: WeatherData[]): HeatStressStats {
 return useMemo(()=>{const s=aggregateReport(data);return {humid:{HH1:s.heat.HH1,HH2:s.heat.HH2,HH3:s.heat.HH3,HH4:s.heat.HH4},dry:{AH1:s.heat.AH1,AH2:s.heat.AH2,AH3:s.heat.AH3,AH4:s.heat.AH4},classifiedHours:s.jointHours,totalHours:data.length}},[data]);
}

function HeatStressTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null

  const item = payload[0]

  return (
    <div className="rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-xs shadow-lg">
      <p className="mb-1 font-medium text-white">{item.payload.label}</p>
      <p style={{ color: item.color }}>
        小时数：<span className="font-semibold">{item.value}</span>
      </p>
    </div>
  )
}

/**
 * 干热 / 湿热等级全年小时数统计图表组件
 */
export default function HeatStressClassificationChart({
  data,
  config,
}: HeatStressClassificationChartProps) {
  const stats = useHeatStressStats(data)

  const humidTotal =
    stats.humid.HH1 + stats.humid.HH2 + stats.humid.HH3 + stats.humid.HH4
  const dryTotal =
    stats.dry.AH1 + stats.dry.AH2 + stats.dry.AH3 + stats.dry.AH4

  /**
   * 计算百分比显示（保留 1 位小数）
   * - base 为 0 时返回 '0.0'
   */
  const percent = (value: number, base: number) =>
    base > 0 ? ((value / base) * 100).toFixed(1) : '0.0'

  /** 湿热等级图表数据 */
  const humidChartData: Array<{ key: HumidLevel; label: string; hours: number }> = [
    {
      key: 'HH1',
      label: 'HH1 (26≤T＜30, 20≤DWPT＜24)',
      hours: stats.humid.HH1,
    },
    {
      key: 'HH2',
      label: 'HH2 (26≤T＜30 且 DWPT≥24; 或 30≤T＜35 且 20≤DWPT＜24)',
      hours: stats.humid.HH2,
    },
    {
      key: 'HH3',
      label: 'HH3 (30≤T＜35 且 DWPT≥24; 或 T≥35 且 20≤DWPT＜24)',
      hours: stats.humid.HH3,
    },
    {
      key: 'HH4',
      label: 'HH4 (T≥35 且 DWPT≥24)',
      hours: stats.humid.HH4,
    },
  ]

  /** 干热等级图表数据 */
  const dryChartData: Array<{ key: DryLevel; label: string; hours: number }> = [
    {
      key: 'AH1',
      label: 'AH1 (35≤T＜40, 10＜DWPT≤15)',
      hours: stats.dry.AH1,
    },
    {
      key: 'AH2',
      label: 'AH2 (35≤T＜40, DWPT≤10; 或T≥40, 10＜DWPT≤15)',
      hours: stats.dry.AH2,
    },
    {
      key: 'AH3',
      label: 'AH3 (T≥40, 5＜DWPT≤10)',
      hours: stats.dry.AH3,
    },
    {
      key: 'AH4',
      label: 'AH4 (T≥40, DWPT≤5)',
      hours: stats.dry.AH4,
    },
  ]

  /** 湿热等级明细数据（含占比） */
  const humidDetails = humidChartData.map((item) => {
    const hours = item.hours
    return {
      ...item,
      percentOfClassified: percent(hours, stats.classifiedHours),
      percentOfHumid: percent(hours, humidTotal),
    }
  })

  /** 干热等级明细数据（含占比） */
  const dryDetails = dryChartData.map((item) => {
    const hours = item.hours
    return {
      ...item,
      percentOfClassified: percent(hours, stats.classifiedHours),
      percentOfDry: percent(hours, dryTotal),
    }
  })

  return (
    <Card className="border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-800/60">
      <CardHeader className="pb-3">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-slate-900 dark:text-white">
              <Flame className="h-5 w-5 text-orange-400" />
              <Droplets className="h-5 w-5 text-cyan-400" />
              <span>{config.locationName} 干热 / 湿热等级统计</span>
            </CardTitle>
            <CardDescription className="text-slate-600 dark:text-slate-300">
              按 HH1–HH4（湿热）、AH1–AH4（干热）分级规则，对全年每小时进行热环境类型划分并统计出现频次
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge
              variant="outline"
              className="border-cyan-400 text-cyan-500 dark:border-cyan-500 dark:text-cyan-300"
            >
              湿热 HH1–HH4
            </Badge>
            <Badge
              variant="outline"
              className="border-orange-400 text-orange-500 dark:border-orange-500 dark:text-orange-300"
            >
              干热 AH1–AH4
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-5">
        {/* 汇总统计卡片 */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  有效参与分级的小时数
                </p>
                <p className="mt-1 text-2xl font-semibold text-slate-900 dark:text-white">
                  {stats.classifiedHours.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  占原始数据的 {percent(stats.classifiedHours, stats.totalHours)}%
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-cyan-50/80 dark:border-slate-700 dark:bg-cyan-900/30">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-cyan-800 dark:text-cyan-200">
                  全年湿热小时数（HH1–HH4）
                </p>
                <p className="mt-1 text-2xl font-semibold text-cyan-900 dark:text-cyan-100">
                  {humidTotal.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-cyan-800/80 dark:text-cyan-200/80">
                  占参与分级小时数的 {percent(humidTotal, stats.classifiedHours)}%
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-orange-50/80 dark:border-slate-700 dark:bg-orange-900/30">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="text-xs text-orange-800 dark:text-orange-200">
                  全年干热小时数（AH1–AH4）
                </p>
                <p className="mt-1 text-2xl font-semibold text-orange-900 dark:text-orange-100">
                  {dryTotal.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-orange-800/80 dark:text-orange-200/80">
                  占参与分级小时数的 {percent(dryTotal, stats.classifiedHours)}%
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 湿热 / 干热等级分布图（水平柱状图） */}
        <div className="grid gap-5 md:grid-cols-2">
          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Droplets className="h-4 w-4 text-cyan-400" />
                湿热等级分布（HH）
              </CardTitle>
              <CardDescription className="text-xs text-slate-600 dark:text-slate-300">
                依据 HH1–HH4 湿热分级标准，统计全年各等级对应的小时数
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={humidChartData}
                    layout="vertical"
                    margin={{ top: 12, right: 24, bottom: 8, left: 80 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="#e5e7eb"
                      className="dark:stroke-slate-700"
                    />
                    <XAxis
                      type="number"
                      stroke="#64748b"
                      tick={{ fontSize: 11, fill: 'currentColor' }}
                    />
                    <YAxis
                      type="category"
                      dataKey="key"
                      stroke="#64748b"
                      tick={{ fontSize: 11, fill: 'currentColor' }}
                    />
                    <Tooltip content={<HeatStressTooltip />} />
                    <Bar isAnimationActive={false}
                      dataKey="hours"
                      name="小时数"
                      fill="#22d3ee"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-900/40">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Flame className="h-4 w-4 text-orange-400" />
                干热等级分布（AH）
              </CardTitle>
              <CardDescription className="text-xs text-slate-600 dark:text-slate-300">
                依据 AH1–AH4 干热分级标准，统计全年各等级对应的小时数
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={dryChartData}
                    layout="vertical"
                    margin={{ top: 12, right: 24, bottom: 8, left: 80 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="#e5e7eb"
                      className="dark:stroke-slate-700"
                    />
                    <XAxis
                      type="number"
                      stroke="#64748b"
                      tick={{ fontSize: 11, fill: 'currentColor' }}
                    />
                    <YAxis
                      type="category"
                      dataKey="key"
                      stroke="#64748b"
                      tick={{ fontSize: 11, fill: 'currentColor' }}
                    />
                    <Tooltip content={<HeatStressTooltip />} />
                    <Bar isAnimationActive={false}
                      dataKey="hours"
                      name="小时数"
                      fill="#fb923c"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 干热 / 湿热等级详细数据表 */}
        <div className="grid gap-5 md:grid-cols-2">
          <Card className="border-slate-200 bg-slate-50/70 dark:border-slate-700 dark:bg-slate-900/40">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Droplets className="h-4 w-4 text-cyan-400" />
                湿热等级明细（HH1–HH4）
              </CardTitle>
              <CardDescription className="text-xs text-slate-600 dark:text-slate-300">
                列出各湿热等级对应的小时数及其在全部参与分级小时数与湿热总小时数中的占比
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="overflow-hidden rounded-md border border-slate-200 bg-white text-xs dark:border-slate-700 dark:bg-slate-900">
                <table className="min-w-full table-auto">
                  <thead className="bg-slate-50/80 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">等级</th>
                      <th className="px-3 py-2 text-left font-medium">条件说明</th>
                      <th className="px-3 py-2 text-right font-medium">小时数</th>
                      <th className="px-3 py-2 text-right font-medium">占全部分级</th>
                      <th className="px-3 py-2 text-right font-medium">占湿热总计</th>
                    </tr>
                  </thead>
                  <tbody>
                    {humidDetails.map((row) => (
                      <tr
                        key={row.key}
                        className="border-t border-slate-100 text-slate-700 dark:border-slate-800 dark:text-slate-200"
                      >
                        <td className="px-3 py-2">{row.key}</td>
                        <td className="px-3 py-2">{row.label}</td>
                        <td className="px-3 py-2 text-right">
                          {row.hours.toLocaleString()}
                        </td>
                        <td className="px-3 py-2 text-right">
                          {row.percentOfClassified}%
                        </td>
                        <td className="px-3 py-2 text-right">
                          {row.percentOfHumid}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 bg-slate-50/70 dark:border-slate-700 dark:bg-slate-900/40">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Flame className="h-4 w-4 text-orange-400" />
                干热等级明细（AH1–AH4）
              </CardTitle>
              <CardDescription className="text-xs text-slate-600 dark:text-slate-300">
                列出各干热等级对应的小时数及其在全部参与分级小时数与干热总小时数中的占比
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="overflow-hidden rounded-md border border-slate-200 bg-white text-xs dark:border-slate-700 dark:bg-slate-900">
                <table className="min-w-full table-auto">
                  <thead className="bg-slate-50/80 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">等级</th>
                      <th className="px-3 py-2 text-left font-medium">条件说明</th>
                      <th className="px-3 py-2 text-right font-medium">小时数</th>
                      <th className="px-3 py-2 text-right font-medium">占全部分级</th>
                      <th className="px-3 py-2 text-right font-medium">占干热总计</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dryDetails.map((row) => (
                      <tr
                        key={row.key}
                        className="border-t border-slate-100 text-slate-700 dark:border-slate-800 dark:text-slate-200"
                      >
                        <td className="px-3 py-2">{row.key}</td>
                        <td className="px-3 py-2">{row.label}</td>
                        <td className="px-3 py-2 text-right">
                          {row.hours.toLocaleString()}
                        </td>
                        <td className="px-3 py-2 text-right">
                          {row.percentOfClassified}%
                        </td>
                        <td className="px-3 py-2 text-right">
                          {row.percentOfDry}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}
