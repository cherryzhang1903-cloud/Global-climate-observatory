import {aggregateReport,valid,display} from '../utils/stats.mjs'
/**
 * 全年每小时温湿度图表组件
 * 显示全年8760小时的温度和湿度变化曲线
 */
import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ComposedChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Thermometer, Droplets, ZoomIn, ZoomOut, Calendar, Filter, Eye, RotateCcw } from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface HourlyTemperatureHumidityChartProps {
  data: WeatherData[];
  config: WeatherConfig;
}

interface ProcessedHourlyData {
  datetime: string;
  dateStr: string;
  temperature: number;
  humidity: number;
  hour: number;
  day: number;
  month: number;
}

/**
 * 全年每小时温湿度图表组件
 */
export default function HourlyTemperatureHumidityChart({ data, config }: HourlyTemperatureHumidityChartProps) {
  const [viewMode, setViewMode] = useState<'all' | 'month' | 'range'>('all');
  const [selectedMonth, setSelectedMonth] = useState<number>(1);
  const [timeRange, setTimeRange] = useState<[number, number]>([0, 100]);
  const [showTemperature, setShowTemperature] = useState(true);
  const [showHumidity, setShowHumidity] = useState(true);

  // 计算相关系数（移到前面）
  const calculateCorrelation = (x: number[], y: number[]): number => {
    const n = x.length;
    const sumX = x.reduce((a, b) => a + b, 0);
    const sumY = y.reduce((a, b) => a + b, 0);
    const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
    const sumXX = x.reduce((sum, xi) => sum + xi * xi, 0);
    const sumYY = y.reduce((sum, yi) => sum + yi * yi, 0);

    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumXX - sumX * sumX) * (n * sumYY - sumY * sumY));

    return denominator === 0 ? 0 : Math.round((numerator / denominator) * 1000) / 1000;
  };

  // 处理小时数据
  const processedData = useMemo((): ProcessedHourlyData[] => {
    return data.map(item => {
      const date = new Date(item.datetime+'Z');
      return {
        datetime: item.datetime,
        dateStr: date.toLocaleDateString('zh-CN', { timeZone: 'UTC', month: 'short', day: 'numeric', hour: 'numeric' }),
        temperature: valid(item.temperature) ? Math.round(item.temperature * 10) / 10 : null,
        humidity: valid(item.humidity) ? Math.round(item.humidity * 10) / 10 : null,
        hour: date.getUTCHours(),
        day: date.getUTCDate(),
        month: date.getUTCMonth() + 1
      };
    });
  }, [data]);

  // 根据视图模式筛选数据
  // 计算温度数据的实际范围
  const getTemperatureRange = useMemo(() => {
    if (processedData.length === 0) return { min: -20, max: 40 };
    
    const temperatures = processedData.map(d => d.temperature).filter(valid);
    const minTemp = Math.min(...temperatures);
    const maxTemp = Math.max(...temperatures);
    
    // 向下和向上取整到5的倍数
    const minTick = Math.floor(minTemp / 5) * 5 - 5;
    const maxTick = Math.ceil(maxTemp / 5) * 5 + 5;
    
    return { min: minTick, max: maxTick };
  }, [processedData]);

  const getDisplayData = useMemo(() => {
    let filteredData = processedData;

    switch (viewMode) {
      case 'month':
        filteredData = processedData.filter(item => item.month === selectedMonth);
        break;
      case 'range':
        const startIndex = Math.floor((timeRange[0] / 100) * processedData.length);
        const endIndex = Math.floor((timeRange[1] / 100) * processedData.length);
        filteredData = processedData.slice(startIndex, endIndex);
        break;
      default:
        // 全年数据，采样显示以提高性能
        const sampleRate = Math.max(1, Math.ceil(processedData.length / 2000));
        filteredData = processedData.filter((r,index)=>index % sampleRate===0 || ['temperature','humidity'].some(k=>valid(r[k])!==valid(processedData[index-1]?.[k]) || valid(r[k])!==valid(processedData[index+1]?.[k])));
        break;
    }

    return filteredData;
  }, [processedData, viewMode, selectedMonth, timeRange]);

  // 计算统计数据
  const calculateStats = useMemo(() => {
    const s=aggregateReport(data,config);
    const at=(key,value)=>{const r=processedData.find(r=>valid(r[key])&&r[key]===Math.round(value*10)/10);return r?r.datetime.replace('T',' '):'—'};
    return {tempStats:{max:display(s.maxTemp),min:display(s.minTemp),avg:display(s.meanTemp),maxTime:at('temperature',s.maxTemp),minTime:at('temperature',s.minTemp)},humidityStats:{max:display(s.maxHumidity),min:display(s.minHumidity),avg:display(s.meanHumidity),maxTime:at('humidity',s.maxHumidity),minTime:at('humidity',s.minHumidity)},correlation:display(s.correlation,3),totalHours:data.length};
  },[data,config,processedData]);



  /**
   * 自定义工具提示
   */
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{data.datetime.replace('T',' ')}</p>
          {showTemperature && (
            <p className="text-red-600 dark:text-red-400 text-sm">温度: {data.temperature}°C</p>
          )}
          {showHumidity && (
            <p className="text-blue-600 dark:text-blue-400 text-sm">湿度: {data.humidity}%</p>
          )}
        </div>
      );
    }
    return null;
  };

  const monthNames = [
    '1月', '2月', '3月', '4月', '5月', '6月',
    '7月', '8月', '9月', '10月', '11月', '12月'
  ];

  return (
    <div className="space-y-6">
      {/* 统计概览 */}
      {calculateStats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/20 border-red-800/30">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Thermometer className="w-5 h-5 text-red-600 dark:text-red-400" />
                <span className="text-slate-900 dark:text-white font-medium">温度统计</span>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">最高:</span>
                  <span className="text-red-600 dark:text-red-400 font-medium">{calculateStats.tempStats.max}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">最低:</span>
                  <span className="text-blue-600 dark:text-blue-400 font-medium">{calculateStats.tempStats.min}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">平均:</span>
                  <span className="text-green-600 dark:text-green-400 font-medium">{calculateStats.tempStats.avg}°C</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/20 border-blue-800/30">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Droplets className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span className="text-slate-900 dark:text-white font-medium">湿度统计</span>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">最高:</span>
                  <span className="text-blue-600 dark:text-blue-400 font-medium">{calculateStats.humidityStats.max}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">最低:</span>
                  <span className="text-cyan-600 dark:text-cyan-400 font-medium">{calculateStats.humidityStats.min}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">平均:</span>
                  <span className="text-teal-600 dark:text-teal-400 font-medium">{calculateStats.humidityStats.avg}%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/20 border-purple-800/30">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Calendar className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span className="text-slate-900 dark:text-white font-medium">数据信息</span>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">总小时:</span>
                  <span className="text-purple-600 dark:text-purple-400 font-medium">{calculateStats.totalHours}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">显示点:</span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-medium">{getDisplayData.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600 dark:text-slate-300">相关性:</span>
                  <span className={`font-medium ${calculateStats.correlation < 0 ? 'text-orange-600 dark:text-orange-400' : 'text-green-600 dark:text-green-400'}`}>
                    {calculateStats.correlation}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-900/20 to-green-800/20 border-green-800/30">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Eye className="w-5 h-5 text-green-600 dark:text-green-400" />
                <span className="text-slate-900 dark:text-white font-medium">显示控制</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showTemperature"
                    checked={showTemperature}
                    onChange={(e) => setShowTemperature(e.target.checked)}
                    className="rounded border-slate-300 dark:border-slate-600"
                  />
                  <label htmlFor="showTemperature" className="text-slate-600 dark:text-slate-300 text-sm">温度</label>
                </div>
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showHumidity"
                    checked={showHumidity}
                    onChange={(e) => setShowHumidity(e.target.checked)}
                    className="rounded border-slate-300 dark:border-slate-600"
                  />
                  <label htmlFor="showHumidity" className="text-slate-600 dark:text-slate-300 text-sm">湿度</label>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 控制面板 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
              <Filter className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
              <span>视图控制</span>
            </CardTitle>
            <Button
              onClick={() => {
                setViewMode('all');
                setTimeRange([0, 100]);
                setSelectedMonth(1);
              }}
              variant="outline"
              size="sm"
              className="bg-transparent border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-700"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              重置
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 视图模式选择 */}
            <div className="space-y-2">
              <label className="text-slate-600 dark:text-slate-300 text-sm">视图模式</label>
              <Select value={viewMode} onValueChange={(value: 'all' | 'month' | 'range') => setViewMode(value)}>
                <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全年概览</SelectItem>
                  <SelectItem value="month">按月查看</SelectItem>
                  <SelectItem value="range">自定义范围</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 月份选择 */}
            {viewMode === 'month' && (
              <div className="space-y-2">
                <label className="text-slate-600 dark:text-slate-300 text-sm">选择月份</label>
                <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(Number(value))}>
                  <SelectTrigger className="bg-white dark:bg-slate-800 border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {monthNames.map((month, index) => (
                      <SelectItem key={index} value={(index + 1).toString()}>
                        {month}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* 时间范围滑块 */}
            {viewMode === 'range' && (
              <div className="space-y-2">
                <label className="text-slate-600 dark:text-slate-300 text-sm">时间范围 ({timeRange[0]}% - {timeRange[1]}%)</label>
                <Slider
                  value={timeRange}
                  onValueChange={(value: number[]) => setTimeRange([value[0], value[1]])}
                  max={100}
                  min={0}
                  step={1}
                  className="w-full"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 全年每小时温湿度曲线 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
                <Thermometer className="w-5 h-5 text-red-600 dark:text-red-400" />
                <Droplets className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>{config.locationName} 全年每小时温湿度变化</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                {viewMode === 'all' && `全年${processedData.length}小时数据概览（采样显示）`}
                {viewMode === 'month' && `${monthNames[selectedMonth - 1]}详细数据`}
                {viewMode === 'range' && `时间范围: ${timeRange[0]}% - ${timeRange[1]}%`}
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              {showTemperature && (
                <Badge variant="outline" className="border-red-400 text-red-600 dark:text-red-400">
                  温度 (°C)
                </Badge>
              )}
              {showHumidity && (
                <Badge variant="outline" className="border-blue-400 text-blue-600 dark:text-blue-400">
                  湿度 (%)
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={getDisplayData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="dateStr" 
                  stroke="#9ca3af"
                  fontSize={10}
                  interval="preserveStartEnd"
                />
                <YAxis 
                  yAxisId="temp"
                  stroke="#ef4444"
                  fontSize={12}
                  type="number"
                  domain={[getTemperatureRange.min, getTemperatureRange.max]}
                  ticks={Array.from({ length: (getTemperatureRange.max - getTemperatureRange.min) / 5 + 1 }, (_, i) => getTemperatureRange.min + i * 5)}
                  interval={0}
                  label={{ value: '温度 (°C)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#ef4444' } }}
                />
                <YAxis 
                  yAxisId="humidity"
                  orientation="right"
                  stroke="#3b82f6"
                  fontSize={12}
                  domain={[0, 100]}
                  tickCount={6}
                  label={{ value: '湿度 (%)', angle: 90, position: 'insideRight', style: { textAnchor: 'middle', fill: '#3b82f6' } }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                
                {/* 温度曲线 */}
                {showTemperature && (
                  <Line isAnimationActive={false}
                    yAxisId="temp"
                    type="monotone"
                    dataKey="temperature"
                    stroke="#ef4444"
                    strokeWidth={1.5}
                    dot={false}
                    name="温度"
                  />
                )}
                
                {/* 湿度曲线 */}
                {showHumidity && (
                  <Line isAnimationActive={false}
                    yAxisId="humidity"
                    type="monotone"
                    dataKey="humidity"
                    stroke="#3b82f6"
                    strokeWidth={1.5}
                    dot={false}
                    name="湿度"
                  />
                )}
                
                {/* 阈值参考线 */}
                {showTemperature && (
                  <>
                    <ReferenceLine 
                      yAxisId="temp"
                      y={config.highTempThreshold} 
                      stroke="#f59e0b" 
                      strokeDasharray="5 5"
                      strokeWidth={2}
                      label={{ value: `高温阈值 ${config.highTempThreshold}°C`, position: "topLeft", fill: "#f59e0b", fontSize: 12 }}
                    />
                    <ReferenceLine 
                      yAxisId="temp"
                      y={config.lowTempThreshold} 
                      stroke="#06b6d4" 
                      strokeDasharray="5 5"
                      strokeWidth={2}
                      label={{ value: `低温阈值 ${config.lowTempThreshold}°C`, position: "bottomLeft", fill: "#06b6d4", fontSize: 12 }}
                    />
                  </>
                )}
                
                {showHumidity && (
                  <>
                    <ReferenceLine 
                      yAxisId="humidity"
                      y={config.highHumidityThreshold} 
                      stroke="#10b981" 
                      strokeDasharray="3 3"
                      strokeWidth={2}
                      label={{ value: `高湿度阈值 ${config.highHumidityThreshold}%`, position: "topRight", fill: "#10b981", fontSize: 12 }}
                    />
                    <ReferenceLine 
                      yAxisId="humidity"
                      y={config.lowHumidityThreshold} 
                      stroke="#f97316" 
                      strokeDasharray="3 3"
                      strokeWidth={2}
                      label={{ value: `低湿度阈值 ${config.lowHumidityThreshold}%`, position: "bottomRight", fill: "#f97316", fontSize: 12 }}
                    />
                  </>
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
