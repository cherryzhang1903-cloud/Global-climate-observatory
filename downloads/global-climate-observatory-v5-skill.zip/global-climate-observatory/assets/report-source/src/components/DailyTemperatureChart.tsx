import {aggregateReport,valid} from '../utils/stats.mjs';
/**
 * 每日温度图表组件
 * 显示每天的最高温度、最低温度和温度差值
 */
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, ReferenceLine } from 'recharts';
import { Thermometer, TrendingUp, TrendingDown, BarChart3, Calendar } from 'lucide-react';
import type { WeatherData, WeatherConfig } from '../pages/Home';

interface DailyTemperatureChartProps {
  data: WeatherData[];
  config: WeatherConfig;
}

interface DailyTempData {
  date: string;
  dateStr: string;
  maxTemp: number;
  minTemp: number;
  avgTemp: number;
  tempRange: number;
  month: number;
  day: number;
}

/**
 * 每日温度图表组件
 */
export default function DailyTemperatureChart({ data, config }: DailyTemperatureChartProps) {
  // 处理每日温度数据
  const processDailyData=()=>aggregateReport(data).daily.map(d=>({date:d.date,dateStr:Number(d.date.slice(5,7))+'/'+Number(d.date.slice(8,10)),maxTemp:d.max,minTemp:d.min,avgTemp:d.avg,tempRange:valid(d.max)&&valid(d.min)?d.max-d.min:null,month:Number(d.date.slice(5,7)),day:Number(d.date.slice(8,10))}));

  // 计算统计数据
  const calculateStats = (dailyData: DailyTempData[]) => {
    if (dailyData.length === 0) return null;

    const maxTemps = dailyData.map(d => d.maxTemp).filter(valid);
    const minTemps = dailyData.map(d => d.minTemp).filter(valid);
    const tempRanges = dailyData.map(d => d.tempRange).filter(valid);

    const absoluteMax = Math.max(...maxTemps);
    const absoluteMin = Math.min(...minTemps);
    const avgMaxTemp = maxTemps.reduce((sum, temp) => sum + temp, 0) / maxTemps.length;
    const avgMinTemp = minTemps.reduce((sum, temp) => sum + temp, 0) / minTemps.length;
    const avgTempRange = tempRanges.reduce((sum, range) => sum + range, 0) / tempRanges.length;
    const maxTempRange = Math.max(...tempRanges);

    // 极端天气统计
    const highTempDays = dailyData.filter(d => valid(d.maxTemp) && d.maxTemp >= config.highTempThreshold).length;
    const lowTempDays = dailyData.filter(d => valid(d.minTemp) && d.minTemp <= config.lowTempThreshold).length;
    const largeTempRangeDays = dailyData.filter(d => d.tempRange >= 15).length;

    return {
      absoluteMax: Math.round(absoluteMax * 10) / 10,
      absoluteMin: Math.round(absoluteMin * 10) / 10,
      avgMaxTemp: Math.round(avgMaxTemp * 10) / 10,
      avgMinTemp: Math.round(avgMinTemp * 10) / 10,
      avgTempRange: Math.round(avgTempRange * 10) / 10,
      maxTempRange: Math.round(maxTempRange * 10) / 10,
      highTempDays,
      lowTempDays,
      largeTempRangeDays,
      totalDays: dailyData.length
    };
  };

  const dailyData = processDailyData();
  const stats = calculateStats(dailyData);

  // 计算温度数据的实际范围
  const getTemperatureRange = () => {
    if (dailyData.length === 0) return { min: -20, max: 40 };
    
    const allTemps = dailyData.flatMap(d => [d.maxTemp, d.minTemp, d.avgTemp]).filter(valid);
    const minTemp = Math.min(...allTemps);
    const maxTemp = Math.max(...allTemps);
    
    // 向下和向上取整到5的倍数
    const minTick = Math.floor(minTemp / 5) * 5 - 5;
    const maxTick = Math.ceil(maxTemp / 5) * 5 + 5;
    
    return { min: minTick, max: maxTick };
  };

  const tempRange = getTemperatureRange();

  // 显示所有每日数据，不进行采样
  const displayData = dailyData;
  
  console.log(`每日温度数据总数: ${dailyData.length}天`); // 调试日志

  // 计算日温差的实际范围
  const getTempRangeYAxis = () => {
    if (dailyData.length === 0) return { min: 0, max: 25, ticks: Array.from({ length: 6 }, (_, i) => i * 5) };
    
    const tempRanges = dailyData.map(d => d.tempRange).filter(valid);
    const maxRange = Math.max(...tempRanges);
    const minRange = Math.min(...tempRanges);
    
    // 从0开始（温差不能为负），但上限根据实际数据调整
    const buffer = Math.max(1, maxRange * 0.1); // 10%缓冲区，最少1度
    const maxTick = Math.ceil((maxRange + buffer) / 5) * 5;
    
    // 生成适当数量的刻度
    const tickCount = Math.min(Math.max(Math.ceil(maxTick / 5) + 1, 4), 10);
    const ticks = Array.from({ length: tickCount }, (_, i) => i * 5);
    
    return { min: 0, max: maxTick, ticks };
  };

  const tempRangeAxis = getTempRangeYAxis();

  /**
   * 自定义工具提示
   */
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-slate-900 dark:text-white font-medium">{label}</p>
          <p className="text-red-600 dark:text-red-400 text-sm">最高温度: {data.maxTemp}°C</p>
          <p className="text-blue-600 dark:text-blue-400 text-sm">最低温度: {data.minTemp}°C</p>
          <p className="text-green-600 dark:text-green-400 text-sm">平均温度: {data.avgTemp}°C</p>
          <p className="text-purple-600 dark:text-purple-400 text-sm">温差: {data.tempRange}°C</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* 统计概览 */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/20 border-red-800/30">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-6 h-6 text-red-600 dark:text-red-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.absoluteMax}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">全年最高</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/20 border-blue-800/30">
            <CardContent className="p-4 text-center">
              <TrendingDown className="w-6 h-6 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stats.absoluteMin}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">全年最低</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/20 to-orange-800/20 border-orange-800/30">
            <CardContent className="p-4 text-center">
              <Thermometer className="w-6 h-6 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{stats.avgMaxTemp}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">平均最高</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-900/20 to-cyan-800/20 border-cyan-800/30">
            <CardContent className="p-4 text-center">
              <Thermometer className="w-6 h-6 text-cyan-600 dark:text-cyan-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-cyan-600 dark:text-cyan-400">{stats.avgMinTemp}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">平均最低</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/20 border-purple-800/30">
            <CardContent className="p-4 text-center">
              <BarChart3 className="w-6 h-6 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{stats.avgTempRange}°C</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">平均日较差</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-900/20 to-yellow-800/20 border-yellow-800/30">
            <CardContent className="p-4 text-center">
              <Calendar className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-400">{stats.highTempDays}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300">高温天数</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 每日最高最低温度曲线 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
                <Thermometer className="w-5 h-5 text-red-600 dark:text-red-400" />
                <span>{config.locationName} 每日温度变化曲线</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                全年每日最高温度、最低温度和平均温度趋势 (显示 {displayData.length} 天完整数据)
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              <Badge variant="outline" className="border-red-400 text-red-600 dark:text-red-400">
                最高温度
              </Badge>
              <Badge variant="outline" className="border-blue-400 text-blue-600 dark:text-blue-400">
                最低温度
              </Badge>
              <Badge variant="outline" className="border-green-400 text-green-600 dark:text-green-400">
                平均温度
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={displayData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                <defs>
                  <linearGradient id="tempRangeGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="dateStr" 
                  stroke="#9ca3af"
                  fontSize={11}
                  interval="preserveStartEnd"
                />
                <YAxis 
                  stroke="#9ca3af"
                  fontSize={12}
                  type="number"
                  domain={[tempRange.min, tempRange.max]}
                  ticks={Array.from({ length: (tempRange.max - tempRange.min) / 5 + 1 }, (_, i) => tempRange.min + i * 5)}
                  interval={0}
                  label={{ value: '温度 (°C)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9ca3af' } }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                
                {/* 最高温度区域 */}
                <Area isAnimationActive={false}
                  type="monotone"
                  dataKey="maxTemp"
                  stroke="#ef4444"
                  fill="url(#tempRangeGradient)"
                  fillOpacity={0.4}
                  strokeWidth={1.5}
                  dot={false}
                  name="最高温度"
                />
                
                {/* 最低温度区域 */}
                <Area isAnimationActive={false}
                  type="monotone"
                  dataKey="minTemp"
                  stroke="#3b82f6"
                  fill="#1e40af"
                  fillOpacity={0.2}
                  strokeWidth={1.5}
                  dot={false}
                  name="最低温度"
                />
                
                {/* 平均温度线 */}
                <Line isAnimationActive={false}
                  type="monotone"
                  dataKey="avgTemp"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={false}
                  name="平均温度"
                />
                
                {/* 高温阈值参考线 */}
                <ReferenceLine 
                  y={config.highTempThreshold} 
                  stroke="#f59e0b" 
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  label={{ 
                    value: `高温阈值 ${config.highTempThreshold}°C`, 
                    position: "topLeft", 
                    fill: "#f59e0b", 
                    fontSize: 11,
                    offset: 10
                  }}
                />
                
                {/* 低温阈值参考线 */}
                <ReferenceLine 
                  y={config.lowTempThreshold} 
                  stroke="#06b6d4" 
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  label={{ 
                    value: `低温阈值 ${config.lowTempThreshold}°C`, 
                    position: "bottomLeft", 
                    fill: "#06b6d4", 
                    fontSize: 11,
                    offset: 10
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 日温差分析 */}
      <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
        <CardHeader>
          <CardTitle className="text-slate-900 dark:text-white flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <span>日温差变化分析</span>
          </CardTitle>
          <CardDescription className="text-slate-600 dark:text-slate-300">
            每日最高温度与最低温度的差值变化
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={displayData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="dateStr" 
                  stroke="#9ca3af"
                  fontSize={11}
                  interval="preserveStartEnd"
                />
                <YAxis 
                  stroke="#9ca3af"
                  fontSize={12}
                  type="number"
                  domain={[tempRangeAxis.min, tempRangeAxis.max]}
                  ticks={tempRangeAxis.ticks}
                  interval={0}
                  label={{ value: '温差 (°C)', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#9ca3af' } }}
                />
                <Tooltip 
                  formatter={(value: any, name: string) => [`${value}°C`, name]}
                  labelFormatter={(label: string) => `日期: ${label}`}
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    border: '1px solid #475569',
                    borderRadius: '8px'
                  }}
                />
                <Legend />
                
                {/* 日温差柱状图 */}
                <Bar isAnimationActive={false} 
                  dataKey="tempRange" 
                  fill="#8b5cf6"
                  fillOpacity={0.7}
                  name="日温差"
                  radius={[2, 2, 0, 0]}
                />
                
                {/* 平均日温差参考线 */}
                {stats && (
                  <Line isAnimationActive={false}
                    type="monotone"
                    dataKey={() => stats.avgTempRange}
                    stroke="#f59e0b"
                    strokeDasharray="5 5"
                    strokeWidth={2}
                    dot={false}
                    name="平均日温差"
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 极端天气统计 */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
            <CardHeader>
              <CardTitle className="text-slate-900 dark:text-white text-lg flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-red-600 dark:text-red-400" />
                <span>高温天数统计</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                日最高温度 ≥ {config.highTempThreshold}°C 的天数
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-4xl font-bold text-red-600 dark:text-red-400 mb-2">{stats.highTempDays}</p>
                <p className="text-slate-400 mb-4">天 / 总计{stats.totalDays}天</p>
                <div className="w-full bg-slate-50 dark:bg-slate-700 rounded-full h-2">
                  <div 
                    className="bg-red-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(stats.highTempDays / stats.totalDays) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  占比: {Math.round((stats.highTempDays / stats.totalDays) * 100 * 10) / 10}%
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
            <CardHeader>
              <CardTitle className="text-slate-900 dark:text-white text-lg flex items-center space-x-2">
                <TrendingDown className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>低温天数统计</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                日最低温度 ≤ {config.lowTempThreshold}°C 的天数
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-2">{stats.lowTempDays}</p>
                <p className="text-slate-400 mb-4">天 / 总计{stats.totalDays}天</p>
                <div className="w-full bg-slate-50 dark:bg-slate-700 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(stats.lowTempDays / stats.totalDays) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  占比: {Math.round((stats.lowTempDays / stats.totalDays) * 100 * 10) / 10}%
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
            <CardHeader>
              <CardTitle className="text-slate-900 dark:text-white text-lg flex items-center space-x-2">
                <BarChart3 className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                <span>大温差天数</span>
              </CardTitle>
              <CardDescription className="text-slate-600 dark:text-slate-300">
                日温差 ≥ 15°C 的天数
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-4xl font-bold text-purple-600 dark:text-purple-400 mb-2">{stats.largeTempRangeDays}</p>
                <p className="text-slate-400 mb-4">天 / 总计{stats.totalDays}天</p>
                <div className="w-full bg-slate-50 dark:bg-slate-700 rounded-full h-2">
                  <div 
                    className="bg-purple-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(stats.largeTempRangeDays / stats.totalDays) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  占比: {Math.round((stats.largeTempRangeDays / stats.totalDays) * 100 * 10) / 10}%
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
