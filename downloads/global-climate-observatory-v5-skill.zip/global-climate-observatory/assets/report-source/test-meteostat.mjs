import assert from 'node:assert/strict';
import {parseMeteostatCsv} from './src/utils/meteostat.mjs';
const csv='year,month,day,hour,rhum,temp,wspd,pres,prcp,temp_source\n2025,1,1,0,50,20,36,1010,0,metno_forecast\n2025,1,1,1,,,,,,\n2024,12,31,23,60,10,0,1000,1,source\n';
const obj=parseMeteostatCsv(csv,2025);assert.equal(obj.rows.length,8760);assert.equal(obj.rows[0][1],20);assert.equal(obj.rows[0][5],10);assert.equal(obj.rows[0][4],0);assert.ok(obj.rows[0][2]>9&&obj.rows[0][2]<10);assert.deepEqual(obj.rows[1].slice(1),[null,null,null,null,null,null]);assert.equal(obj.modelHours,1);assert.equal(obj.presentHours,2);assert.equal(obj.missingHours,8758);assert.equal(obj.rows.at(-1)[0],'2025-12-31T23:00:00');
assert.throws(()=>parseMeteostatCsv('year,month,day,hour,temp\n2025,1,1,0,20',2025),/rhum/);
assert.throws(()=>parseMeteostatCsv(csv+'2025,1,1,0,50,20,0,1000,1,x\n',2025),/重复/);
assert.throws(()=>parseMeteostatCsv('<html>blocked</html>',2025),/字段/);
console.log('PASS: named headers, missing vs zero, UTC year, unit conversion, dewpoint derivation, model attribution, schema and duplicate errors');
