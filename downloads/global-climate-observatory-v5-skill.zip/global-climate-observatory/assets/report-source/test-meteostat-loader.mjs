// Loader tests use controlled HTTP responses; no local hourly fallback is permitted.
import assert from 'node:assert/strict';
import {gzipSync} from 'node:zlib';
import {loadMeteostatHourly} from './src/utils/meteostat.mjs';
const originalFetch=globalThis.fetch;const calls=[];
try{
 globalThis.fetch=async url=>{calls.push(url);return new Response(gzipSync('year,month,day,hour,temp,rhum,wspd\n2025,1,1,0,20,50,36\n'));};
 const data=await loadMeteostatHourly('06659');assert.equal(data.rows[0][5],10);assert.equal(data.presentHours,1);assert.equal(calls[0],'https://data.meteostat.net/hourly/2025/06659.csv.gz');
 calls.length=0;globalThis.fetch=async url=>{calls.push(url);return new Response('',{status:404});};await assert.rejects(loadMeteostatHourly('06659'),/404/);assert.equal(calls.length,1);
 calls.length=0;globalThis.fetch=async url=>{calls.push(url);throw new TypeError('Network');};await assert.rejects(loadMeteostatHourly('06659'),/不会读取本地/);assert.equal(calls.length,1);assert.ok(calls.every(u=>u.startsWith('https://data.meteostat.net/')));
 console.log('PASS: official URL, gzip decoding, leading-zero ID, HTTP/network errors, no local fallback');
}finally{globalThis.fetch=originalFetch;}
