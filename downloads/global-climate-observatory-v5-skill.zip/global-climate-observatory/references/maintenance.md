# V5结构与维护

## 目录

- assets/site/：可直接运行与发布的V5网页。根index.html跳转v5/index.html。
- assets/site/v5/stations.json：12967站静态风险、分类、经纬度与时区；v5/meta.json为来源说明。气象记录不在此目录。
- assets/site/data/world.json：地图；当前中国选区包含台湾。修改边界需以用户请求为准。
- assets/site/v5/app.js：首页图表、筛选、CSV与跳转。
- assets/site/report/：完整全年报告构建产物。
- assets/report-source/：报告React源项目与测试。构建脚本将输出到相邻site/report。

## 报告源码修改

先复制assets到独立工作目录，保留report-source与site相邻。修改报告需Node.js及npm；正常查看网页不需要Node。源码不依赖原机器绝对路径。

在report-source内运行 `npm ci`，修改后运行：

```text
node test-ultraviolet.mjs
node test-solar.mjs
node test-stats.mjs
node test-meteostat.mjs
node test-meteostat-loader.mjs
node test-meteostat-timezone.mjs
node build.mjs
```

- src/pages/StationReport.tsx：scheme=5读取Meteostat在线记录并独立加载NASA辐照，方案1/2分支仅为旧版兼容；本包入口始终scheme=5，不包含旧版本地气象文件。
- src/utils/meteostat.mjs：按字段名解析CSV、单位/缺失处理、UTC转站点当地时间、跨年补取、超时与错误提示。
- src/utils/stats.mjs：报告统计口径。

保持CSV表头解析兼容性；不要依赖固定列顺序。保留前导零站点代码。时区使用IANA标识和历史规则；避免让浏览器所在时区再次转换已生成的当地日期。

## API与许可

年度接口：`https://data.meteostat.net/hourly/{year}/{station}.csv.gz`，无需密钥。按需请求单站，遵守服务端HTTP缓存，不为普通查看批量重抓全部站点。

官方说明：https://dev.meteostat.net/data/timeseries/hourly
站点元数据：https://dev.meteostat.net/data/weather-stations
时间与单位：https://dev.meteostat.net/formats.html
许可：https://dev.meteostat.net/license.html

风险分类、极寒标记与全年图表取自不同层次的数据，在线数据更新不会自动重算样本P5/P95归一化风险分。用户要换年份或重算评分时，需重新提供或确认年度指标和样本，不沿用旧分数冒充新结果。

## 发布

仅发布site的内容；不要发布report-source/node_modules或任何凭据。保留.nojekyll和相对路径以兼容GitHub项目子路径。按用户授权指定仓库与分支；沿用自己的电脑登录并先检查远端文件，再按正常Git或可用GitHub工具提交。未获得写入权限时先完成本地交付，不修改权限或创建密钥。

当前公开部署只是使用入口：https://cherryzhang1903-cloud.github.io/Global-climate-observatory/

V5太阳辐照实现与单位见[solar.md](solar.md)。构建脚本输出到相邻assets/site/report。
