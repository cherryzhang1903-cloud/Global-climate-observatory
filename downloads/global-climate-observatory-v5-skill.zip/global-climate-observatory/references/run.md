# 运行与迁移

## 直接使用

公开站点无需安装Python或Node；现代浏览器和访问Meteostat的网络即可。Skill让Codex知道如何查找、启动和维护应用，不替代Codex本身或浏览器。

## 本机运行

从Skill所在目录解析相对路径，不使用任何原电脑的绝对路径。需要Python 3；如宿主有运行时发现工具，优先使用其提供的Python。网页已构建，运行无需pip或npm安装。

```text
python scripts/serve.py --background --port 0
```

返回JSON中的url即本机入口，例如 `http://127.0.0.1:随机端口/v5/index.html`。服务只绑定127.0.0.1，不向局域网公开。服务日志和状态文件保存在该电脑临时目录。--port 0让系统挑选空闲端口，避免冲突。前台运行可用 `python scripts/serve.py --port 0`，通过运行它的终端或会话停止。

需要改项目或交付网站副本：

```text
python scripts/export_site.py --output 用户选择的新文件夹
```

输出目录不得已经存在；脚本不覆盖已有项目，不自动发布。查看副本可用 `python scripts/serve.py --site 用户副本目录 --background --port 0`。

## 在另一台电脑安装

Skill压缩包解压后保持 `global-climate-observatory/SKILL.md` 的目录结构。用户可让目标Codex安装此本地Skill，或运行：

```text
python global-climate-observatory/scripts/install_skill.py
```

默认复制到目标电脑的 `$CODEX_HOME/skills/global-climate-observatory`；未设置CODEX_HOME时使用 `~/.codex/skills/global-climate-observatory`。已经存在时不覆盖；若当前位置已是目标目录则报告已安装。安装后重启Codex或新开会话，在Skill列表中调用 `$global-climate-observatory`。

Windows的 `~` 通常是当前用户主目录；macOS/Linux同样使用当前用户目录。不要复制原电脑的凭据、node_modules、.git或本地逐小时数据。
