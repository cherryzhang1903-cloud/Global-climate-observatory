"""Serve the bundled static V5 on loopback; no third-party dependencies."""
import argparse, functools, http.server, json, os, pathlib, subprocess, sys, tempfile, time
SKILL=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--site',type=pathlib.Path,default=SKILL/'assets/site');p.add_argument('--port',type=int,default=0);p.add_argument('--background',action='store_true');p.add_argument('--state-file',type=pathlib.Path);a=p.parse_args();root=a.site.expanduser().resolve()
 if not (root/'v5/index.html').is_file():p.error('site must contain v5/index.html')
 if not 0<=a.port<=65535:p.error('port must be 0..65535')
 if a.background:
  tmp=pathlib.Path(tempfile.mkdtemp(prefix='climate-v5-'));state=tmp/'server.json';log=tmp/'server.log';args=[sys.executable,str(pathlib.Path(__file__).resolve()),'--site',str(root),'--port',str(a.port),'--state-file',str(state)]
  kwargs={'stdin':subprocess.DEVNULL,'cwd':str(root)}
  if os.name=='nt':kwargs['creationflags']=subprocess.DETACHED_PROCESS|subprocess.CREATE_NEW_PROCESS_GROUP|subprocess.CREATE_NO_WINDOW
  else:kwargs['start_new_session']=True
  with log.open('ab') as out:proc=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,**kwargs)
  for _ in range(100):
   if state.exists():result=json.loads(state.read_text(encoding='utf-8'));result.update(stateFile=str(state),log=str(log));print(json.dumps(result,ensure_ascii=True),flush=True);return
   if proc.poll() is not None:raise SystemExit('Server failed: '+log.read_text(encoding='utf-8',errors='replace'))
   time.sleep(.1)
  raise SystemExit('Server startup timed out; check '+str(log))
 handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(root));server=http.server.ThreadingHTTPServer(('127.0.0.1',a.port),handler);result={'status':'ready','url':f'http://127.0.0.1:{server.server_port}/v5/index.html','pid':os.getpid(),'site':str(root)}
 if a.state_file:a.state_file.write_text(json.dumps(result,ensure_ascii=True),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=True),flush=True)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:server.server_close()
if __name__=='__main__':main()
