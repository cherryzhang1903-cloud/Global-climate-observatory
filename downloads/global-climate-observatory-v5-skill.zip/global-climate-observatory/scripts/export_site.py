"""Export an independent, publication-ready site; never overwrite an existing path."""
import argparse,json,pathlib,shutil
SKILL=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=pathlib.Path);a=p.parse_args();out=a.output.expanduser().resolve();source=SKILL/'assets/site'
 if out.exists():p.error('output already exists; choose a new directory')
 if source.resolve()==out or source.resolve() in out.parents:p.error('output must be outside the bundled site')
 shutil.copytree(source,out);files=[f for f in out.rglob('*') if f.is_file()];print(json.dumps({'site':str(out),'entry':'v5/index.html','files':len(files),'bytes':sum(f.stat().st_size for f in files)},ensure_ascii=True))
if __name__=='__main__':main()
