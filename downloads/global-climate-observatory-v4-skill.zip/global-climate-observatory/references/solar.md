# V4太阳辐照数据口径

- NASA POWER参数ALLSKY_SFC_SW_DWN为全天空地表水平短波辐照，网格估计不是站点辐射仪实测，也不是紫外线。
- 接口https://power.larc.nasa.gov/api/temporal/hourly/point；站点经纬度、community=RE、format=JSON、time-standard=UTC，年度前后各补一天。按需单站加载。
- Wh/m²乘0.0036得到MJ/㎡；kW-hr/m²乘3.6。单位无法识别时报错，不猜测。小时能量MJ/㎡除0.0036为小时平均辐照度W/㎡。
- 先转换站点IANA时区，再汇总日/月/年，保留UTC唯一时刻和夏令时23/25小时日。
- 有效零值保留，负值/填充值/缺失为空。日/月/年仅完整时显示完整累计；不完整则显示覆盖率和有效小时累计，不补零、不外推。
- 独立加载、60秒超时、可重试，失败不阻塞温湿度报告，不替换站点或来源。
- 组件assets/report-source/src/components/SolarRadiation.tsx；工具src/utils/solar.mjs；测试node test-solar.mjs。
- V4入口v4/index.html；报告report/index.html?station=51573&scheme=4。V3继续保留；原V3 Excel仍为首页评分快照，不包含在线生成的辐照曲线。

官方说明：https://power.larc.nasa.gov/docs/services/api/temporal/hourly/
