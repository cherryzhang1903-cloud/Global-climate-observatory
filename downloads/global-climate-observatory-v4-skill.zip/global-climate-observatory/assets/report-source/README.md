# V4 report source

Run npm ci, then node test-solar.mjs and node build.mjs. Build output: ../site/report. Viewing the bundled website does not require Node or npm. See ../../references/maintenance.md and solar.md.
