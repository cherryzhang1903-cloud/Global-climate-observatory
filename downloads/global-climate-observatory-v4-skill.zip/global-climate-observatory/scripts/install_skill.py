"""Install this skill on the current computer, without credentials or overwrites."""
import argparse,json,os,pathlib,shutil
SOURCE=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--codex-home',type=pathlib.Path,default=pathlib.Path(os.environ.get('CODEX_HOME',str(pathlib.Path.home()/'.codex'))));a=p.parse_args();dest=a.codex_home.expanduser().resolve()/'skills'/'global-climate-observatory'
 if SOURCE==dest:print(json.dumps({'status':'already-installed','path':str(dest)},ensure_ascii=True));return
 if dest.exists():p.error('skill already exists; existing files were not changed')
 if not (SOURCE/'SKILL.md').is_file() or not (SOURCE/'assets/site/v4/index.html').is_file():p.error('incomplete skill archive')
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(SOURCE,dest);print(json.dumps({'status':'installed','path':str(dest),'next':'Restart Codex or open a new session; invoke $global-climate-observatory'},ensure_ascii=True))
if __name__=='__main__':main()
